using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using PopLD.Domain.Services;

namespace PopLD.Engine
{
    /// <summary>
    /// Extended haplotype homozygosity (EHH) decay around an anchor site — a faithful port of
    /// the original PopLDdecay <c>EHHDeal.h</c> (<c>-EHH chr:pos</c> mode).
    ///
    /// Only fully-called sites inside [anchor-MaxDist, anchor+MaxDist] take part (the original
    /// drops any site with missing data). Haplotypes are extended outward from the core site in
    /// both directions; at each step the haplotypes are re-partitioned and homozygosity is
    /// <c>Σ n_h(n_h-1) / (nHap(nHap-1))</c>. Extension stops when EHH drops below 0.088 or the
    /// region runs out — exactly the original's stopping rule.
    ///
    /// Where the original concatenates a per-haplotype allele string at every step (O(nHap) chars
    /// per site, then a string-keyed map), this keeps an integer group id per haplotype and
    /// refines it. The induced partition — and therefore every output number — is identical, but
    /// the cost per step drops to one pass with no string allocation.
    /// </summary>
    public static class EhhAnalysis
    {
        /// <summary>Original's cut-off: stop extending once total EHH falls below this.</summary>
        private const double StopBelow = 0.088;

        /// <summary>Original requires at least this many fully-called sites in the region.</summary>
        private const int MinSites = 8;

        public sealed class EhhOutcome
        {
            public bool Success;
            public string Message;
            public int SitesInRegion;      // sites inside the window, before the missing-data filter
            public int SitesUsed;          // fully-called sites actually used
            public long CorePos;           // anchor SNP the haplotypes were grown from
        }

        /// <summary>
        /// Computes EHH around <paramref name="anchorPos"/> and writes <paramref name="outPath"/>
        /// (gzipped TSV: Chr, Site, Dist, EHH_all, EHH_0, EHH_1). <paramref name="sites"/> must be
        /// the retained sites of the anchor's chromosome, ascending by position.
        /// </summary>
        public static EhhOutcome Run(
            IReadOnlyList<PackedSite> sites, int nHap, string chrom, long anchorPos, int maxDistBp, string outPath,
            System.Threading.CancellationToken ct = default(System.Threading.CancellationToken))
        {
            if (nHap < 2)
                return new EhhOutcome { Success = false, Message = "EHH needs at least 2 haplotypes." };

            long begin = anchorPos - maxDistBp; if (begin < 0) begin = 0;
            long end = anchorPos + maxDistBp;

            // Region members; the original keeps only sites with no missing genotype. It also
            // holds sites in a std::map keyed by position, so a repeated position keeps the FIRST
            // record and drops later ones — mirrored here so #SNP_Number and the core pick agree.
            int inRegion = 0;
            long lastPos = long.MinValue;
            var used = new List<PackedSite>();
            for (int i = 0; i < sites.Count; i++)
            {
                long pos = sites[i].Pos;
                if (pos < begin) continue;
                if (pos > end) break;
                if (pos == lastPos) continue;      // duplicate position: first record wins
                lastPos = pos;
                inRegion++;
                if (!sites[i].AnyMissing) used.Add(sites[i]);
            }

            int n = used.Count;
            if (n < MinSites)
            {
                return new EhhOutcome
                {
                    Success = false,
                    SitesInRegion = inRegion,
                    SitesUsed = n,
                    Message = $"EHH needs at least {MinSites} fully-called SNP in the region; " +
                              $"found {n} (of {inRegion} in {chrom}:{begin}-{end}). " +
                              "Widen MaxDist, relax the filters, or pick another anchor.",
                };
            }

            // Core site: the last one at or before the anchor, nudged inward exactly as the
            // original does so there is always at least one site on the far side to extend to.
            int core = -1;
            for (int i = 0; i < n; i++)
            {
                if (used[i].Pos <= anchorPos) core = i; else break;
            }
            if (core < 0) core = n - 2;      // anchor sits left of every site
            else if (core == 0) core = 1;    // anchor at or before the first site

            double denom = (double)nHap * (nHap - 1);
            var ehhAll = new double[n];
            var ehh0 = new double[n];
            var have = new bool[n];

            // --- core site ---
            var coreAllele = new byte[nHap];
            int zeros = 0;
            for (int h = 0; h < nHap; h++)
            {
                byte a = AlleleAt(used[core], h);
                coreAllele[h] = a;
                if (a == 0) zeros++;
            }
            int ones = nHap - zeros;
            // In double: n(n-1) overflows an int once a core allele is carried by more than
            // 46,340 haplotypes (about 23,000 samples).
            ehh0[core] = (double)zeros * (zeros - 1) / denom;
            ehhAll[core] = (double)ones * (ones - 1) / denom + ehh0[core];
            have[core] = true;

            // --- extend left, then right, each starting from the core partition ---
            Extend(used, nHap, core, -1, coreAllele, denom, ehhAll, ehh0, have, ct);
            Extend(used, nHap, core, +1, coreAllele, denom, ehhAll, ehh0, have, ct);

            WriteEhh(outPath, chrom, anchorPos, used, ehhAll, ehh0, have, n);

            return new EhhOutcome
            {
                Success = true,
                SitesInRegion = inRegion,
                SitesUsed = n,
                CorePos = used[core].Pos,
                Message = $"EHH around {chrom}:{anchorPos} (core SNP {used[core].Pos}); " +
                          $"{n} fully-called of {inRegion} SNP in ±{maxDistBp / 1000}kb -> {outPath}",
            };
        }

        /// <summary>
        /// Walks away from the core in <paramref name="step"/> direction, refining the haplotype
        /// partition one site at a time and recording EHH until it drops below the cut-off.
        /// </summary>
        private static void Extend(
            IReadOnlyList<PackedSite> used, int nHap, int core, int step, byte[] coreAllele,
            double denom, double[] ehhAll, double[] ehh0, bool[] have, System.Threading.CancellationToken ct)
        {
            int n = used.Count;
            // Group ids start as the core allele, so group 0 == "carries core allele 0".
            var group = new int[nHap];
            for (int h = 0; h < nHap; h++) group[h] = coreAllele[h];
            var groupIsCore0 = new List<bool> { true, false };

            var next = new Dictionary<long, int>();
            var sizes = new List<int>();
            var isCore0 = new List<bool>();

            for (int i = core + step; i >= 0 && i < n; i += step)
            {
                ct.ThrowIfCancellationRequested();
                next.Clear(); sizes.Clear(); isCore0.Clear();
                var site = used[i];
                for (int h = 0; h < nHap; h++)
                {
                    long key = ((long)group[h] << 1) | AlleleAt(site, h);
                    if (!next.TryGetValue(key, out int id))
                    {
                        id = sizes.Count;
                        next[key] = id;
                        sizes.Add(0);
                        isCore0.Add(groupIsCore0[group[h]]);
                    }
                    group[h] = id;
                    sizes[id]++;
                }
                groupIsCore0.Clear();
                groupIsCore0.AddRange(isCore0);

                double sum = 0, sum0 = 0;
                for (int g = 0; g < sizes.Count; g++)
                {
                    double c = (double)sizes[g] * (sizes[g] - 1);
                    sum += c;
                    if (isCore0[g]) sum0 += c;
                }

                ehhAll[i] = sum / denom;
                ehh0[i] = sum0 / denom;
                have[i] = true;
                if (ehhAll[i] < StopBelow) break;
            }
        }

        /// <summary>Allele (0/1) of haplotype <paramref name="h"/>; sites here are fully called.</summary>
        private static byte AlleleAt(PackedSite site, int h)
            => (byte)((site.Ones[h >> 6] >> (h & 63)) & 1UL);

        private static void WriteEhh(
            string path, string chrom, long anchorPos, IReadOnlyList<PackedSite> used,
            double[] ehhAll, double[] ehh0, bool[] have, int n)
        {
            // Atomic (a failed write keeps the previous file), and in the input's own bytes: the
            // chromosome name was read as Latin-1, so writing it back as Latin-1 reproduces the
            // VCF's bytes exactly, as the original does.
            PopLD.Domain.IO.AtomicFile.Write(path, fs =>
                WriteEhhBody(fs, chrom, anchorPos, used, ehhAll, ehh0, have, n));
        }

        private static void WriteEhhBody(
            Stream fs, string chrom, long anchorPos, IReadOnlyList<PackedSite> used,
            double[] ehhAll, double[] ehh0, bool[] have, int n)
        {
            using (var gz = new GZipStream(fs, CompressionLevel.Optimal, true))
            using (var w = new StreamWriter(gz, PopLD.Domain.IO.TextInput.Latin1, 1 << 16))
            {
                ResultFormat.WriteEhhHeader(w, n);
                for (int i = 0; i < n; i++)
                {
                    long pos = used[i].Pos;
                    // A site past the stop rule carries no EHH: the original writes zeros there.
                    if (have[i]) ResultFormat.WriteEhhRow(w, chrom, pos, pos - anchorPos, ehhAll[i], ehh0[i], ehhAll[i] - ehh0[i]);
                    else ResultFormat.WriteEhhRow(w, chrom, pos, pos - anchorPos, 0, 0, 0);
                }
            }
        }
    }
}
