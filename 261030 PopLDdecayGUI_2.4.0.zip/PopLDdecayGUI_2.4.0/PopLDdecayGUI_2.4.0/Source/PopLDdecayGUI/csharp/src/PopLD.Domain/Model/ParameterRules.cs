using System.Globalization;

namespace PopLD.Domain.Model
{
    /// <summary>
    /// Accepted values of every user-set parameter, and how a typed value is read. The command
    /// line and the GUI both validate through here, so a value refused by one is refused by the
    /// other with the same message.
    /// </summary>
    public static class ParameterRules
    {
        // Analysis. MaxDist is multiplied by 1000 into a base-pair array index, so it stays well
        // below the point where that product would overflow an int. A minor-allele frequency
        // cannot exceed 0.5; Het and Miss are ratios.
        public const int MaxDistKbMin = 1, MaxDistKbMax = 2000000;
        public const double MafMin = 0.0, MafMax = 0.5;
        public const double HetMin = 0.0, HetMax = 1.0;
        public const double MissMin = 0.0, MissMax = 1.0;

        // Plotting. 0 for bin1, bin2 or break means "the default", exactly as the reference
        // plotter's "$bin1||=10; $bin2||=100; $break||=100" reads a 0 (Plot_OnePop.pl:64-67).
        public const int BinMin = 0, BinMax = 10000000;
        public const int BreakMin = 0, BreakMax = int.MaxValue;
        public const int DefaultBin1 = 10, DefaultBin2 = 100, DefaultBreak = 100;
        /// <summary>0 = the file's own extent (the reference plotter's default).</summary>
        public const int MaxXKbMin = 0, MaxXKbMax = 2000000;
        /// <summary>The layout reserves room for axes; a smaller canvas has no plot area left.</summary>
        public const int CanvasMin = 200, CanvasMax = 20000;
        /// <summary>Upper bound when a PNG is rendered too (8000 x 8000 is already 256 MB of pixels).</summary>
        public const int PngCanvasMax = 8000;

        /// <summary>
        /// Reads a decimal number with '.' as the decimal point, whatever the machine's language
        /// settings. Thousands separators are NOT accepted: under the invariant culture "0,005"
        /// would otherwise read as five. NaN and infinities are refused.
        /// </summary>
        public static bool TryParseNumber(string text, out double value)
        {
            if (text != null &&
                double.TryParse(text.Trim(), NumberStyles.Float, CultureInfo.InvariantCulture, out value) &&
                !double.IsNaN(value) && !double.IsInfinity(value))
                return true;
            value = 0;
            return false;
        }

        /// <summary>Reads a whole number (optional sign, surrounding spaces allowed).</summary>
        public static bool TryParseInteger(string text, out int value)
        {
            if (text != null && int.TryParse(text.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out value))
                return true;
            value = 0;
            return false;
        }

        /// <summary>Null when <paramref name="v"/> is inside [min, max]; otherwise the message.</summary>
        public static string CheckRange(string name, double v, double min, double max)
        {
            if (v >= min && v <= max) return null;
            var inv = CultureInfo.InvariantCulture;
            return $"{name} must be between {min.ToString(inv)} and {max.ToString(inv)}, got {v.ToString(inv)}";
        }

        /// <summary>Message for a value that is not a number at all.</summary>
        public static string NotANumber(string name, string text)
            => $"{name} expects a number with '.' as the decimal point, got '{text}'";

        /// <summary>Message for a value that is not a whole number.</summary>
        public static string NotAnInteger(string name, string text)
            => $"{name} expects a whole number, got '{text}'";

        /// <summary>The bin width the plotter uses for a requested one (0 = default).</summary>
        public static int EffectiveBin(int requested, int dflt) => requested > 0 ? requested : dflt;

        /// <summary>The break point the plotter uses for a requested one (0 = default).</summary>
        public static int EffectiveBreak(int requested) => requested > 0 ? requested : DefaultBreak;
    }
}
