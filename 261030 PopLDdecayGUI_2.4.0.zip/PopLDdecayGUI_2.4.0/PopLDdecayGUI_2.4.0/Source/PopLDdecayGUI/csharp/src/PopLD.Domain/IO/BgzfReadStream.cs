using System;
using System.IO;
using System.IO.Compression;

namespace PopLD.Domain.IO
{
    /// <summary>
    /// Read-only stream that decompresses BGZF (blocked gzip, as produced by bgzip/tabix
    /// and used by 1000 Genomes VCFs). .NET Framework's <see cref="GZipStream"/> only reads
    /// the first gzip member, so it cannot handle the thousands of concatenated blocks in a
    /// BGZF file; this reader walks every block. Each block's exact compressed size comes from
    /// the mandatory "BC" extra subfield, so we feed DeflateStream one bounded block at a time
    /// and never over-read across block boundaries. No third-party dependency.
    /// <para>Every block is checked against its trailer (length and CRC-32), as zlib checks each
    /// member, and a file that ends inside a block is an error rather than a quiet end of data:
    /// analysing the readable part of a truncated download would look like a complete result.</para>
    /// <para>An ordinary gzip member after the blocks (a bgzipped file with a gzipped one
    /// appended) is handed to <see cref="GzipMembersStream"/> with the rest of the file. Bytes
    /// that do not start a gzip member are ignored after the end-of-file marker block, as zlib
    /// ignores them, and are an error anywhere else: zeros or junk after a block that is not the
    /// marker are what a cut-off or overwritten file looks like. (A file cut exactly at a block
    /// boundary, with nothing after it, cannot be told from a complete file without a marker.)</para>
    /// </summary>
    public sealed class BgzfReadStream : ReadOnlyStream
    {
        private readonly Stream _base;
        private byte[] _out = new byte[1 << 16];   // decompressed block (BGZF blocks are <= 64 KiB)
        private int _outPos;
        private int _outLen;
        private bool _eof;
        private long _block;                       // index of the block being read, for messages
        private Stream _tail;                      // the rest of the file, when it is plain gzip
        private bool _afterEofMarker;              // the last block read was the empty EOF marker

        // Reused per-block scratch buffers: a BGZF file has thousands of blocks, and allocating
        // fresh arrays for each one was a large source of Gen0 GC churn. All are bounded (header
        // 12 B, trailer 8 B, extra/cdata < 64 KiB), so we keep them and grow only if ever needed.
        private readonly byte[] _hdr = new byte[12];
        private readonly byte[] _trailer = new byte[8];
        private byte[] _extra = new byte[64];
        private byte[] _cdata = new byte[1 << 16];

        public BgzfReadStream(Stream baseStream)
        {
            _base = baseStream ?? throw new ArgumentNullException(nameof(baseStream));
        }

        private static byte[] EnsureCapacity(byte[] buf, int need)
        {
            return buf.Length >= need ? buf : new byte[need];
        }

        /// <summary>True if the stream begins with a BGZF block (gzip + "BC" extra subfield).</summary>
        public static bool LooksLikeBgzf(byte[] head, int len)
        {
            return len >= 16 && head[0] == 0x1f && head[1] == 0x8b
                && (head[3] & 0x04) != 0 && head[12] == (byte)'B' && head[13] == (byte)'C';
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            while (_outPos >= _outLen)
            {
                if (_tail != null) return _tail.Read(buffer, offset, count);
                if (!NextBlock() && _tail == null) return 0;
            }
            int n = Math.Min(count, _outLen - _outPos);
            Buffer.BlockCopy(_out, _outPos, buffer, offset, n);
            _outPos += n;
            return n;
        }

        private bool NextBlock()
        {
            while (true)
            {
                if (_eof) return false;

                // Fixed 12-byte gzip header (BGZF always sets FEXTRA). A clean end of file can
                // only fall here, between blocks.
                long start = _base.CanSeek ? _base.Position : -1;
                int got = ReadUpTo(_base, _hdr, 0, 12);
                if (got == 0) { _eof = true; return false; }
                if (got < 2 || _hdr[0] != 0x1f || _hdr[1] != 0x8b)
                {
                    if (_block == 0)
                        throw new InvalidDataException("Not a BGZF file: missing gzip header.");
                    // Bytes that are not gzip data are accepted only after the end-of-file marker
                    // block that bgzip writes last. Anywhere else they mean the data was cut off
                    // or overwritten: a download that stopped partway into a preallocated file
                    // leaves zeros exactly like this.
                    if (!_afterEofMarker)
                        throw new InvalidDataException(
                            $"The BGZF data stops after block {_block - 1} without its end-of-file marker and is " +
                            "followed by bytes that are not BGZF: the file is truncated or damaged.");
                    _eof = true;
                    return false;
                }
                if (got < 12 || (_hdr[3] & 0x04) == 0) return HandOff(start);

                int xlen = _hdr[10] | (_hdr[11] << 8);
                _extra = EnsureCapacity(_extra, xlen);
                if (ReadUpTo(_base, _extra, 0, xlen) < xlen) throw Truncated();

                int bsize = -1;
                for (int i = 0; i + 3 < xlen;)
                {
                    int slen = _extra[i + 2] | (_extra[i + 3] << 8);
                    if (_extra[i] == 'B' && _extra[i + 1] == 'C' && slen == 2 && i + 5 < xlen)
                    {
                        bsize = _extra[i + 4] | (_extra[i + 5] << 8); // total block size - 1
                        break;
                    }
                    i += 4 + slen;
                }
                if (bsize < 0) return HandOff(start);

                int cdataLen = (bsize + 1) - 12 - xlen - 8; // minus header, extra, CRC32+ISIZE
                if (cdataLen < 0) throw new InvalidDataException($"Corrupt BGZF block {_block}: impossible block size.");
                _cdata = EnsureCapacity(_cdata, cdataLen);
                if (ReadUpTo(_base, _cdata, 0, cdataLen) < cdataLen) throw Truncated();
                if (ReadUpTo(_base, _trailer, 0, 8) < 8) throw Truncated();
                uint crc = U32(_trailer, 0);
                int isize = (int)U32(_trailer, 4);
                if (isize < 0 || isize > (1 << 16))
                    throw new InvalidDataException($"Corrupt BGZF block {_block}: uncompressed size {isize}.");
                _block++;

                if (isize == 0)
                {
                    // The EOF marker (or another empty block). It is checked like any block: a
                    // zeroed trailer in front of real data, or zeros where a block should be, must
                    // not pass as "nothing here".
                    if (crc != 0 || InflatesToSomething(cdataLen))
                        throw new InvalidDataException(
                            $"Corrupt BGZF block {_block - 1}: the data does not match its checksum.");
                    _afterEofMarker = true;
                    continue;
                }
                _afterEofMarker = false;

                _out = EnsureCapacity(_out, isize);
                int n = 0;
                using (var ms = new MemoryStream(_cdata, 0, cdataLen, false))
                using (var inflate = new DeflateStream(ms, CompressionMode.Decompress))
                {
                    while (n < isize)
                    {
                        int r = inflate.Read(_out, n, isize - n);
                        if (r == 0) break;
                        n += r;
                    }
                }
                if (n != isize || Crc32.Compute(_out, 0, n) != crc)
                    throw new InvalidDataException(
                        $"Corrupt BGZF block {_block - 1}: the data does not match its checksum.");
                _outLen = n;
                _outPos = 0;
                return true;
            }
        }

        /// <summary>True when the block's deflate data is not a valid empty stream.</summary>
        private bool InflatesToSomething(int cdataLen)
        {
            try
            {
                using (var ms = new MemoryStream(_cdata, 0, cdataLen, false))
                using (var inflate = new DeflateStream(ms, CompressionMode.Decompress))
                    return inflate.Read(new byte[1], 0, 1) != 0;
            }
            catch (InvalidDataException)
            {
                return true;
            }
        }

        /// <summary>
        /// The member at <paramref name="start"/> is gzip but not BGZF: read it and everything
        /// after it as ordinary gzip.
        /// </summary>
        private bool HandOff(long start)
        {
            if (start < 0)
                throw new InvalidDataException($"Block {_block} is not a BGZF block, and the input cannot be re-read as plain gzip.");
            _base.Position = start;
            _tail = new GzipMembersStream(_base);
            return false;
        }

        private InvalidDataException Truncated()
            => new InvalidDataException(
                $"The compressed file ends in the middle of BGZF block {_block}; it is truncated or damaged.");

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _tail?.Dispose();
                _base.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
