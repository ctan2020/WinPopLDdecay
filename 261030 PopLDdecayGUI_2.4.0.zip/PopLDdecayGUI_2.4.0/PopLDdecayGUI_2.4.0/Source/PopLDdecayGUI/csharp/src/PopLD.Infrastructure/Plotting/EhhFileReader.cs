using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace PopLD.Infrastructure.Plotting
{
    /// <summary>
    /// Reads an <c>.ehh.gz</c> file (Chr, Site, Dist, EHH_all, EHH_0, EHH_1) into a plottable
    /// series. Unlike LD decay, EHH is not binned — every SNP in the region is a point — and the
    /// curve spans both sides of the anchor, so X runs negative through positive.
    /// </summary>
    public static class EhhFileReader
    {
        /// <summary>Which EHH column to plot.</summary>
        public enum Track { All = 3, CoreAllele0 = 4, CoreAllele1 = 5 }

        /// <summary>
        /// A column kept for the export, read the same way on every runtime (a raw parse turns
        /// "1e309" into infinity on .NET 8 and into a refusal on .NET Framework): a finite number
        /// as written, NaN for a NaN, infinity or number too large for a double (exported as
        /// "nan"), and 0 for anything else ("NA", a missing column).
        /// </summary>
        private static double Col(string[] f, int i)
        {
            if (i >= f.Length) return 0;
            switch (StatFileBinner.Classify(f[i], out double v))
            {
                case StatFileBinner.FieldKind.Finite: return v;
                case StatFileBinner.FieldKind.NonFinite: return double.NaN;
                default: return 0;
            }
        }

        public static DecayPoints Read(string ehhGzPath, Track track = Track.All)
        {
            var inv = CultureInfo.InvariantCulture;
            var xs = new List<double>();
            var ys = new List<double>();
            var rows = new List<EhhRow>();   // kept verbatim so an export can rewrite *.ehh
            double maxY = 0, minX = 0, maxX = 0;
            bool first = true;
            int skipped = 0;
            int col = (int)track;

            // Gzipped or plain text (the reference's own *.ehh is plain); the content decides.
            using (var r = PopLD.Domain.IO.TextInput.OpenText(ehhGzPath, 1 << 16))
            {
                string line;
                while ((line = r.ReadLine()) != null)
                {
                    if (line.Length == 0 || line[0] == '#') continue;
                    string[] f = line.Split('\t');
                    if (f.Length <= col) continue;
                    if (!long.TryParse(f[2], NumberStyles.Integer, inv, out long dist)) continue;
                    // A NaN or infinity would be an invisible point; leave the row out and count
                    // it, as the stat-file binner does, reading the value the same way on every
                    // runtime ("nan", "inf" and a number too large for a double included).
                    var kind = StatFileBinner.Classify(f[col], out double y);
                    if (kind == StatFileBinner.FieldKind.Text) continue;
                    if (kind == StatFileBinner.FieldKind.NonFinite) { skipped++; continue; }

                    double xkb = dist / 1000.0;
                    xs.Add(xkb);
                    ys.Add(y);

                    long site;
                    long.TryParse(f[1], NumberStyles.Integer, inv, out site);
                    rows.Add(new EhhRow
                    {
                        Chrom = f[0],
                        Site = site,
                        Dist = dist,
                        All = Col(f, 3),
                        Allele0 = Col(f, 4),
                        Allele1 = Col(f, 5),
                    });
                    if (y > maxY) maxY = y;
                    if (first) { minX = maxX = xkb; first = false; }
                    else { if (xkb < minX) minX = xkb; if (xkb > maxX) maxX = xkb; }
                }
            }

            string label = track == Track.CoreAllele0 ? "EHH (core allele 0)"
                         : track == Track.CoreAllele1 ? "EHH (core allele 1)" : "EHH";
            return new DecayPoints
            {
                Name = Path.GetFileName(ehhGzPath),
                // Full path, not just the file name: two .ehh.gz with the same base name in
                // different folders are different sources, and the exporters name their output
                // from this so neither silently overwrites the other.
                SourcePath = ehhGzPath,
                XKb = xs.ToArray(),
                Y = ys.ToArray(),
                Measure = label,
                MinXKb = minX,
                MaxXKb = maxX,
                MaxY = maxY,
                XAxisLabel = "Distance from anchor site (kb)",
                EhhRows = rows.ToArray(),
                SkippedNonFinite = skipped,
            };
        }
    }
}
