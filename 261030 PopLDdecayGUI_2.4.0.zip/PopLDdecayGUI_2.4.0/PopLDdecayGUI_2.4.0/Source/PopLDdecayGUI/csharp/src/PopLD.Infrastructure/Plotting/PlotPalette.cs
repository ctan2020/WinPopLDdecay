namespace PopLD.Infrastructure.Plotting
{
    /// <summary>
    /// Series colors shared by every plot backend (WPF screen view, PNG export and the
    /// vector-PDF writer), so the same population always gets the same color everywhere.
    /// </summary>
    public static class PlotPalette
    {
        /// <summary>RGB triplets; index with <c>seriesIndex % Colors.Length</c>.</summary>
        public static readonly byte[][] Colors =
        {
            new byte[] { 0x6C, 0x63, 0xFF }, new byte[] { 0x00, 0xB8, 0x94 },
            new byte[] { 0xFF, 0x6B, 0x5B }, new byte[] { 0x33, 0x8E, 0xF7 },
            new byte[] { 0xF7, 0x93, 0x1E }, new byte[] { 0xC0, 0x3A, 0xB8 },
        };
    }
}
