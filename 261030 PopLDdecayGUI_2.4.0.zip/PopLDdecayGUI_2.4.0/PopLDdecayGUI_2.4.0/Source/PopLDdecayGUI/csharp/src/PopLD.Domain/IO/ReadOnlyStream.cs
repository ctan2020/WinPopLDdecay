using System;
using System.IO;

namespace PopLD.Domain.IO
{
    /// <summary>
    /// The forward-only readers' common part: they read and refuse everything else, and they fill
    /// buffers from streams that may return fewer bytes than asked for.
    /// </summary>
    public abstract class ReadOnlyStream : Stream
    {
        public override bool CanRead => true;
        public override bool CanSeek => false;
        public override bool CanWrite => false;
        public override long Length => throw new NotSupportedException();
        public override long Position { get => throw new NotSupportedException(); set => throw new NotSupportedException(); }
        public override void Flush() { }
        public override long Seek(long offset, SeekOrigin origin) => throw new NotSupportedException();
        public override void SetLength(long value) => throw new NotSupportedException();
        public override void Write(byte[] buffer, int offset, int count) => throw new NotSupportedException();

        /// <summary>Reads until <paramref name="count"/> bytes are in or <paramref name="s"/> ends; returns how many.</summary>
        internal static int ReadUpTo(Stream s, byte[] buf, int offset, int count)
        {
            int off = 0;
            while (off < count)
            {
                int r = s.Read(buf, offset + off, count - off);
                if (r == 0) break;
                off += r;
            }
            return off;
        }

        /// <summary>The little-endian unsigned 32-bit value at <paramref name="i"/> (gzip's CRC and ISIZE).</summary>
        internal static uint U32(byte[] b, int i)
            => (uint)(b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24));
    }
}
