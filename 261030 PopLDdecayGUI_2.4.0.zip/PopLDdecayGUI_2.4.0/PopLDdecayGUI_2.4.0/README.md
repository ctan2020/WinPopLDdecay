# PopLDdecayGUI 2.4.0

**English** ｜ [中文](#中文)

PopLDdecayGUI is a Windows reimplementation of PopLDdecay (Zhang et al.,
Bioinformatics 2019) with a graphical interface and a command-line program. It
computes and plots linkage disequilibrium (LD) decay directly from VCF files; on
diploid genotypes its default results are byte-identical to the original
PopLDdecay v3.45.

## 1. Contents

| Directory / file | Description |
| --- | --- |
| `Installer\` | the installer, `PopLDdecayGUI_Setup_2.4.0.exe` |
| `Manual\` | user manuals in Chinese and English, each as PDF and Word |
| `Source\` | the source code needed to build the installer (program sources and installer script) |
| `LICENSE` | the license (MIT) |
| `SHA256SUMS.txt` | SHA-256 checksums of every file in this package |

## 2. Requirements

- Windows 7 SP1 to Windows 11, 64-bit.
- .NET Framework 4.8: built into Windows 10/11; a one-time install on Windows 7/8.1.

## 3. Installing and uninstalling

Run `Installer\PopLDdecayGUI_Setup_2.4.0.exe` and follow the prompts. No administrator rights are needed.

Two programs are installed:

- `PopLDdecayGUI.exe` — the graphical interface
- `PopLDdecay.cli.exe` — the command line

See the user manual in `Manual\` for how to use them.

**To uninstall**: Windows Settings > Apps > PopLDdecayGUI > Uninstall.

## 4. Building the installer from source

**Requires** the .NET SDK 8 or later, the .NET Framework 4.8 targeting pack and Inno Setup 6.

Unzip to a short path (e.g. `D:\PopLDdecayGUI_2.4.0`) so that the build stays within the Windows 260-character path limit.

1. **Build the programs**: in `Source\PopLDdecayGUI\csharp` run

   ```bash
   dotnet build PopLDdecay.sln -c Release
   ```

2. **Build the installer**: compile `Source\PopLDdecayGUI\installer\PopLDdecayGUI.iss`
   with Inno Setup 6; the installer is written to
   `Source\PopLDdecayGUI\installer\output\`.

The build downloads no packages.

## 5. Citation

If you publish results obtained with this software, please cite the original PopLDdecay:

> Zhang C, Dong S-S, Xu J-Y, He W-M, Yang T-L. PopLDdecay: a fast and effective tool
> for linkage disequilibrium decay analysis based on variant call format files.
> Bioinformatics. 2019;35(10):1786-1788. doi:10.1093/bioinformatics/bty875

## 6. License

MIT License; see `LICENSE`, which also carries the original PopLDdecay's MIT notice.

---

## 中文

PopLDdecayGUI 是 PopLDdecay（Zhang et al., Bioinformatics 2019）的 Windows 版重写，
带图形界面，并附命令行程序。它直接从 VCF 文件计算连锁不平衡（LD）衰减并作图；
对二倍体基因型，默认结果与原版 PopLDdecay v3.45 逐字节一致。

### 一、包内内容

| 目录 / 文件 | 说明 |
| --- | --- |
| `Installer\` | 安装程序 `PopLDdecayGUI_Setup_2.4.0.exe` |
| `Manual\` | 使用说明：中文、英文，各有 PDF 和 Word 两种格式 |
| `Source\` | 编译安装程序所需的源代码（程序源码与安装脚本） |
| `LICENSE` | 许可证（MIT） |
| `SHA256SUMS.txt` | 包内各文件的 SHA-256 校验值 |

### 二、系统要求

- Windows 7 SP1 至 Windows 11，64 位。
- .NET Framework 4.8：Windows 10/11 已自带；Windows 7/8.1 需先安装一次。

### 三、安装与卸载

运行 `Installer\PopLDdecayGUI_Setup_2.4.0.exe`，按提示完成即可，不需要管理员权限。

安装后有两个程序：

- `PopLDdecayGUI.exe` —— 图形界面
- `PopLDdecay.cli.exe` —— 命令行程序

使用方法见 `Manual\` 中的使用说明。

**卸载**：Windows 设置 → 应用，找到 PopLDdecayGUI 后卸载。

### 四、从源码编译安装程序

**需要**：.NET SDK 8 或更新版本、.NET Framework 4.8 开发包（targeting pack）、Inno Setup 6。

请解压到路径较短的位置（如 `D:\PopLDdecayGUI_2.4.0`），以免超出 Windows 260 字符的路径长度限制。

1. **编译程序**：在 `Source\PopLDdecayGUI\csharp` 目录下运行

   ```bash
   dotnet build PopLDdecay.sln -c Release
   ```

2. **生成安装程序**：用 Inno Setup 6 编译 `Source\PopLDdecayGUI\installer\PopLDdecayGUI.iss`，
   安装程序输出到 `Source\PopLDdecayGUI\installer\output\`。

编译不需要从网上下载任何程序包。

### 五、引用

使用本软件发表结果时，请引用原版 PopLDdecay：

> Zhang C, Dong S-S, Xu J-Y, He W-M, Yang T-L. PopLDdecay: a fast and effective tool
> for linkage disequilibrium decay analysis based on variant call format files.
> Bioinformatics. 2019;35(10):1786-1788. doi:10.1093/bioinformatics/bty875

### 六、许可证

MIT 许可证，见 `LICENSE`。其中也附有原版 PopLDdecay 的 MIT 许可声明。
