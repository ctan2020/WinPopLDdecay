; PopLDdecayGUI (C# / .NET Framework 4.8) Inno Setup script
; Payload = the Release net48 build (exe + 4 DLLs + config). No Qt, no Python.

#define MyAppName "PopLDdecayGUI"
#define MyAppVersion "2.4.0"
#define MyAppPublisher "BGI-Shenzhen"
#define MyAppExeName "PopLDdecayGUI.exe"
; The PopLDdecayGUI folder, from where this script lies, so the build does not depend on a drive path.
#define Root       AddBackslash(SourcePath) + ".."
#define ReleaseDir Root + "\csharp\src\PopLD.App\bin\Release\net48"
#define CliDir     Root + "\csharp\src\PopLD.Cli\bin\Release\net48"

[Setup]
AppId={{F1E2D3C4-B5A6-4790-9C8D-2E3F4A5B6C7D}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
OutputDir={#Root}\installer\output
OutputBaseFilename=PopLDdecayGUI_Setup_{#MyAppVersion}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile={#Root}\csharp\src\PopLD.App\Assets\app.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"

[Files]
; The whole Release folder, but skip debug symbols.
Source: "{#ReleaseDir}\*"; DestDir: "{app}"; Excludes: "*.pdb"; Flags: ignoreversion recursesubdirs createallsubdirs
; The headless CLI, so the command line documented in the manual works from an install
; rather than only from a source build. Only the executable and its runtime config: it is
; built from the same solution and loads the four DLLs above, byte-identical copies of which
; its own output folder already carries.
Source: "{#CliDir}\PopLDdecay.cli.exe";        DestDir: "{app}"; Flags: ignoreversion
Source: "{#CliDir}\PopLDdecay.cli.exe.config"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Run {#MyAppName}"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
Type: dirifempty; Name: "{app}"

[Code]
function IsDotNet48OrLater(): Boolean;
var
  release: Cardinal;
begin
  Result := False;
  if RegQueryDWordValue(HKLM, 'SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full', 'Release', release) then
    Result := (release >= 528040); // 528040 = .NET Framework 4.8
end;

function InitializeSetup(): Boolean;
begin
  Result := True;
  if not IsDotNet48OrLater() then
  begin
    if MsgBox('This program needs Microsoft .NET Framework 4.8.' + #13#10 +
              'It is preinstalled on Windows 10/11; on Windows 7 SP1 you must install it once' + #13#10 +
              '(https://dotnet.microsoft.com/download/dotnet-framework/net48).' + #13#10 + #13#10 +
              'Continue with installation anyway?', mbConfirmation, MB_YESNO) = IDNO then
      Result := False;
  end;
end;
