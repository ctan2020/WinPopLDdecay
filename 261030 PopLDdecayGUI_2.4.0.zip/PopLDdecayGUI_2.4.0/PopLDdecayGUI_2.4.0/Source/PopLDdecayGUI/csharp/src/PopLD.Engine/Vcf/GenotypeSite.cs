namespace PopLD.Engine.Vcf
{
    /// <summary>
    /// One retained biallelic SNP site after filtering. <see cref="Alleles"/> holds one
    /// entry per haplotype (2 per sample for phased data), encoded exactly as the original
    /// PopLDdecay: 0 = major allele, 1 = minor allele, 2 = missing / other.
    /// </summary>
    public sealed class GenotypeSite
    {
        public string Chrom;
        public long Pos;
        public byte[] Alleles;

        public GenotypeSite(string chrom, long pos, byte[] alleles)
        {
            Chrom = chrom;
            Pos = pos;
            Alleles = alleles;
        }
    }

    /// <summary>Counters describing what the reader kept and discarded (for logging/provenance).</summary>
    public sealed class ReaderStats
    {
        public int Kept;
        public int SkippedIndelOrSv;
        public int SkippedMiss;
        public int SkippedHet;
        public int SkippedMaf;
        public int SkippedMonoOrMulti;
        /// <summary>Malformed records: fewer sample columns than the header declares, a kept
        /// sample column that is empty, or fewer than the ten columns of a VCF record.</summary>
        public int SkippedShortLine;
        /// <summary>Kept records whose POS is not a plain number. They are read as the original
        /// reads them — its leading digits, or 0 when there are none — and counted here so the
        /// run can say so.</summary>
        public int MalformedPos;
        public int SampleCount;
    }
}
