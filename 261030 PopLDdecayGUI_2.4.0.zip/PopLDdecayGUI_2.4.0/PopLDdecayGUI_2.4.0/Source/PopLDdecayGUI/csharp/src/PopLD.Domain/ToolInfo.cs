using System.Reflection;

namespace PopLD.Domain
{
    /// <summary>
    /// The single place the tool's version is read from. It comes off the assembly, which
    /// Directory.Build.props stamps, so a release bump cannot leave a stale literal behind in
    /// the provenance records.
    /// </summary>
    public static class ToolInfo
    {
        /// <summary>Three-part version, e.g. "2.4.0".</summary>
        public static readonly string Version = Read();

        private static string Read()
        {
            var v = typeof(ToolInfo).Assembly.GetName().Version;
            return v == null ? "0.0.0" : v.Major + "." + v.Minor + "." + v.Build;
        }
    }
}
