using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace PopLD.Domain.IO
{
    /// <summary>
    /// What makes two paths the same file, and what tells a file's content has changed, beyond
    /// its name, size and modification time.
    /// <list type="bullet">
    /// <item><see cref="SameFile"/>: the same full path, or — on Windows, for files that exist —
    /// the same volume and file index, so a hard link, an 8.3 short name or a different spelling
    /// of the path is recognised as the file it is.</item>
    /// <item><see cref="ChangeStamp"/>: NTFS's change time, which the file system sets whenever
    /// the content (or any other metadata) is written, including when a tool resets the
    /// modification time afterwards. Ordinary tools cannot set it back.</item>
    /// </list>
    /// Elsewhere (no Windows, FAT/exFAT volumes, some network shares) both fall back to what the
    /// path, size and modification time tell.
    /// </summary>
    public static class FileIdentity
    {
        /// <summary>True when the two paths name the same file.</summary>
        public static bool SameFile(string a, string b)
        {
            if (string.IsNullOrEmpty(a) || string.IsNullOrEmpty(b)) return false;
            string fa, fb;
            try { fa = Path.GetFullPath(a); fb = Path.GetFullPath(b); }
            catch (Exception) { return false; }
            if (string.Equals(fa, fb, StringComparison.OrdinalIgnoreCase)) return true;
            var ia = FileId(fa);
            var ib = ia == null ? null : FileId(fb);
            return ia != null && ib != null && ia.Value.Equals(ib.Value);
        }

        /// <summary>
        /// The first output that is also one of the inputs, as "output" and "input" paths, or
        /// null when there is none. A run must never replace a file it was given to read.
        /// </summary>
        public static Tuple<string, string> FindConflict(IEnumerable<string> outputs, IEnumerable<string> inputs)
        {
            var ins = new List<string>();
            foreach (var i in inputs) if (!string.IsNullOrEmpty(i)) ins.Add(i);
            foreach (var o in outputs)
            {
                if (string.IsNullOrEmpty(o)) continue;
                foreach (var i in ins)
                    if (SameFile(o, i)) return Tuple.Create(o, i);
            }
            return null;
        }

        /// <summary>
        /// The file's change time as a number, or null when the file system does not keep one or
        /// it cannot be read. Part of a cache identity: two different values mean the file was
        /// written in between, whatever its modification time says.
        /// </summary>
        public static string ChangeStamp(string path)
        {
            if (!IsWindows) return null;
            try
            {
                using (var h = OpenForAttributes(path))
                {
                    if (h == null) return null;
                    if (!GetFileInformationByHandleEx(h, FileBasicInfoClass, out FileBasicInfo info,
                            Marshal.SizeOf(typeof(FileBasicInfo))))
                        return null;
                    return info.ChangeTime == 0 ? null : info.ChangeTime.ToString(System.Globalization.CultureInfo.InvariantCulture);
                }
            }
            catch (Exception ex) when (ex is DllNotFoundException || ex is EntryPointNotFoundException ||
                                       ex is IOException || ex is UnauthorizedAccessException)
            {
                return null;
            }
        }

        private struct Id : IEquatable<Id>
        {
            public uint Volume;
            public ulong Index;
            public bool Equals(Id other) => Volume == other.Volume && Index == other.Index;
            public override bool Equals(object obj) => obj is Id other && Equals(other);
            public override int GetHashCode() => (int)Volume ^ Index.GetHashCode();
        }

        private static Id? FileId(string path)
        {
            if (!IsWindows || !File.Exists(path)) return null;
            try
            {
                using (var h = OpenForAttributes(path))
                {
                    if (h == null || !GetFileInformationByHandle(h, out ByHandleFileInformation info)) return null;
                    return new Id { Volume = info.VolumeSerialNumber, Index = ((ulong)info.FileIndexHigh << 32) | info.FileIndexLow };
                }
            }
            catch (Exception ex) when (ex is DllNotFoundException || ex is EntryPointNotFoundException)
            {
                return null;
            }
        }

        private static bool IsWindows => Environment.OSVersion.Platform == PlatformID.Win32NT;

        /// <summary>
        /// A handle that may read attributes only. Such an open neither needs read permission on
        /// the content nor conflicts with another program holding the file exclusively.
        /// </summary>
        private static SafeFileHandle OpenForAttributes(string path)
        {
            var h = CreateFileW(path, FileReadAttributes, ShareAll, IntPtr.Zero, OpenExisting, BackupSemantics, IntPtr.Zero);
            if (h.IsInvalid) { h.Dispose(); return null; }
            return h;
        }

        private const uint FileReadAttributes = 0x80;
        private const uint ShareAll = 0x1 | 0x2 | 0x4;      // read | write | delete
        private const uint OpenExisting = 3;
        private const uint BackupSemantics = 0x02000000;    // also opens a directory; harmless here
        private const int FileBasicInfoClass = 0;

        [StructLayout(LayoutKind.Sequential)]
        private struct FileBasicInfo
        {
            public long CreationTime, LastAccessTime, LastWriteTime, ChangeTime;
            public uint FileAttributes;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct ByHandleFileInformation
        {
            public uint FileAttributes;
            public uint CreationLow, CreationHigh, AccessLow, AccessHigh, WriteLow, WriteHigh;
            public uint VolumeSerialNumber, FileSizeHigh, FileSizeLow, NumberOfLinks, FileIndexHigh, FileIndexLow;
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        private static extern SafeFileHandle CreateFileW(string name, uint access, uint share, IntPtr security,
            uint creation, uint flags, IntPtr template);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetFileInformationByHandleEx(SafeFileHandle file, int infoClass,
            out FileBasicInfo info, int size);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetFileInformationByHandle(SafeFileHandle file, out ByHandleFileInformation info);
    }
}
