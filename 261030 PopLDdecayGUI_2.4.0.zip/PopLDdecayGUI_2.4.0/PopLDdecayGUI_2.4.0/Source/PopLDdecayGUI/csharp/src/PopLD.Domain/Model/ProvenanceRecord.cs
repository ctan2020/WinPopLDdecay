namespace PopLD.Domain.Model
{
    /// <summary>
    /// One append-only reproducibility record: enough to reproduce a run exactly and to audit
    /// what produced a given result file.
    /// </summary>
    public sealed class ProvenanceRecord
    {
        public string TimestampUtc;
        public string ToolVersion;
        public string CacheKey;
        public string Inputs;       // canonical input identity (path|size|mtime; subpop)
        public string Parameters;   // canonical parameter string
        public string OutputPath;
        public long PairsEvaluated;
        public int DegreeOfParallelism;
        public double ElapsedSeconds;
        public bool CacheHit;
    }
}
