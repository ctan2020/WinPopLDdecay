using System;

namespace PopLD.Engine
{
    /// <summary>
    /// Maximum-likelihood two-locus haplotype frequencies from unphased genotypes.
    /// <para>Every two-locus genotype except the double heterozygote fixes its two haplotypes,
    /// so the likelihood has a single free parameter: how many of the <c>h</c> double
    /// heterozygotes carry 11/00 (coupling) rather than 10/01 (repulsion). Calling that number
    /// <c>u</c>, the haplotype counts are F11 = k11+u, F00 = k00+u, F10 = k10+h-u, F01 = k01+h-u,
    /// and the EM fixed point u·F10·F01 = (h-u)·F11·F00 — whose interior solutions are exactly the
    /// stationary points of the likelihood — is a cubic in u. This finds the roots of that cubic
    /// in [0, h] that are local maxima and keeps the higher, so the estimate is the global
    /// maximum rather than wherever an iteration happened to stop.</para>
    /// </summary>
    public static class HaplotypeMle
    {
        /// <summary>
        /// The maximum-likelihood number of double heterozygotes in coupling phase, in [0, h].
        /// <paramref name="k11"/>..<paramref name="k00"/> are the haplotypes the other genotypes
        /// determine (1 = minor allele, first digit = first site).
        /// </summary>
        public static double CoupledDoubleHets(long k11, long k10, long k01, long k00, long h)
        {
            if (h <= 0) return 0.0;
            double c11 = k11, c10 = k10, c01 = k01, c00 = k00, H = h;

            // f(u) = 2u^3 + a2 u^2 + a1 u + a0, with f(0) = -h·k11·k00 <= 0 and f(h) = h·k10·k01 >= 0.
            // Along u the log-likelihood L obeys dL/du = -f(u)·S(u)/D(u) exactly, where
            // S = 1/F11 + 1/F00 + 1/F10 + 1/F01 > 0 and D = F11·F00 + F10·F01 > 0 (Fisher's identity on
            // the EM complete-data likelihood). So L rises where f < 0 and falls where f > 0: its local
            // maxima are exactly the roots where f rises through zero, and because f(0) <= 0 <= f(h)
            // the maximum over [0, h] is always one of them. With one such root it is the estimate;
            // with two (a cubic crosses zero upwards at most twice) the likelihood decides.
            double a2 = c11 + c00 - c10 - c01 - 3.0 * H;
            double a1 = (c10 + H) * (c01 + H) + c11 * c00 - H * (c11 + c00);
            double a0 = -H * c11 * c00;

            // Cut [0, h] at the cubic's turning points, so f is monotone on every piece and each
            // piece holds at most one root.
            double t1 = double.NaN, t2 = double.NaN;
            double disc = a2 * a2 - 6.0 * a1;            // f'(u) = 6u^2 + 2a2 u + a1
            if (disc > 0)
            {
                double s = Math.Sqrt(disc);
                t1 = (-a2 - s) / 6.0;
                t2 = (-a2 + s) / 6.0;
            }

            // Collect the rising roots (a cubic crosses zero upwards at most twice). The end values
            // are taken in closed form (exact in double for any realistic sample size): when
            // k10·k01 = 0 the root sits at u = h exactly, and Horner's rounding could otherwise push
            // f(h) just below zero.
            double r0 = 0, r1 = 0;
            int roots = 0;
            // Newton's starting guess: one EM step from u = h/2. Most pairs are near linkage
            // equilibrium, where the root is close to h/2 and this step lands almost on it.
            double m = 0.5 * H;
            double cpl = (c11 + m) * (c00 + m), rep = (c10 + m) * (c01 + m);
            double start = cpl + rep > 0 ? H * cpl / (cpl + rep) : m;
            double lo = 0.0, flo = a0;
            for (int piece = 0; piece < 3; piece++)
            {
                double hi = piece == 0 ? t1 : piece == 1 ? t2 : H;
                if (piece < 2 && !(hi > lo && hi < H)) continue;   // turning point outside (lo, h)
                double fhi = piece == 2 ? H * c10 * c01 : Cubic(hi, a2, a1, a0);

                // f is monotone on [lo, hi]; only a rising piece can hold a candidate root.
                if (fhi > flo)
                {
                    double root = double.NaN;
                    if (flo == 0.0) root = lo;
                    else if (fhi == 0.0) { if (piece == 2) root = hi; }   // an inner hi is the next lo
                    else if (flo < 0.0 && fhi > 0.0) root = Bracketed(lo, hi, start, a2, a1, a0);

                    if (!double.IsNaN(root))
                    {
                        if (roots == 0) r0 = root; else r1 = root;
                        roots++;
                    }
                }
                lo = hi; flo = fhi;
            }
            // f(0) <= 0 <= f(h) guarantees a rising root; this only guards against rounding at a
            // turning point.
            if (roots == 0) return a0 >= 0.0 ? 0.0 : H;
            if (roots == 1) return r0;

            // Two local maxima (rare): compare their likelihoods.
            double best = double.NaN, bestLl = double.NegativeInfinity, bestAbsD = double.PositiveInfinity;
            Consider(r0, c11, c10, c01, c00, H, ref best, ref bestLl, ref bestAbsD);
            Consider(r1, c11, c10, c01, c00, H, ref best, ref bestLl, ref bestAbsD);
            return best;
        }

        private static double Cubic(double u, double a2, double a1, double a0)
            => ((2.0 * u + a2) * u + a1) * u + a0;

        /// <summary>
        /// The root of a rising piece [lo, hi] (f(lo) &lt; 0 &lt; f(hi)): Newton steps from
        /// <paramref name="start"/> (the midpoint if it lies outside the piece), falling back to
        /// bisection whenever a step would leave the bracket. Newton converges quadratically, so
        /// a last Newton step below 1e-7 of u leaves an error near 1e-14 of u. A bisection step
        /// says nothing about the error beyond the bracket's width, so after one the search only
        /// stops once the bracket itself is that narrow.
        /// </summary>
        private static double Bracketed(double lo, double hi, double start, double a2, double a1, double a0)
        {
            double u = start > lo && start < hi ? start : 0.5 * (lo + hi);
            for (int it = 0; it < 200; it++)
            {
                double f = Cubic(u, a2, a1, a0);
                if (f == 0.0) return u;
                if (f < 0.0) lo = u; else hi = u;
                double d = (6.0 * u + 2.0 * a2) * u + a1;
                double next = d != 0.0 ? u - f / d : double.NaN;
                double scale = Math.Max(1.0, Math.Abs(u));
                if (next > lo && next < hi)
                {
                    if (Math.Abs(next - u) <= 1e-7 * scale) return next;
                }
                else
                {
                    next = 0.5 * (lo + hi);
                    if (hi - lo <= 1e-13 * scale) return next;
                }
                u = next;
            }
            return u;
        }

        /// <summary>
        /// Keeps <paramref name="u"/> if its likelihood beats the best so far. Two likelihoods
        /// equal to rounding are settled towards the smaller |D|, so a tie never invents LD; when
        /// |D| ties as well (every sample a double heterozygote: u = 0 and u = h mirror each
        /// other) the first root, the smaller u, is kept — r^2 and |D'| are the same for both.
        /// </summary>
        private static void Consider(double u, double c11, double c10, double c01, double c00, double h,
            ref double best, ref double bestLl, ref double bestAbsD)
        {
            double f11 = c11 + u, f00 = c00 + u, f10 = c10 + h - u, f01 = c01 + h - u;
            double ll = 0.0;
            // 0·log(0) is 0 here: a haplotype nobody is known to carry adds nothing.
            if (c11 > 0) ll += c11 * Math.Log(f11);
            if (c00 > 0) ll += c00 * Math.Log(f00);
            if (c10 > 0) ll += c10 * Math.Log(f10);
            if (c01 > 0) ll += c01 * Math.Log(f01);
            ll += h * Math.Log(f11 * f00 + f10 * f01);
            double absD = Math.Abs(f11 * f00 - f10 * f01);

            double tol = 1e-9 * Math.Max(1.0, Math.Abs(ll));
            if (double.IsNaN(best) || ll > bestLl + tol || (ll >= bestLl - tol && absD < bestAbsD))
            {
                best = u; bestLl = ll; bestAbsD = absD;
            }
        }
    }
}
