using System;
using System.Globalization;
using System.IO;
using PopLD.Domain.IO;
using PopLD.Domain.Services;

namespace PopLD.Infrastructure.Io
{
    /// <summary>
    /// The output names the GUI gives its results. A result is named after the VCF (less
    /// .vcf/.vcf.gz) and the sample list's file name, so different inputs can share a name:
    /// <c>a.vcf</c> and <c>a.vcf.gz</c> in one folder, or <c>pop1.txt</c> in two folders. A result
    /// already at a name is replaced only when its provenance record shows the same VCF and the
    /// same list, or no list for both (a re-run); otherwise — other inputs, or no record to tell —
    /// "_2", "_3", … is appended instead of overwriting it.
    /// </summary>
    public static class ResultNaming
    {
        /// <summary>The prefix (…<c>.LDdecay</c>) for one input's result in <paramref name="dir"/>.</summary>
        public static string PrefixFor(string dir, string baseName, bool ehh, string vcf, string sampleList)
        {
            string prefix = Path.Combine(dir, baseName + ".LDdecay");
            // No upper limit: the search ends at the first free name or at this input's own
            // earlier result, and a folder holds finitely many files. With a fixed limit the last
            // candidate would be handed back unchecked — and overwritten.
            for (long k = 2; ; k++)
            {
                string result = OutputPaths.ResultFor(prefix, ehh);
                if (!File.Exists(result) || SameInputs(OutputPaths.ProvenanceFor(result), vcf, sampleList)) return prefix;
                prefix = Path.Combine(dir, baseName + "_" + k.ToString(CultureInfo.InvariantCulture) + ".LDdecay");
            }
        }

        /// <summary>True when the provenance record names this VCF and this sample list (or none).</summary>
        public static bool SameInputs(string sidecar, string vcf, string sampleList)
        {
            string input = null, list = null;
            try
            {
                if (!File.Exists(sidecar)) return false;
                foreach (var line in File.ReadAllLines(sidecar))
                {
                    if (line.StartsWith("input\t", StringComparison.Ordinal)) input = line.Substring("input\t".Length);
                    else if (line.StartsWith("sampleList\t", StringComparison.Ordinal)) list = line.Substring("sampleList\t".Length);
                }
            }
            catch (IOException) { return false; }
            catch (UnauthorizedAccessException) { return false; }
            if (input == null || !FileIdentity.SameFile(input, vcf)) return false;
            return string.IsNullOrEmpty(list) ? string.IsNullOrEmpty(sampleList)
                                              : !string.IsNullOrEmpty(sampleList) && FileIdentity.SameFile(list, sampleList);
        }
    }
}
