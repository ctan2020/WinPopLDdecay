using PopLD.Domain.Model;

namespace PopLD.Domain.Abstractions
{
    /// <summary>Append-only reproducibility ledger (file-based, no database).</summary>
    public interface IProvenanceLedger
    {
        /// <summary>Appends a record and returns its provenance id.</summary>
        string Append(ProvenanceRecord record);
    }
}
