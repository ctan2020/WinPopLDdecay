namespace PopLD.Domain.Model
{
    /// <summary>
    /// The settings an analysis actually runs with, as the engine settles them from the request
    /// and the first record of its input. Options that cannot change this input's numbers are
    /// reset to their defaults: a phased VCF is read as haplotypes, so the unphased estimator does
    /// not apply; ignoring the phase of a VCF that has none changes nothing; EHH never uses the
    /// estimator. Callers key caches and name outputs on these, so a setting without effect never
    /// forces a recomputation or a second result file.
    /// </summary>
    public sealed class EffectiveSettings
    {
        /// <summary>The request's parameters with the no-effect options reset to their defaults.</summary>
        public AnalysisParameters Parameters { get; set; }

        /// <summary>True when the genotypes are read as phased haplotypes.</summary>
        public bool ReadAsPhased { get; set; }

        /// <summary>
        /// Where the LD values come from: "phased haplotypes", "PopLDdecay rule (unphased)" or
        /// "maximum likelihood (unphased)"; null for EHH, which is not an LD-decay estimate.
        /// </summary>
        public string LdEstimator { get; set; }

        /// <summary>
        /// The "warning: …" progress line for an option the request asked for that has no effect
        /// on this input (the unphased estimator on a phased VCF), or null. It belongs to the
        /// request, not to the input: the cache key leaves such options out, so one cached result
        /// serves requests with and without them, and a cache hit reports this line itself.
        /// </summary>
        public string IgnoredOptionWarning { get; set; }
    }
}
