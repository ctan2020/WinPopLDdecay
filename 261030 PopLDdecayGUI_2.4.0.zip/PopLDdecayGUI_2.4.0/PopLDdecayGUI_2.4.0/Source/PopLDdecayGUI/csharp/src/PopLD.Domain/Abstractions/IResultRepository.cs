using PopLD.Domain.Model;

namespace PopLD.Domain.Abstractions
{
    /// <summary>
    /// Persistence of results in the original on-disk file formats (no database).
    /// Also the seam where the file-based CAIR cache and provenance ledger will hook in.
    /// </summary>
    public interface IResultRepository
    {
        /// <summary>Records run provenance (params, input hashes, version) beside the result.</summary>
        void WriteProvenance(AnalysisRequest request, AnalysisResult result);
    }
}
