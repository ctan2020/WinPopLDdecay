using System;
using System.Collections.Generic;
using System.Globalization;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using PopLD.Core.Services;
using PopLD.Domain.Abstractions;
using PopLD.Domain.Model;
using System.IO;
using PopLD.Engine;
using PopLD.Engine.Vcf;
using PopLD.Infrastructure.Caching;
using PopLD.Infrastructure.Io;
using PopLD.Infrastructure.Plotting;
using PopLD.Infrastructure.Provenance;

namespace PopLD.Cli
{
    /// <summary>
    /// Anything the user got wrong on the command line. Carried as an exception so every
    /// parse site can refuse with one line and still leave through a single exit path.
    /// </summary>
    internal sealed class CliArgumentException : Exception
    {
        public CliArgumentException(string message) : base(message) { }
    }

    /// <summary>
    /// Headless entry point (mirrors the original --cli-run mode) so analyses can run
    /// in scripts, on clusters and in reproducibility experiments without the GUI.
    /// </summary>
    internal static class Program
    {
        // Exit codes. The original returns 1 for every argument error (LD_Decay.cpp:272-277);
        // we keep a distinct code for it so a script can tell "you typed it wrong" from
        // "the analysis ran and failed".
        private const int ExitOk = 0;
        private const int ExitFailed = 1;
        private const int ExitUsage = 2;

        // Option tables. The original parses a closed table and stops with
        // "UnKnow argument -<flag>" on anything else (LD_Decay.cpp:218-222, main then returns 1),
        // so a typo can never run silently at defaults. Same contract here: each mode declares
        // what it takes and ParseArgs refuses the rest.
        private static readonly string[] AnalysisValueArgs =
        {
            "--vcf", "--out", "--subpop", "--maxdist", "--maf", "--het", "--miss",
            "--outtype", "--ehh", "--dop", "--block", "--unphased",
        };
        private static readonly string[] AnalysisFlagArgs = { "--no-cache", "--deterministic", "--ignore-phase" };

        private static readonly string[] PlotValueArgs =
        {
            "--plotout", "--measure", "--bin1", "--bin2", "--break", "--maxx", "--w", "--h",
        };
        private static readonly string[] NoFlagArgs = new string[0];

        private static async Task<int> Main(string[] args)
        {
            Console.WriteLine("PopLDdecay " + PopLD.Domain.ToolInfo.Version + " (C#/.NET) - CLI");
            if (args.Length == 0)
            {
                PrintUsage();
                return ExitOk;
            }

            try
            {
                return await RunAsync(args).ConfigureAwait(false);
            }
            catch (CliArgumentException ex)
            {
                Console.Error.WriteLine("error: " + ex.Message);
                Console.Error.WriteLine("run 'PopLDdecay.cli --help' for the accepted arguments.");
                return ExitUsage;
            }
            catch (Exception ex)
            {
                // EVERY mode leaves through here, so a corrupt input, a locked output or any
                // other run-time failure ends as one line on stderr plus ExitFailed — never a
                // stack trace, and never the CLR's own exit code, whichever mode raised it.
                // The reference reports its run-time failures the same way, with cerr and a
                // non-zero return (FileDeal.h "Can't open the file", LD_Decay.cpp's exits).
                Console.Error.WriteLine(ModeName(args) + " failed: " + Describe(ex));
                return ExitFailed;
            }
        }

        /// <summary>Names the mode a failure came out of, for the one-line report on stderr.</summary>
        private static string ModeName(string[] args)
        {
            switch (args[0].ToLowerInvariant())
            {
                case "--scan": return "--scan";
                case "--binn": return "--binn";
                case "--plot": return "--plot";
                default: return "run";
            }
        }

        /// <summary>
        /// Flattens an exception to one line: its message plus any inner message it does not
        /// already contain. A wrapper's text ("Error in the application") names nothing the user
        /// can act on; the cause underneath it does.
        /// </summary>
        private static string Describe(Exception ex)
        {
            string text = ex.Message;
            for (Exception inner = ex.InnerException; inner != null; inner = inner.InnerException)
                if (inner.Message.Length > 0 && text.IndexOf(inner.Message, StringComparison.Ordinal) < 0)
                    text += " -- " + inner.Message;
            return text;
        }

        private static async Task<int> RunAsync(string[] args)
        {
            switch (args[0].ToLowerInvariant())
            {
                case "--help":
                case "-help":
                case "-h":
                case "-?":
                case "/?":
                    PrintUsage();
                    return ExitOk;
                case "--scan":
                    return ScanMode(args);
                case "--binn":
                    return BinnMode(args);
                case "--plot":
                    return Plot(args);
                case "--author-info":
                    return AuthorInfo();
            }

            return await AnalyseAsync(args).ConfigureAwait(false);
        }

        /// <summary>
        /// Reports who this build is attributed to, and whether that attribution still verifies
        /// against the public key compiled beside it.
        /// <para>Deliberately absent from <see cref="PrintUsage"/>: it answers a question about
        /// the build rather than about an analysis, and nothing the tool writes depends on it —
        /// no result file carries any of this.</para>
        /// </summary>
        private static int AuthorInfo()
        {
            Console.WriteLine("author      " + PopLD.Domain.Integrity.Authorship.Author);
            Console.WriteLine("key         P-256 " + PopLD.Domain.Integrity.Authorship.KeyFingerprint);
            Console.WriteLine("statement   " + PopLD.Domain.Integrity.Authorship.Statement);

            bool ok = PopLD.Domain.Integrity.Authorship.Verify();
            Console.WriteLine("signature   " + (ok ? "valid" : "INVALID"));
            if (ok) return ExitOk;

            // The name and the signature are checked against each other, so a mismatch means the
            // constants were edited rather than that the answer is different.
            Console.Error.WriteLine(
                "the shipped signature does not verify against the shipped public key -- this build has been altered.");
            return ExitFailed;
        }

        /// <summary>The original's main mode: filter a VCF and write the stat (or EHH) file.</summary>
        private static async Task<int> AnalyseAsync(string[] rawArgs)
        {
            Args args = ParseArgs(rawArgs, 0, AnalysisValueArgs, AnalysisFlagArgs);

            // The original refuses to start without an input ("lack argument for the must",
            // LD_Decay.cpp:225-229). Our --out keeps a default, but the input cannot be guessed.
            string vcf = args.Get("--vcf");
            if (string.IsNullOrEmpty(vcf))
                throw new CliArgumentException(
                    "--vcf <file> is required (use --plot to draw an existing .stat.gz).");

            string subpop = args.Get("--subpop");
            string outPrefix = args.Get("--out") ?? "out";

            var parameters = new AnalysisParameters();
            // Ranges and number syntax are shared with the GUI (ParameterRules): -MAF/-Het/-Miss
            // are compared against ratios in the reference's filters and a minor-allele frequency
            // cannot exceed 0.5, so values outside them can only ever discard every SNP.
            parameters.MaxDistKb = IntArg(args, "--maxdist", parameters.MaxDistKb,
                ParameterRules.MaxDistKbMin, ParameterRules.MaxDistKbMax);
            parameters.Maf = DoubleArg(args, "--maf", parameters.Maf, ParameterRules.MafMin, ParameterRules.MafMax);
            parameters.Het = DoubleArg(args, "--het", parameters.Het, ParameterRules.HetMin, ParameterRules.HetMax);
            parameters.Miss = DoubleArg(args, "--miss", parameters.Miss, ParameterRules.MissMin, ParameterRules.MissMax);
            parameters.OutType = OutTypeArg(args, parameters.OutType);
            parameters.UnphasedEstimator = UnphasedArg(args, parameters.UnphasedEstimator);
            parameters.IgnorePhase = args.Has("--ignore-phase");

            // -EHH takes chr:site. There EHH runs whatever -OutType says (LD_Decay.cpp:341-347),
            // so here too the flag alone selects the mode. The whole anchor is checked here, with
            // the parser the service and the engine use, so every malformed anchor is a usage
            // error (exit 2) before any input is read.
            string ehh = args.Get("--ehh");
            if (ehh != null)
            {
                if (!PopLD.Domain.Services.SiteParser.TryParse(ehh, out _, out _))
                    throw new CliArgumentException(
                        $"--ehh should be chr:pos with a whole-number position, such as chr1:5000; got '{ehh}'");
                parameters.EhhSite = ehh;
                parameters.OutType = LdOutputType.Ehh;
            }
            else if (parameters.OutType == LdOutputType.Ehh)
            {
                throw new CliArgumentException("--outtype 3 (EHH) needs an anchor site: add --ehh <chr:pos>.");
            }
            // EHH follows haplotypes; reading the VCF as unphased can only end in a refusal, so say so
            // now rather than after the whole file has been streamed.
            if (parameters.OutType == LdOutputType.Ehh && parameters.IgnorePhase)
                throw new CliArgumentException("--ignore-phase cannot be combined with EHH, which needs phased haplotypes.");

            var engine = new LdAnalysisEngine();
            var repository = new FileResultRepository();

            engine.Deterministic = args.Has("--deterministic");
            // The engine uses ForcedDop only when it is >= 1 and only when it is not running
            // deterministically (LdAnalysisEngine.Run, where dop is chosen). Refuse what it would
            // silently drop, so the thread count in the provenance record is always the requested one.
            if (args.Has("--dop"))
            {
                if (engine.Deterministic)
                    throw new CliArgumentException(
                        "--deterministic runs single-threaded, so --dop cannot apply; drop one of them.");
                engine.ForcedDop = IntArg(args, "--dop", engine.ForcedDop, 1, 1024);
            }
            // The engine clamps a smaller block size up to its minimum; say so instead of
            // accepting a number it will not use.
            engine.BlockSize = IntArg(args, "--block", engine.BlockSize, LdAnalysisEngine.MinBlockSize, 1 << 20);

            // Every value is checked before the disk is touched (the reference likewise validates
            // after its parse loop), so a mistyped option is never hidden by a missing file.
            if (!File.Exists(vcf))
                throw new CliArgumentException("input VCF not found: " + vcf);
            if (subpop != null && !File.Exists(subpop))
                throw new CliArgumentException("sample list (--subpop) not found: " + subpop);
            // ...and the output target with them: the reference opens its output right after the
            // parse, so a bad -out costs nothing, while here the write is the LAST step of the
            // run. Without this check a missing folder throws the whole read and pairwise pass
            // away at the end of the job.
            RequireOutputDirectory(outPrefix, "--out");

            // CAIR cache + provenance ledger under %LOCALAPPDATA%\PopLDdecay (disable with --no-cache).
            AnalysisService service;
            if (args.Has("--no-cache"))
            {
                service = new AnalysisService(engine, repository);
            }
            else
            {
                string cacheRoot = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PopLDdecay");
                service = new AnalysisService(engine, repository,
                    new FileCairCache(Path.Combine(cacheRoot, "cache")),
                    new FileProvenanceLedger(cacheRoot));
            }

            var request = new AnalysisRequest
            {
                VcfPaths = new[] { vcf },
                OutputPrefix = outPrefix,
                Parameters = parameters,
                SampleListPath = subpop,
                // The cache key does not record how a result was summed, so a deterministic run
                // could otherwise be handed a result some earlier parallel run stored. It
                // recomputes instead (and refreshes the cache with its own result).
                BypassCache = engine.Deterministic,
            };
            // An --out that names the VCF or the sample list would replace it with the result
            // (the service refuses too; here it is a usage error before anything is read).
            string conflict = AnalysisService.OutputConflict(request,
                PopLD.Domain.Services.OutputPaths.ResultFor(outPrefix, parameters.OutType == LdOutputType.Ehh));
            if (conflict != null) throw new CliArgumentException(conflict.Replace("output prefix", "--out"));
            // Printed on the reporting thread, in order. Progress<T> would post each report to the
            // thread pool, so lines could come out of order and the last warnings after the summary.
            var progress = new ConsoleProgress();

            var sw = Stopwatch.StartNew();
            AnalysisResult result = await service.RunAsync(request, progress, CancellationToken.None)
                .ConfigureAwait(false);
            sw.Stop();

            // A failed run is a diagnostic, not output: the reference writes those with cerr, so
            // a pipeline reading stdout never sees them.
            if (result.Success) Console.WriteLine(result.Message);
            else Console.Error.WriteLine(result.Message);
            Console.WriteLine($"elapsed = {sw.Elapsed.TotalSeconds:F2}s");
            return result.Success ? ExitOk : ExitFailed;
        }

        /// <summary>
        /// Prints one progress stage. The engine reports its SubPop mismatches as "warning: …"
        /// stages, and the reference prints every such diagnostic with cerr (FileDeal.h's sample
        /// checks, LD_Decay.cpp), so those go to stderr while ordinary progress stays on stdout.
        /// </summary>
        private static void ReportProgress(AnalysisProgress p)
        {
            // "[50%]" on every machine: the invariant "P0" format would print "[50 %]".
            int percent = (int)Math.Round(Math.Max(0.0, Math.Min(1.0, p.Fraction)) * 100);
            string line = "[" + percent.ToString(CultureInfo.InvariantCulture) + "%] " + p.Stage;
            if (p.Stage != null && p.Stage.StartsWith("warning", StringComparison.OrdinalIgnoreCase))
                Console.Error.WriteLine(line);
            else
                Console.WriteLine(line);
        }

        /// <summary>Prints each report synchronously; the analysis reports from several threads.</summary>
        private sealed class ConsoleProgress : IProgress<AnalysisProgress>
        {
            private readonly object _gate = new object();

            public void Report(AnalysisProgress value)
            {
                lock (_gate) ReportProgress(value);
            }
        }

        /// <summary>
        /// Makes sure a prefix can actually be written to, before any reading starts: creates the
        /// folder when it is missing, and refuses with a message naming the option when it cannot.
        /// Called for --out and --plotout, whose writers open their files only at the very end.
        /// </summary>
        private static void RequireOutputDirectory(string prefix, string option)
        {
            if (string.IsNullOrEmpty(prefix))
                throw new CliArgumentException($"{option} needs an output prefix, such as {option} results/PopA");

            string full;
            try
            {
                full = Path.GetFullPath(prefix);
            }
            catch (Exception ex)   // invalid characters, no drive, path too long
            {
                throw new CliArgumentException($"{option} '{prefix}' is not a usable path: {ex.Message}");
            }
            // A prefix is a FILE stem, so it must have a name part: "results\" would write
            // "results\.stat.gz", a file the user did not ask for and will not find again.
            if (string.IsNullOrEmpty(Path.GetFileName(full)))
                throw new CliArgumentException(
                    $"{option} '{prefix}' names a folder; add the file prefix, e.g. {prefix}PopA");

            string dir = Path.GetDirectoryName(full);
            if (string.IsNullOrEmpty(dir) || Directory.Exists(dir)) return;
            try
            {
                Directory.CreateDirectory(dir);
                Console.WriteLine("created output folder: " + dir);
            }
            catch (Exception ex)
            {
                throw new CliArgumentException(
                    $"cannot create the output folder for {option} ('{dir}'): {ex.Message}");
            }
        }

        /// <summary>Dev harness: --scan &lt;file.vcf.gz&gt; [maxSites] — reader/filter statistics only.</summary>
        private static int ScanMode(string[] args)
        {
            if (args.Length < 2)
                throw new CliArgumentException("lack argument for [ --scan ]  (--scan <file.vcf.gz> [maxSites])");
            if (args.Length > 3)
                throw new CliArgumentException(
                    "--scan takes a file and an optional site limit; unexpected: " +
                    string.Join(" ", args, 3, args.Length - 3));
            if (!File.Exists(args[1]))
                throw new CliArgumentException("input VCF not found: " + args[1]);

            int maxSites = int.MaxValue;
            if (args.Length == 3 &&
                (!int.TryParse(args[2], NumberStyles.Integer, CultureInfo.InvariantCulture, out maxSites) || maxSites < 1))
                throw new CliArgumentException($"--scan site limit must be a positive integer, got '{args[2]}'");

            return ScanVcf(args[1], maxSites);
        }

        /// <summary>Dev harness: --binn &lt;file.stat.gz&gt; — first bins at the default binning.</summary>
        private static int BinnMode(string[] args)
        {
            if (args.Length < 2)
                throw new CliArgumentException("lack argument for [ --binn ]  (--binn <file.stat.gz>)");
            if (args.Length > 2)
                throw new CliArgumentException("--binn takes a single .stat.gz file; use --plot for binning options.");
            if (!File.Exists(args[1]))
                throw new CliArgumentException("file not found: " + args[1]);

            // Default binning AND the reference's default x range: 0 = the file's own extent,
            // the same default --plot now uses.
            var pts = StatFileBinner.ReadBinned(args[1], ParameterRules.DefaultBin1, ParameterRules.DefaultBin2, ParameterRules.DefaultBreak, 0);
            Console.WriteLine($"binned points = {pts.XKb.Length}, maxY = {pts.MaxY:F4}, maxX = {pts.MaxXKb}kb");
            for (int i = 0; i < Math.Min(5, pts.XKb.Length); i++)
                Console.WriteLine($"  x={pts.XKb[i]:F3}kb  r2={pts.Y[i]:F4}");
            return ExitOk;
        }

        // Headless plotting: vector PDF + the plotted data, from existing .stat.gz/.ehh.gz files.
        //   --plot a.stat.gz[;b.stat.gz...] [--plotout base] [--measure r2|d|both]
        //          [--bin1 10] [--bin2 100] [--break 100] [--maxx 0] [--w 1200] [--h 900]
        // Run-time failures (unreadable file, unwritable target) are caught by the one guard in
        // Main, which reports them as "--plot failed: …" on stderr with ExitFailed.
        private static int Plot(string[] rawArgs)
        {
            if (rawArgs.Length < 2 || rawArgs[1].StartsWith("-", StringComparison.Ordinal))
                throw new CliArgumentException(
                    "lack argument for [ --plot ]  (--plot a.stat.gz[;b.stat.gz...])");
            Args args = ParseArgs(rawArgs, 2, PlotValueArgs, NoFlagArgs);

            string measureArg = (args.Get("--measure") ?? "r2").ToLowerInvariant();
            PlotMeasure measure;
            if (measureArg == "both" || measureArg == "b") measure = PlotMeasure.Both;
            else if (measureArg == "d" || measureArg == "dprime" || measureArg == "d'") measure = PlotMeasure.DPrime;
            else if (measureArg == "r2" || measureArg == "r^2" || measureArg == "r") measure = PlotMeasure.R2;
            else throw new CliArgumentException($"unknown --measure '{measureArg}' (use r2, d or both)");

            // 0 for a bin width or the break point means the default, as in the reference
            // ($bin1||=10, $bin2||=100, $break||=100); maxX is multiplied by 1000, so it is capped.
            int bin1 = IntArg(args, "--bin1", ParameterRules.DefaultBin1, ParameterRules.BinMin, ParameterRules.BinMax);
            int bin2 = IntArg(args, "--bin2", ParameterRules.DefaultBin2, ParameterRules.BinMin, ParameterRules.BinMax);
            int brk = IntArg(args, "--break", ParameterRules.DefaultBreak, ParameterRules.BreakMin, ParameterRules.BreakMax);
            // -maxX defaults to the FILE'S OWN extent in the reference, not to a fixed number:
            // Plot_OnePop.pl documents "[maxDist]" and implements it as $maxX ||= int($maxX_tmp/1000)
            // after reading the stat file (Plot_MultiPop.pl does the same). The binner spells that
            // as 0, so 0 is both our default and an explicit "use the file's extent".
            int maxXKb = IntArg(args, "--maxx", 0, ParameterRules.MaxXKbMin, ParameterRules.MaxXKbMax);
            int w = IntArg(args, "--w", 1200, ParameterRules.CanvasMin, ParameterRules.CanvasMax);
            int h = IntArg(args, "--h", 900, ParameterRules.CanvasMin, ParameterRules.CanvasMax);
            string outBase = args.Get("--plotout") ?? "LDdecay";

            string[] files = rawArgs[1].Split(new[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            if (files.Length == 0)
                throw new CliArgumentException("--plot needs at least one .stat.gz file");
            foreach (string f in files)
                if (!File.Exists(f))
                    throw new CliArgumentException($"file not found: {f}  (note: ';' separates multiple files)");

            // EHH and LD decay use incompatible axes; refuse the mix rather than mislabel. A file
            // counts as EHH by its name or its header — the same test the GUI uses.
            int ehhFiles = PlotLoader.ClassifyEhh(files, out bool[] isEhh);
            if (ehhFiles > 0 && ehhFiles < files.Length)
                throw new CliArgumentException("cannot plot EHH and LD-decay results together — their axes differ.");
            // EHH curves are read as written, so binning and measure selection do not reach them.
            // Say it instead of accepting the numbers and quietly dropping them.
            if (ehhFiles == files.Length)
            {
                string ignored = GivenNames(args, "--measure", "--bin1", "--bin2", "--break", "--maxx");
                if (ignored != null)
                    Console.Error.WriteLine(
                        $"warning: {ignored} not applied — EHH input is plotted as written.");
            }

            // LAST check before the inputs are read, and in that order for the same reason
            // AnalyseAsync uses: the PDF writer opens its file only after every file has been
            // binned, so the folder has to exist before the pass starts — but a command that
            // goes on to refuse (missing .stat.gz, mixed axes) must leave the disk untouched,
            // so nothing is created until every argument has been accepted.
            RequireOutputDirectory(outBase, "--plotout");

            // The same reading as the GUI's (PlotLoader): a curve with no points is left out of the
            // chart and the tables, and rows with a NaN or infinity are left out with a warning.
            var load = PlotLoader.Load(files, isEhh, measure, bin1, bin2, brk, maxXKb * 1000, new ConsolePlotReport());
            var series = load.Series;
            // An exported table is already binned and is plotted as written; bin widths given now
            // do not reach it. Say so, as for EHH input.
            foreach (var s in load.Tables())
            {
                string ignoredBins = GivenNames(args, "--bin1", "--bin2", "--break");
                if (ignoredBins != null)
                    Console.Error.WriteLine($"warning: {ignoredBins} not applied to {Path.GetFileName(s.SourcePath)} — an exported table is plotted as written.");
                else
                    Console.WriteLine($"note: {Path.GetFileName(s.SourcePath)} is an exported table, plotted as written (binning: {s.TableParams}).");
            }
            if (series.Count == 0)
            {
                // Nothing left to draw; writing an empty figure would look like a result.
                Console.Error.WriteLine("none of the files yielded any points — nothing was plotted.");
                return ExitFailed;
            }
            foreach (var s in series)
            {
                string label = PlotLayout.TrimName(s.Name);
                if (!PdfPlotWriter.CanEncode(label))
                    Console.Error.WriteLine($"warning: legend \"{label}\" has non-Latin characters; the PDF shows them as '?' (use ASCII file names for the PDF legend)");
            }

            // --maxx unset: the binner has filled MaxXKb from each file's own largest Dist, which
            // is the reference's default. Say which value the plot ends up using; the exported
            // table's parameter comment records that value too, not the 0 that asked for it.
            if (maxXKb == 0 && ehhFiles == 0)
                // "auto", not "not given": 0 is equally what an explicit --maxx 0 asks for.
                Console.WriteLine($"maxX auto: plotting 0-{PlotDataWriter.EffectiveMaxXKb(series)}kb, the file extent (reference default)");

            // Every file the export writes is known now; none may be one of the files just read
            // (plotting an exported table under its own name would replace it with its re-binned copy).
            string overwritten = PlotExport.OverwrittenInput(outBase, series, false, files);
            if (overwritten != null)
                throw new CliArgumentException(
                    $"--plotout {outBase} would overwrite {overwritten}, one of the files given to --plot; choose another --plotout.");

            PdfPlotWriter.Write(outBase + ".pdf", w, h, series);
            // Report the names the writers give back, never the one we asked for: an EHH plot
            // writes one file per curve, and the tables are split per source stat file
            // (Plot_MultiPop.pl's $output.$PopID), so the requested name may not be on disk.
            string[] data = PlotExport.WriteData(outBase, series, measure, bin1, bin2, brk);
            string dataFile = data.Length == 0 ? "(no data table)" : string.Join(", ", data);
            Console.WriteLine($"wrote {outBase}.pdf (vector, {w}x{h}px canvas) and {dataFile}");
            return ExitOk;
        }

        /// <summary>The command line's side of <see cref="PlotLoader"/>: warnings on stderr, progress on stdout.</summary>
        private sealed class ConsolePlotReport : IPlotLoadReport
        {
            public void NonFinite(string file, DecayPoints curve)
                => Console.Error.WriteLine($"warning: {Path.GetFileName(file)}: {curve.SkippedNonFinite} row(s) without a finite {curve.Measure} value (NaN or infinity) left out.");

            public void OlderExport(string file)
                => Console.Error.WriteLine($"warning: {Path.GetFileName(file)} is a table exported by an earlier version (parameter comment at the end); it was binned again, which moves each point one bin to the right and can change D'. Plot the original result file, or re-export it with this version.");

            public void NoPoints(string file, bool ehh)
                => Console.Error.WriteLine(ehh
                    ? $"warning: {Path.GetFileName(file)} has no EHH rows — left out."
                    : $"warning: {Path.GetFileName(file)} yielded no points — left out.");

            public void NoDPrime(string file, bool leftOut)
                => Console.Error.WriteLine($"warning: {Path.GetFileName(file)} has no D' data (OutType 1 file?)" + (leftOut ? " — left out." : ""));

            public void NoR2(string file)
                => Console.Error.WriteLine($"warning: {Path.GetFileName(file)} has no usable r² — D' only.");

            public void Loaded(string file, IReadOnlyList<DecayPoints> curves, string drawn)
            {
                int points = 0;
                foreach (var c in curves) points = Math.Max(points, c.XKb.Length);
                Console.WriteLine(drawn == "EHH"
                    ? $"read {Path.GetFileName(file)}: {points} points (EHH)"
                    : $"binned {Path.GetFileName(file)}: {points} points ({drawn})");
            }
        }

        /// <summary>The options a mode was given, read once by <see cref="ParseArgs"/>.</summary>
        private sealed class Args
        {
            public readonly Dictionary<string, string> Values =
                new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            public readonly HashSet<string> Flags =
                new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            /// <summary>The value given for <paramref name="name"/>, or null.</summary>
            public string Get(string name) => Values.TryGetValue(name, out string v) ? v : null;

            /// <summary>True when <paramref name="name"/> was given (as a flag or with a value).</summary>
            public bool Has(string name) => Flags.Contains(name) || Values.ContainsKey(name);
        }

        /// <summary>
        /// Reads the argument list from <paramref name="start"/> into a table, refusing anything
        /// the mode does not declare. Mirrors the reference parser: a bare value is "command
        /// option error!" (LD_Decay.cpp:131-135), a value-taking option with nothing after it is
        /// "Lack Argument for [ -flag ]" (LD_Decay.cpp:141 etc. via CommFun.h:10-13), and an
        /// unrecognised flag is "UnKnow argument -flag" (LD_Decay.cpp:218-222) — all fatal.
        /// <para>Every later lookup reads this table, never the raw list, so a value is never
        /// mistaken for an option: "--out --no-cache" is a missing value for --out, not an output
        /// called "--no-cache" that also turns the cache off. An option given twice is refused
        /// (the reference silently keeps the last one, which hides a typo).</para>
        /// </summary>
        private static Args ParseArgs(string[] args, int start, string[] valueArgs, string[] flagArgs)
        {
            var parsed = new Args();
            for (int i = start; i < args.Length; i++)
            {
                string a = args[i];
                string name = Find(valueArgs, a);
                if (name != null)
                {
                    if (i + 1 >= args.Length || Find(valueArgs, args[i + 1]) != null || Find(flagArgs, args[i + 1]) != null)
                        throw new CliArgumentException($"lack argument for [ {a} ]");
                    if (parsed.Values.ContainsKey(name))
                        throw new CliArgumentException($"{name} is given more than once");
                    parsed.Values[name] = args[++i];
                    continue;
                }
                name = Find(flagArgs, a);
                if (name != null)
                {
                    if (!parsed.Flags.Add(name))
                        throw new CliArgumentException($"{name} is given more than once");
                    continue;
                }
                if (a.Length == 0 || a[0] != '-')
                    throw new CliArgumentException($"unexpected value '{a}' (options are given as --name value)");
                throw new CliArgumentException($"unknown argument {a}");
            }
            return parsed;
        }

        /// <summary>The table's spelling of <paramref name="arg"/> if it is one of <paramref name="names"/>.</summary>
        private static string Find(string[] names, string arg)
        {
            foreach (var n in names)
                if (string.Equals(n, arg, StringComparison.OrdinalIgnoreCase)) return n;
            return null;
        }

        /// <summary>Lists which of <paramref name="names"/> the user actually typed, or null.</summary>
        private static string GivenNames(Args args, params string[] names)
        {
            var given = new List<string>();
            foreach (var n in names)
                if (args.Has(n)) given.Add(n);
            return given.Count == 0 ? null : string.Join(", ", given.ToArray());
        }

        /// <summary>Reads an option as an integer inside the range the callee actually honours.</summary>
        private static int IntArg(Args args, string name, int dflt, int min, int max)
        {
            string v = args.Get(name);
            if (v == null) return dflt;
            if (!ParameterRules.TryParseInteger(v, out int r))
                throw new CliArgumentException(ParameterRules.NotAnInteger(name, v));
            string bad = ParameterRules.CheckRange(name, r, min, max);
            if (bad != null) throw new CliArgumentException(bad);
            return r;
        }

        /// <summary>Reads an option as a decimal fraction inside the range the filters accept.</summary>
        private static double DoubleArg(Args args, string name, double dflt, double min, double max)
        {
            string v = args.Get(name);
            if (v == null) return dflt;
            if (!ParameterRules.TryParseNumber(v, out double r))
                throw new CliArgumentException(ParameterRules.NotANumber(name, v));
            string bad = ParameterRules.CheckRange(name, r, min, max);
            if (bad != null) throw new CliArgumentException(bad);
            return r;
        }

        /// <summary>
        /// Maps -OutType. The reference accepts 0-8 and refuses the rest with
        /// "-OutType should be [0-8]" (LD_Decay.cpp:237-241). This build implements 1, 2 and its
        /// own 3 (= EHH), so every other value is refused here too: silently downgrading it to 1
        /// would hand back numbers nobody asked for.
        /// </summary>
        private static LdOutputType OutTypeArg(Args args, LdOutputType dflt)
        {
            string v = args.Get("--outtype");
            if (v == null) return dflt;
            if (!ParameterRules.TryParseInteger(v, out int n))
                throw new CliArgumentException(ParameterRules.NotAnInteger("--outtype", v));
            switch (n)
            {
                case 1: return LdOutputType.R2;
                case 2: return LdOutputType.R2AndDPrime;
                case 3: return LdOutputType.Ehh;
                default:
                    throw new CliArgumentException(
                        "--outtype must be 1 (r^2), 2 (r^2 & D') or 3 (EHH); got " + n +
                        ". The original documents 1-8, but its pairwise-LD dumps (3-8 there) " +
                        "are not implemented in this build.");
            }
        }

        /// <summary>
        /// Maps --unphased. Not an option of the original, which only knows its own rule, so the
        /// default "popld" keeps this build's output identical to it.
        /// </summary>
        private static UnphasedLdEstimator UnphasedArg(Args args, UnphasedLdEstimator dflt)
        {
            string v = args.Get("--unphased");
            if (v == null) return dflt;
            switch (v.Trim().ToLowerInvariant())
            {
                case "popld": return UnphasedLdEstimator.PopLDdecay;
                case "ml": return UnphasedLdEstimator.MaximumLikelihood;
                default:
                    throw new CliArgumentException(
                        "--unphased must be popld (the original's rule) or ml (maximum likelihood); got '" + v + "'");
            }
        }

        /// <summary>Everything this build accepts — nothing more, nothing less.</summary>
        private static void PrintUsage()
        {
            Console.WriteLine();
            Console.WriteLine("  analysis  ->  <prefix>.stat.gz  (or <prefix>.ehh.gz with --ehh)");
            Console.WriteLine("    PopLDdecay.cli --vcf <in.vcf[.gz]> [--out <prefix>] [options]");
            Console.WriteLine();
            Console.WriteLine("      --vcf      <file>     input SNP VCF                            (required)");
            Console.WriteLine("      --out      <str>      output prefix; folder created if absent  [out]");
            Console.WriteLine("      --subpop   <file>     sub-group sample list                    [all samples]");
            Console.WriteLine("      --maxdist  <int>      max distance (kb) between two SNP        [300]");
            Console.WriteLine("      --maf      <float>    min minor allele frequency, 0-0.5        [0.005]");
            Console.WriteLine("      --het      <float>    max ratio of het allele, 0-1             [0.88]");
            Console.WriteLine("      --miss     <float>    max ratio of miss allele, 0-1            [0.25]");
            Console.WriteLine("      --outtype  <int>      1: r^2   2: r^2 & D'   3: EHH            [1]");
            Console.WriteLine("      --ehh      <chr:pos>  EHH anchor site; implies --outtype 3");
            Console.WriteLine("      --unphased <str>      LD on unphased ('/') VCF: popld | ml     [popld]");
            Console.WriteLine("                              popld = the original's rule (het read as major/minor)");
            Console.WriteLine("                              ml    = maximum-likelihood haplotype frequencies");
            Console.WriteLine("      --ignore-phase        read a phased ('|') VCF as unphased");
            Console.WriteLine("      --no-cache            run without the CAIR cache and ledger");
            Console.WriteLine("      --deterministic       single thread, reproducible summation order;");
            Console.WriteLine("                            always recomputes (never served from the cache)");
            Console.WriteLine("      --dop      <int>      force degree of parallelism, >= 1        [auto]");
            Console.WriteLine("      --block    <int>      pairwise block size, >= 8                [128]");
            Console.WriteLine();
            Console.WriteLine("      Note: --outtype 3 is this build's EHH mode; the original's OutType 3-8");
            Console.WriteLine("      (pairwise LD dumps) are not implemented. EHH raises MAF to 0.05 when a");
            Console.WriteLine("      lower value is given, exactly as the original does.");
            Console.WriteLine();
            Console.WriteLine("  plot  ->  <base>.pdf (vector) + the binned table(s) (LD) or <base>.ehh.gz (EHH)");
            Console.WriteLine("            (one table per input stat file; the run prints the names it wrote)");
            Console.WriteLine("    PopLDdecay.cli --plot a.stat.gz[;b.stat.gz...] [options]");
            Console.WriteLine();
            Console.WriteLine("      --plotout  <str>      figure prefix; folder created if absent  [LDdecay]");
            Console.WriteLine("      --measure  <str>      r2 | d | both                            [r2]");
            Console.WriteLine("      --bin1     <int>      bin size (bp) for short distance         [10]");
            Console.WriteLine("      --bin2     <int>      bin size (bp) for long distance          [100]");
            Console.WriteLine("      --break    <int>      break point (bp) short vs long distance  [100]");
            Console.WriteLine("                            (0 for any of the three = its default, as in the original)");
            Console.WriteLine("      --maxx     <int>      max X distance to plot (kb); 0 = auto    [file's maxDist]");
            Console.WriteLine("      --w / --h  <int>      canvas size in px, 200-20000             [1200 / 900]");
            Console.WriteLine();
            Console.WriteLine("      Note: EHH input is plotted as written, so --measure and the binning");
            Console.WriteLine("      options do not apply to it. Result files may be gzipped or plain text.");
            Console.WriteLine();
            Console.WriteLine("  diagnostics");
            Console.WriteLine("    PopLDdecay.cli --scan <file.vcf[.gz]> [maxSites]   reader/filter statistics");
            Console.WriteLine("    PopLDdecay.cli --binn <file.stat.gz>               first bins, default binning");
            Console.WriteLine("    PopLDdecay.cli --help                              this text");
            Console.WriteLine();
            Console.WriteLine("  exit status: 0 = ok, 1 = the run failed, 2 = bad command line");
            Console.WriteLine("  progress goes to stdout, warnings and failures to stderr");
            Console.WriteLine();
        }

        /// <summary>
        /// Phase-1 harness: stream the reader over a real VCF and report filter stats.
        /// <para>"kept sites" counts what an analysis run would actually use, so the two agree on
        /// one file: the engine stores sites in a per-chromosome position set and drops a second
        /// record at the same CHROM/POS (first one wins, mirroring the original's std::map), and
        /// this scan repeats that here. The reader's own pre-dedup total is reported next to it.</para>
        /// </summary>
        private static int ScanVcf(string path, int maxSites)
        {
            var p = new AnalysisParameters();
            var reader = new VcfGenotypeReader();
            var stats = new ReaderStats();
            var sw = Stopwatch.StartNew();
            long haplotypes = 0;

            int unique = 0, duplicates = 0;

            bool phased = VcfGenotypeReader.IsPhased(path);
            Console.WriteLine($"phased = {phased}");
            foreach (var site in VcfGenotypeReader.FirstAtEachPosition(reader.ReadSites(path, p, stats, null, phased),
                                                                       () => duplicates++))
            {
                haplotypes = site.Alleles.Length;
                // The limit counts analysable SNP, the same unit the run reports.
                if (++unique >= maxSites) break;
            }
            sw.Stop();

            Console.WriteLine($"samples          = {stats.SampleCount}  (haplotypes/site = {haplotypes})");
            Console.WriteLine($"kept sites       = {unique}  (SNP an analysis run would use)");
            Console.WriteLine($"  read by filter = {stats.Kept}  (before duplicate CHROM/POS removal)");
            Console.WriteLine($"  dup CHROM/POS  = {duplicates}  (dropped, first record wins)");
            Console.WriteLine($"skip indel/SV    = {stats.SkippedIndelOrSv}");
            Console.WriteLine($"skip miss        = {stats.SkippedMiss}");
            Console.WriteLine($"skip het         = {stats.SkippedHet}");
            Console.WriteLine($"skip mono/multi  = {stats.SkippedMonoOrMulti}");
            Console.WriteLine($"skip MAF         = {stats.SkippedMaf}");
            // Ragged records the reader refuses to encode; without this line the counters above
            // do not add up to the number of records in the file and the cause stays invisible.
            Console.WriteLine($"skip short line  = {stats.SkippedShortLine}");
            Console.WriteLine($"non-numeric POS  = {stats.MalformedPos}  (kept; read as the original reads them)");
            Console.WriteLine($"elapsed          = {sw.Elapsed.TotalSeconds:F2}s");
            return ExitOk;
        }
    }
}
