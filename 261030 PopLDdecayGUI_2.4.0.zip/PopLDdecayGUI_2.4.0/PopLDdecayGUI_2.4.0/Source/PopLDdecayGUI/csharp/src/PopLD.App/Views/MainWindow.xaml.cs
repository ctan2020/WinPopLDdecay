﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using PopLD.Core.Services;
using PopLD.Domain.Abstractions;
using PopLD.Domain.Model;
using PopLD.Engine;
using PopLD.Infrastructure.Caching;
using PopLD.Infrastructure.Io;
using PopLD.Infrastructure.Plotting;
using PopLD.Infrastructure.Provenance;

namespace PopLD.App.Views
{
    /// <summary>
    /// Main window. UI glue only: it reads control values, delegates analysis to the shared
    /// AnalysisService/engine (same core as the CLI), and renders results with DecayPlotView.
    /// </summary>
    public partial class MainWindow : Window
    {
        private readonly LdAnalysisEngine _engine = new LdAnalysisEngine();
        private readonly AnalysisService _service;

        private string[] _vcfPaths = new string[0];
        private string _sampleList;
        private readonly List<string> _statFiles = new List<string>();
        private List<DecayPoints> _lastSeries;          // series behind the current plot (for export)
        private AnalysisParameters _lastPlotParams;     // bin/maxX params behind the current plot
        private List<string> _plottedFiles;             // files behind the current plot (for its caption)
        private CancellationTokenSource _cts;
        private bool _resetting;                        // a reset is clearing the cache

        /// <summary>How the last run ended; drives the status dot once the run is over.</summary>
        private enum RunOutcome { Ok, Warning, Cancelled, Failed }
        private RunOutcome _outcome = RunOutcome.Ok;

        /// <summary>Number of warnings raised so far. Only ever compared with itself, to tell
        /// "this action raised a warning" from "a warning was already standing".</summary>
        private int _warnCount;
        /// <summary>True when the recorded <see cref="RunOutcome.Warning"/> came from a plot
        /// action rather than from an analysis run. A later successful plot clears its own kind
        /// of warning; a run's warning is about results on disk and outlives any replotting.</summary>
        private bool _warningFromPlot;

        private bool _english;
        private double _tRead, _tPair, _tWrite, _tPlot;

        private readonly FileCairCache _cache;          // kept for the "reset cached results" action; null if unavailable
        private PlotMeasure _lastMeasure = PlotMeasure.R2;   // what the current plot shows, for the export's comment

        public MainWindow()
        {
            InitializeComponent();
            string cacheRoot = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PopLDdecay");
            string cacheProblem = null;
            try
            {
                _cache = new FileCairCache(Path.Combine(cacheRoot, "cache"));
                _service = new AnalysisService(_engine, new FileResultRepository(), _cache,
                    new FileProvenanceLedger(cacheRoot));
            }
            catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
            {
                // A profile folder that cannot be written must not stop the program: run without
                // the cache and the ledger, and say so.
                _cache = null;
                _service = new AnalysisService(_engine, new FileResultRepository());
                cacheProblem = ex.Message;
            }
            ApplySampleScope();
            ApplyMeasureOptions();
            if (cacheProblem != null)
                Log("缓存与运行记录不可用（" + cacheProblem + "），本次将不使用缓存。 / " +
                    "Cache and run ledger unavailable (" + cacheProblem + "); running without them.");

            // The preferred 880px height is taller than the work area of a 1366x768 laptop or a
            // scaled 1080p display; shrink to fit rather than opening partly off-screen.
            var work = SystemParameters.WorkArea;
            if (Height > work.Height - 24) Height = Math.Max(MinHeight, work.Height - 24);
            if (Width > work.Width - 24) Width = Math.Max(MinWidth, work.Width - 24);
        }

        /// <summary>True when the user picked "single sample list" in the right-hand panel.</summary>
        private bool SingleListMode => ScopeSingleBox != null && ScopeSingleBox.IsChecked == true;

        /// <summary>
        /// Applies the sample-scope mode: in "all samples" the left-hand sample-list button is
        /// disabled and any previously chosen list is dropped, so what the panel says is exactly
        /// what the next run does.
        /// </summary>
        private void ApplySampleScope()
        {
            if (SampleListRow == null) return;   // still initializing
            bool single = SingleListMode;
            SampleListRow.Visibility = single ? Visibility.Visible : Visibility.Collapsed;
            if (!single) _sampleList = null;
            UpdateInputSummary();
        }

        /// <summary>Refreshes the two read-only file fields in the rail.</summary>
        private void UpdateInputSummary()
        {
            if (VcfBox == null) return;
            ShowSelection(VcfBox, _vcfPaths, $"{_vcfPaths.Length} VCF files", $"已选 {_vcfPaths.Length} 个 VCF 文件");
            ShowSelection(SampleListDisplay, string.IsNullOrEmpty(_sampleList) ? new string[0] : new[] { _sampleList }, null, null);
            if (ResultFilesBox != null)
                ShowSelection(ResultFilesBox, _statFiles, $"{_statFiles.Count} files selected", $"已选 {_statFiles.Count} 个文件");
        }

        /// <summary>Shows a selection in its box: "not selected" (muted), the one file's name, or a count.</summary>
        private void ShowSelection(TextBox box, IReadOnlyList<string> files, string manyEn, string manyZh)
        {
            box.Text = files.Count == 0 ? (_english ? "Not selected" : "未选择")
                     : files.Count == 1 ? Path.GetFileName(files[0])
                     : (_english ? manyEn : manyZh);
            box.Foreground = (Brush)FindResource(files.Count == 0 ? "InkMute" : "Ink");
        }

        private void OnSampleScopeChanged(object sender, RoutedEventArgs e)
        {
            if (!IsInitialized) return;
            ApplySampleScope();
            Log(SingleListMode
                ? (_english ? "Scope: single sample list — choose one on the left."
                            : "样本范围：单个样本列表，请在左侧选择列表文件。")
                : (_english ? "Scope: all samples (sample list ignored)."
                            : "样本范围：全部样本（不使用样本列表）。"));
        }

        /// <summary>
        /// Full reset: drops every file selection, the current plot and all cached results, so
        /// the next analysis starts from a clean slate and must be re-selected and re-run.
        /// Result files already written to disk are left alone.
        /// </summary>
        private async void OnResetCache(object sender, RoutedEventArgs e)
        {
            if (_resetting)
            {
                Log(_english ? "The cache is still being cleared by the previous reset." : "上一次复位仍在清空缓存。");
                return;
            }
            var answer = MessageBox.Show(
                _english
                    ? "Clear the selected files, the current plot and all cached results?\nYou will need to select the inputs and run again.\n(Result files already written to disk are not deleted.)"
                    : "确定清空已选文件、当前图和全部缓存结果吗？\n之后需要重新选择文件并运行。\n（已写出的结果文件不会被删除。）",
                _english ? "Reset & clear results" : "复位并清空计算结果",
                MessageBoxButton.OKCancel, MessageBoxImage.Question);
            if (answer != MessageBoxResult.OK) return;

            if (_cts != null) { _cts.Cancel(); Log(_english ? "Cancelling the running analysis…" : "正在取消进行中的分析…"); }

            // The window is reset first: clearing the cache below may wait, and whatever the user
            // selects meanwhile must not be wiped when it finishes.
            _vcfPaths = new string[0];
            _sampleList = null;
            _statFiles.Clear();
            ClearPlot();
            _tRead = _tPair = _tWrite = 0;
            UpdateTiming();
            Progress.Value = 0;
            ApplySampleScope();
            // The selection is gone, so the Y axis falls back to the stage-1 analysis type.
            ApplyMeasureOptions(dataChanged: true);
            // Reset promises a clean slate, so the recorded outcome and the status light go back
            // to idle too — otherwise an amber "needs attention" from an earlier plot survives a
            // reset that has just discarded the thing it was complaining about.
            _outcome = RunOutcome.Ok;
            _warningFromPlot = false;
            if (_cts == null) SetStatus("就绪", "Ready", "OkCol");

            int n = 0;
            bool cleared = true;
            _resetting = true;
            try
            {
                // Off the UI thread: the cache waits for another PopLDdecay process (or this one's
                // running analysis) to let go of it, and the window must not freeze meanwhile.
                if (_cache != null) n = await Task.Run(() => _cache.Clear());
            }
            catch (Exception ex)
            {
                cleared = false;
                Log((_english ? "Cache clear failed: " : "清空缓存失败：") + ex.Message);
            }
            finally
            {
                _resetting = false;
            }

            Log(cleared
                ? (_english
                    ? $"Reset: file selections and the plot cleared, {n} cached result(s) discarded. Select the inputs and run again."
                    : $"已复位：已清空文件选择与当前图，并删除 {n} 条缓存结果。请重新选择文件并运行。")
                : (_english
                    ? "Reset: file selections and the plot cleared; the cached results were NOT cleared (see above)."
                    : "已复位：已清空文件选择与当前图；缓存结果未能清空（原因见上一行）。"));
        }

        // ---- logging ----

        /// <summary>
        /// Logs a message the user must act on: the log line alone is easy to miss in a scrolling
        /// panel, so the status light turns amber alongside it.
        /// </summary>
        private void Warn(string zh, string en)
        {
            Log(_english ? en : zh);
            _warnCount++;
            // Remember it as well: SetBusy(false) restores the idle status when the run ends, and
            // without this the amber light would be replaced by a green "Ready" that claims the
            // run was clean. Never downgrade an already-recorded cancellation or failure.
            if (_outcome == RunOutcome.Ok)
            {
                _outcome = RunOutcome.Warning;
                // Outside a run this warning belongs to the plot, and a later good plot may
                // retire it; inside one it belongs to the run and must not be cleared by
                // replotting files the run never produced.
                _warningFromPlot = _cts == null;
            }
            // While a run is in flight the caption belongs to the run: a warning about the first
            // of several VCFs must not claim the analysis has stopped. SetBusy(false) reads
            // _outcome at the end and paints the amber caption then.
            if (_cts == null) SetStatus("需要处理", "Needs attention", "WarnCol");
        }

        // The log's placeholder in each language (MainWindow.xaml starts with the Chinese one).
        private const string LogPlaceholderZh = "分析和作图结果将在此显示...";
        private const string LogPlaceholderEn = "Analysis and plot results will appear here…";

        private void WarnParameter(ParameterInputException ex) => Warn("参数错误：" + ex.Zh, "Parameter error: " + ex.En);

        private void Log(string message)
        {
            if (LogBox.Text == LogPlaceholderZh || LogBox.Text == LogPlaceholderEn) LogBox.Clear();
            LogBox.AppendText(DateTime.Now.ToString("HH:mm:ss") + "  " + message + Environment.NewLine);
            LogBox.ScrollToEnd();
        }

        // ---- file selection ----
        private void OnChooseVcf(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "VCF files|*.vcf;*.vcf.gz|All files|*.*", Multiselect = true };
            if (dlg.ShowDialog() == true)
            {
                _vcfPaths = dlg.FileNames;
                Log((_english ? $"Selected {_vcfPaths.Length} VCF: " : $"已选择 {_vcfPaths.Length} 个 VCF：") +
                    string.Join(", ", Array.ConvertAll(_vcfPaths, Path.GetFileName)));
                UpdateInputSummary();
            }
        }

        private void OnChooseSampleList(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Filter = "Sample list|*.txt;*.list;*.*" };
            if (dlg.ShowDialog() == true)
            {
                _sampleList = dlg.FileName;
                Log((_english ? "Sample list selected: " : "已选择样本列表：") + Path.GetFileName(_sampleList));
                ApplySampleScope();
            }
        }

        // ---- run analysis ----
        private async void OnGenerateResults(object sender, RoutedEventArgs e)
        {
            if (_cts != null) { _cts.Cancel(); Log(_english ? "Cancelling…" : "正在取消…"); return; }
            if (_vcfPaths.Length == 0) { Warn("请先选择 VCF 文件。", "Select a VCF first."); return; }
            if (SingleListMode && string.IsNullOrEmpty(_sampleList))
            {
                Warn("当前样本范围为“指定样本列表”，但尚未选择列表；请选择列表文件，或改选“全部样本”。",
                     "Scope is \"sample list\" but no list is chosen — pick one, or switch to \"all samples\".");
                return;
            }
            if (EhhMode && !PopLD.Domain.Services.SiteParser.TryParse(EhhBox.Text, out _, out _))
            {
                Warn("EHH 需要锚点位点，格式 chr:pos（位置为整数），例如 22:17000000。",
                     "EHH needs an anchor site written as chr:pos (a whole-number position), e.g. 22:17000000.");
                return;
            }
            AnalysisParameters p;
            try { p = ReadParameters(); }
            catch (ParameterInputException ex) { WarnParameter(ex); return; }

            // The inputs of THIS run, fixed now: the file and list choices stay editable while it
            // runs, and a change made mid-run must not reach the inputs still waiting their turn.
            string[] vcfPaths = _vcfPaths;
            string sampleList = _sampleList;

            var newStats = new List<string>();
            int failed = 0;                     // inputs the service refused (no exception thrown)
            var progress = new Progress<AnalysisProgress>(pr =>
            {
                Progress.Value = pr.Fraction;
                if (string.IsNullOrEmpty(pr.Stage)) return;
                Log(pr.Stage);
                // The engine's own warnings (sample names not in the VCF, ragged records, an
                // option that did not apply…) are the run's warnings too: the light must not end
                // on a clean green "Ready" after one of them.
                if (pr.Stage.StartsWith("warning", StringComparison.OrdinalIgnoreCase))
                {
                    _warnCount++;
                    if (_outcome == RunOutcome.Ok) { _outcome = RunOutcome.Warning; _warningFromPlot = false; }
                }
            });

            _cts = new CancellationTokenSource();
            _outcome = RunOutcome.Ok;
            _warningFromPlot = false;
            _tRead = _tPair = _tWrite = _tPlot = 0;
            UpdateTiming();
            SetBusy(true);
            try
            {
                foreach (var vcf in vcfPaths)
                {
                    // Stop here rather than at the next cancellable piece of work: a CAIR cache
                    // hit is served without the engine ever running, so AnalysisService returns
                    // Success on the fast path without looking at the token (the copy/truncate in
                    // ICacheStore.TryServe is not cancellable). Left to itself the loop would run
                    // every remaining input to completion and end on a green "Ready" light, right
                    // after the log said "Cancelling…".
                    _cts.Token.ThrowIfCancellationRequested();
                    // Include the sample-list name in the output, so pop1/pop2 runs on the
                    // same VCF produce distinct files instead of silently overwriting one.
                    string listPart = string.IsNullOrEmpty(sampleList)
                        ? "" : "." + SafeNamePart(Path.GetFileNameWithoutExtension(sampleList));
                    // EHH results also carry the anchor, so two anchors on one VCF do not
                    // overwrite each other. Contig names can hold characters a file name cannot
                    // (':' always, '*' or '|' in HLA contigs, '/' would even open a subfolder).
                    string anchorPart = p.OutType == LdOutputType.Ehh && !string.IsNullOrEmpty(p.EhhSite)
                        ? "." + SafeNamePart(p.EhhSite.Trim()) : "";
                    var request = new AnalysisRequest
                    {
                        VcfPaths = new[] { vcf },
                        SampleListPath = sampleList,
                        Parameters = p,
                    };
                    // A maximum-likelihood result gets its own name, so it can be plotted next to
                    // the PopLDdecay-rule result of the same VCF instead of replacing it — only when
                    // the engine will really apply it (unphased input), which the same resolution
                    // that keys the cache decides. It reads the VCF, so it runs off this thread.
                    var settings = await _service.ResolveAsync(request, _cts.Token);
                    string mlPart = settings.Parameters.UnphasedEstimator == UnphasedLdEstimator.MaximumLikelihood
                        ? ".ml" : "";
                    string baseName = StripVcf(Path.GetFileName(vcf)) + listPart + anchorPart + mlPart;
                    request.OutputPrefix = PrefixFor(Path.GetDirectoryName(vcf) ?? ".", baseName,
                        p.OutType == LdOutputType.Ehh, vcf, sampleList);
                    Log((_english ? "Analyzing " : "开始分析 ") + Path.GetFileName(vcf) +
                        (string.IsNullOrEmpty(sampleList)
                            ? (_english ? " (all samples)" : "（全部样本）")
                            : (_english ? $" (SubPop: {Path.GetFileName(sampleList)})" : $"（样本列表：{Path.GetFileName(sampleList)}）")) + " …");
                    var result = await _service.RunAsync(request, progress, _cts.Token);
                    Log(result.Message + (result.FromCache
                        ? (_english ? " (CAIR cache hit)" : "（CAIR 缓存命中，免重算）")
                        : $" (dop={result.DegreeOfParallelism})"));
                    _tRead += result.ReadSeconds;
                    _tPair += result.PairwiseSeconds;
                    _tWrite += result.WriteSeconds;
                    UpdateTiming();
                    if (result.Success) newStats.Add(result.StatFilePath);
                    else
                    {
                        // The service reports a refused run (missing input, SubPop < 3 samples,
                        // unusable EHH anchor …) through Success/Message instead of throwing, so
                        // the outcome has to be recorded here too — otherwise the finally-block
                        // below ends the run on a green "Ready" light that says it worked.
                        failed++;
                        Warn("未生成结果文件：" + Path.GetFileName(vcf) + "（原因见上一行）。",
                             "No result file produced for " + Path.GetFileName(vcf) + " (reason above).");
                    }
                    // Again after the call: a Cancel pressed while this input was being served
                    // from the cache is only observable here, once the un-cancellable fast path
                    // has returned. The result above is logged and kept — it is on disk — but
                    // the run stops instead of quietly working through the rest.
                    _cts.Token.ThrowIfCancellationRequested();
                }

                // All inputs refused = the run failed; if some succeeded it stays a warning.
                if (failed > 0 && newStats.Count == 0) _outcome = RunOutcome.Failed;

                if (newStats.Count > 0)
                {
                    _statFiles.Clear();
                    _statFiles.AddRange(newStats);
                    UpdateInputSummary();
                    // The run just replaced the stage-2 selection, so re-offer the Y axis from what
                    // it wrote. A type-2 run lands on r², and D' stays one click away.
                    ApplyMeasureOptions(dataChanged: true);
                    TryPlot(p);
                }
            }
            catch (OperationCanceledException)
            {
                // Say what survived: a cancel can land after some inputs are already written
                // (a cached one completes in the time it takes to copy a file), and a bare
                // "Cancelled." would suggest nothing came of the run at all.
                Log(_english
                    ? (newStats.Count > 0
                        ? $"Cancelled — {newStats.Count} result file(s) had already been written and are kept; the rest were skipped and no plot was drawn."
                        : "Cancelled.")
                    : (newStats.Count > 0
                        ? $"已取消：其中 {newStats.Count} 个结果文件已写出并保留，其余未计算，也未作图。"
                        : "已取消。"));
                _outcome = RunOutcome.Cancelled;
            }
            catch (Exception ex)
            {
                Warn("分析失败：" + ex.Message, "Analysis failed: " + ex.Message);
                _outcome = RunOutcome.Failed;
            }
            finally { _cts.Dispose(); _cts = null; SetBusy(false); }
        }

        // ---- plotting ----
        private void OnChooseStatFiles(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                // Plain-text results (the original's *.ehh, an unzipped *.stat) read as well as gzipped.
                Filter = "Results (*.stat.gz, *.ehh.gz, *.stat, *.ehh)|*.stat.gz;*.ehh.gz;*.stat;*.ehh|LD stat|*.stat.gz;*.stat|EHH|*.ehh.gz;*.ehh|All files|*.*",
                Multiselect = true,
            };
            if (dlg.ShowDialog() == true)
            {
                _statFiles.Clear();
                _statFiles.AddRange(dlg.FileNames);
                UpdateInputSummary();
                // Re-offer the Y axis from what these files actually contain, and say what that
                // was: the box changing under the user is only helpful if the reason is visible.
                ApplyMeasureOptions(dataChanged: true);
                Log(_english
                    ? $"Selected {_statFiles.Count} result file(s) for plotting. Y axis: {MeasureChoices()} (set to {MeasureLabel()})."
                    : $"已选择 {_statFiles.Count} 个结果文件用于作图。纵坐标可选：{MeasureChoices()}（当前为 {MeasureLabel()}）。");
            }
        }

        private void OnGeneratePlot(object sender, RoutedEventArgs e)
        {
            if (_statFiles.Count == 0) { Log(_english ? "Select result files (.stat.gz) first." : "请先选择结果文件（.stat.gz）。"); return; }
            AnalysisParameters plotParams;
            try { plotParams = ReadPlotParameters(); }
            catch (ParameterInputException ex) { WarnParameter(ex); return; }
            _tRead = _tPair = _tWrite = 0; // plotting existing files: analysis steps N/A
            TryPlot(plotParams);
        }

        /// <summary>
        /// Plots the selection. A failure drops the old chart — left standing it belongs to the
        /// previous selection, but its caption and the enabled Export button would be read as
        /// describing the files just picked — and is reported as a plot failure, also when the
        /// plot follows an analysis: the analysis itself has succeeded by then.
        /// </summary>
        private void TryPlot(AnalysisParameters p)
        {
            try { PlotStatFiles(p); }
            catch (Exception ex)
            {
                ClearPlot();
                Warn("作图失败：" + ex.Message + "（已清除上一张图）",
                     "Plot failed: " + ex.Message + " (the previous chart has been cleared).");
            }
        }

        /// <summary>
        /// Drops the current chart and everything that describes it: the caption, the export
        /// button and the series the exporter would write. Used whenever plotting fails or is
        /// refused — a stale figure with a fresh selection behind it is worse than no figure,
        /// because Export would silently save the earlier one.
        /// </summary>
        private void ClearPlot()
        {
            _lastSeries = null;
            _lastPlotParams = null;
            _plottedFiles = null;
            Plot.SetSeries(new List<DecayPoints>());
            ExportBtn.IsEnabled = false;
            UpdatePlotHeader(null);
            _tPlot = 0;              // the timing described the chart that has just gone
            UpdateTiming();
        }

        private void PlotStatFiles(AnalysisParameters p)
        {
            // EHH and LD decay share no axis: EHH is per-SNP homozygosity over a signed distance
            // from an anchor, LD is a binned r²/D' over absolute distance. One chart cannot label
            // both, so refuse the mix instead of drawing a mislabeled figure.
            // EHH by name or by header — the test the Y-axis box and the command line use too.
            int ehhCount = PlotLoader.ClassifyEhh(_statFiles, out bool[] isEhh);
            if (ehhCount > 0 && ehhCount < _statFiles.Count)
            {
                ClearPlot();   // refused: the chart still on screen is not this selection
                Warn("EHH（.ehh.gz）与 LD（.stat.gz）结果的坐标轴不同，不能画在同一张图上；请分别选择同一类结果文件。",
                     "Cannot plot EHH (.ehh.gz) and LD (.stat.gz) results together — their axes differ. Select one kind at a time.");
                return;
            }

            // Warnings raised from here on belong to THIS plot and must survive it; anything
            // standing from an earlier one is retired at the end if this plot succeeds.
            int warnsBefore = _warnCount;
            var sw = System.Diagnostics.Stopwatch.StartNew();
            // What to draw is chosen independently of what was computed (the original's
            // -measure): an OutType-2 stat file holds r² AND D', so either — or both, on twin
            // axes — can be plotted from the same file.
            var measure = SelectedMeasure();
            if (ehhCount > 0)
                Log(_english
                    ? "EHH is plotted point by point as written: bin1, bin2, break and maxX do not apply."
                    : "EHH 按文件原样逐点作图：bin1、bin2、break 与 maxX 不适用。");
            // The same reading as the command line's; WindowPlotReport words what happens here.
            var load = PlotLoader.Load(_statFiles, isEhh, measure, p.Bin1Bp, p.Bin2Bp, p.BreakBp, p.MaxXKb * 1000,
                new WindowPlotReport(this));
            var series = load.Series;
            // An exported table is already binned and is drawn as written; the bin boxes do not
            // reach it.
            foreach (var s in load.Tables())
                Log(_english
                    ? $"Note: {Path.GetFileName(s.SourcePath)} is an exported table — plotted as written (binning: {s.TableParams}); bin1/bin2/break do not apply."
                    : $"提示：{Path.GetFileName(s.SourcePath)} 是导出的数据表，已分箱，按原样作图（分箱：{s.TableParams}），bin1/bin2/break 不适用。");

            if (series.Count == 0)
            {
                // Every selected file was refused (each said why above). Clearing rather than
                // leaving the previous figure keeps the chart, its caption and Export in step
                // with the selection.
                ClearPlot();
                Warn("所选结果文件都没有可绘制的数据，本次未作图。",
                     "None of the selected result files yielded any points — nothing was plotted.");
                sw.Stop();
                return;
            }

            Plot.SetSeries(series);
            _lastSeries = series;
            _lastPlotParams = p;
            // The files that contributed a curve — a D'-only request skips the ones with no D'
            // column, and the caption must count what is drawn, not what was selected.
            _plottedFiles = load.Plotted;
            _lastMeasure = measure;
            ExportBtn.IsEnabled = Plot.HasData;   // enable export once a plot exists
            UpdatePlotHeader(series);
            sw.Stop();
            _tPlot = sw.Elapsed.TotalSeconds;
            UpdateTiming();

            // This plot worked, so an amber light left over from an EARLIER one is complaining
            // about a chart that no longer exists — retire it. Warnings raised by this plot
            // (_warnCount moved) stay, and inside a run the outcome belongs to the run, which
            // SetBusy(false) paints when it ends.
            if (_cts == null && _outcome == RunOutcome.Warning && _warningFromPlot && _warnCount == warnsBefore)
            {
                _outcome = RunOutcome.Ok;
                _warningFromPlot = false;
                SetStatus("就绪", "Ready", "OkCol");
            }
        }

        /// <summary>
        /// Names what the chart currently shows — files, statistic and range — so the figure is
        /// self-describing without digging through the log. Everything is read back off the
        /// series being drawn rather than off the parameter boxes: the boxes hold what was
        /// REQUESTED, which is not the same thing (maxX = 0 asks for the file's own extent, and
        /// a file with no D' contributes no D' curve), and the caption has to match the axes.
        /// </summary>
        private void UpdatePlotHeader(IReadOnlyList<DecayPoints> series)
        {
            if (PlotSubtitle == null) return;
            if (series == null || series.Count == 0)
            {
                PlotSubtitle.Text = _english ? "No plot yet" : "尚未作图";
                PlotSubtitle.Tag = "尚未作图|No plot yet";
                PlotTitle.Text = _english ? "LD Decay Curve" : "LD 衰减曲线";
                PlotTitle.Tag = "LD 衰减曲线|LD Decay Curve";
                return;
            }

            bool ehh = series[0].Measure.StartsWith("EHH", StringComparison.Ordinal);
            // Describe the files THIS plot came from; _statFiles may already have moved on.
            var src = _plottedFiles ?? new List<string>();
            string files = src.Count == 1
                ? PlotLoader.Stem(src[0])
                : (_english ? $"{src.Count} files" : $"{src.Count} 个文件");
            string measures = series[0].Measure;
            for (int i = 1; i < series.Count; i++)
                if (series[i].Measure != measures) { measures = "r² + D'"; break; }

            string range;
            if (ehh)
            {
                // Measure the span of the .ehh.gz actually on screen. The stage-1 MaxDist box says
                // nothing about it: the file may come from an earlier run, from the CLI or from the
                // reference tool, and even within one run the reach stops at the last SNP that
                // passed the filters, not at the requested radius. EHH X values are the signed
                // Dist column of the reference layout (EHHDeal.h:91 "#Chr Site Dist EHH_all …").
                double lo = series[0].MinXKb, hi = series[0].MaxXKb;
                for (int i = 1; i < series.Count; i++)
                {
                    if (series[i].MinXKb < lo) lo = series[i].MinXKb;
                    if (series[i].MaxXKb > hi) hi = series[i].MaxXKb;
                }
                // " … " rather than an en dash: both ends carry an explicit sign, and "-298.4–+301.2"
                // reads as an arithmetic expression.
                string span = FmtKb(lo) + " … " + FmtKb(hi) + " kb";
                range = _english ? span + " from the anchor" : "距锚点 " + span;
            }
            else
            {
                // The x range PlotLayout actually lays out: 0 to the widest MaxXKb of the drawn
                // series. Printing the maxX box instead would read "0–0 kb" for its "use the
                // file's own extent" value — the reference's own default, int($maxX_tmp/1000),
                // Plot_OnePop.pl:586-588, which the binner has already resolved into MaxXKb.
                double hi = series[0].MaxXKb;
                for (int i = 1; i < series.Count; i++)
                    if (series[i].MaxXKb > hi) hi = series[i].MaxXKb;
                range = "0–" + hi.ToString("0.#", CultureInfo.InvariantCulture) + " kb";
            }
            PlotSubtitle.Text = files + " · " + measures + " · " + range;
            PlotSubtitle.Tag = null;   // dynamic text; the translator must not overwrite it

            string zh = ehh ? "EHH 衰减曲线" : "LD 衰减曲线";
            string en = ehh ? "EHH Decay Curve" : "LD Decay Curve";
            PlotTitle.Text = _english ? en : zh;
            PlotTitle.Tag = zh + "|" + en;
        }

        /// <summary>
        /// Reports a D' request against a result file that carries no D' column. The reference
        /// plotter treats this as fatal in the MeanBin path this GUI mirrors — Plot_OnePop.pl:626-631
        /// (and Plot_MultiPop.pl:299-304) print "can't find the D'", tell the user to re-run the core
        /// program with -OutType 2, and exit — so it is raised as a warning here (amber status light,
        /// and a message naming the same two ways out) instead of a log line that scrolls past next
        /// to a blank chart.
        /// </summary>
        // The trigger is "no bin carried a D' value", which an analysis-type-1 result is much the
        // likeliest cause of but not the only one (an empty or truncated file does it too), so the
        // message offers that as the probable reason rather than asserting it.
        private void WarnNoDPrime(string file) => Warn(
            $"{Path.GetFileName(file)} 中没有 D' 数据（通常因为它由分析类型 1 生成），未画 D' 曲线；请将纵坐标改为 r²，或用分析类型 2 重新计算。",
            $"{Path.GetFileName(file)} carries no D' values (usually because it is an analysis-type-1 result) — no D' curve drawn. Switch the Y axis to r², or re-run with analysis type 2.");

        /// <summary>
        /// Reports a result file that yielded no points in ANY statistic — an empty, truncated or
        /// header-only file, or one whose rows the reader could not use. Distinct from
        /// <see cref="WarnNoDPrime"/>, where the file has rows but no D' column: here there is
        /// nothing to draw at all, so the file is left off the chart rather than added as an
        /// invisible curve the caption would then describe as a real plot.
        /// </summary>
        private void WarnNoPoints(string file) => Warn(
            $"{Path.GetFileName(file)} 没有可用数据点（文件为空或已损坏），未画曲线。",
            $"{Path.GetFileName(file)} yielded no points (empty or unreadable file) — no curve drawn.");

        /// <summary>
        /// The window's side of <see cref="PlotLoader"/>: what goes wrong with a file is a warning
        /// (amber light, in both languages), what was drawn is a log line.
        /// </summary>
        private sealed class WindowPlotReport : IPlotLoadReport
        {
            private readonly MainWindow _w;
            public WindowPlotReport(MainWindow w) { _w = w; }

            // Rows left out for a NaN or infinite value cannot be drawn, and a curve that lost
            // them must not look complete.
            public void NonFinite(string file, DecayPoints curve) => _w.Warn(
                $"{Path.GetFileName(file)} 有 {curve.SkippedNonFinite} 行的 {curve.Measure} 不是有限数值（NaN 或无穷），已略去。",
                $"{Path.GetFileName(file)}: {curve.SkippedNonFinite} row(s) without a finite {curve.Measure} value (NaN or infinity) left out.");

            // A table exported by an earlier version (its parameter comment is the last line) is
            // binned again like a result file, which shifts every point one bin to the right.
            public void OlderExport(string file) => _w.Warn(
                $"{Path.GetFileName(file)} 是早期版本导出的数据表（参数注释在末尾），已按普通结果文件再分一次箱，各点会右移一个箱，D′ 也可能改变。请改用原始结果文件作图，或用本版本重新导出。",
                $"{Path.GetFileName(file)} is a table exported by an earlier version (parameter comment at the end); it was binned again, which moves each point one bin to the right and can change D'. Plot the original result file, or re-export it with this version.");

            public void NoPoints(string file, bool ehh) => _w.WarnNoPoints(file);

            public void NoDPrime(string file, bool leftOut) => _w.WarnNoDPrime(file);

            public void NoR2(string file) => _w.Warn(
                $"{Path.GetFileName(file)} 没有可用的 r²，只画 D'。",
                $"{Path.GetFileName(file)} has no usable r² — D' only.");

            public void Loaded(string file, IReadOnlyList<DecayPoints> curves, string drawn)
            {
                string name = Path.GetFileName(file), points = _w.PointCount(curves[0]);
                if (drawn == "EHH")
                {
                    _w.Log(_w._english ? $"Plotting {name}: {points} (EHH)" : $"作图：{name} → {points}（EHH）");
                    return;
                }
                string zh = drawn == "r² and D'" ? "r² 与 D'" : drawn == "r² only" ? "仅 r²" : drawn == "D' only" ? "仅 D'" : drawn;
                _w.Log(_w._english ? $"Plotted {name} -> {points} ({drawn})" : $"作图：{name} → {points}（{zh}）");
            }
        }

        /// <summary>
        /// The point count for a log line, as "N points" — or "N of M points in view" when the
        /// series carries bins beyond the right edge of the chart. The binner keeps those on
        /// purpose: neither reference script drops a bin, -maxX only crops the view
        /// (<c>xlim=c(0,maxX)</c>), so the raw array length routinely counts points the user
        /// cannot see. Counted against this series' own drawn range, which is the axis range
        /// except for the last partial bin of a shorter file sharing the chart.
        /// </summary>
        private string PointCount(DecayPoints s)
        {
            int total = s.XKb.Length, shown = 0;
            for (int i = 0; i < total; i++)
                if (s.XKb[i] >= s.MinXKb && s.XKb[i] <= s.MaxXKb) shown++;
            if (shown == total) return _english ? total + " points" : total + " 点";
            return _english
                ? $"{shown} of {total} points in view"
                : $"{total} 点中 {shown} 点在图内";
        }

        /// <summary>
        /// Keeps the plot range consistent with the analysis range: editing MaxDist copies the
        /// value into maxX once (comment #3), but maxX is not locked — the user can still
        /// fine-tune it afterwards.
        /// </summary>
        private void OnMaxDistChanged(object sender, TextChangedEventArgs e)
        {
            if (MaxXBox == null) return; // fires while InitializeComponent is still running
            if (int.TryParse(MaxDistBox.Text, out int v) && v > 0)
                MaxXBox.Text = MaxDistBox.Text;
        }

        // ---- status bar ----

        /// <summary>Per-stage timings condensed into the one status-bar line.</summary>
        private void UpdateTiming()
        {
            if (TimingText == null) return;
            double total = _tRead + _tPair + _tWrite + _tPlot;
            if (total <= 0) { TimingText.Text = ""; return; }

            var parts = new List<string>();
            if (_tRead > 0) parts.Add((_english ? "read " : "读取 ") + Fmt(_tRead));
            if (_tPair > 0) parts.Add((_english ? "compute " : "计算 ") + Fmt(_tPair));
            if (_tWrite > 0) parts.Add((_english ? "write " : "写出 ") + Fmt(_tWrite));
            if (_tPlot > 0) parts.Add((_english ? "plot " : "作图 ") + Fmt(_tPlot));
            parts.Add((_english ? "total " : "总计 ") + Fmt(total));
            TimingText.Text = string.Join(" · ", parts.ToArray());
        }

        /// <summary>Sets the status dot and its caption (idle / working / problem).</summary>
        private void SetStatus(string zh, string en, string brushKey)
        {
            if (StatusText == null) return;
            StatusText.Text = _english ? en : zh;
            StatusText.Tag = zh + "|" + en;
            StatusDot.Fill = (Brush)FindResource(brushKey);
        }


        /// <summary>Signed kb for the EHH caption; the sign says which side of the anchor.</summary>
        /// <summary>
        /// One end of the EHH span, signed. Rounds first so a value that displays as zero cannot
        /// come out as "-0.0", and signs both directions so the two ends of the range match.
        /// </summary>
        private static string FmtKb(double kb)
        {
            double r = Math.Round(kb, 1);
            if (r == 0.0) r = 0.0;   // collapses -0.0
            return (r > 0 ? "+" : "") + r.ToString("F1", CultureInfo.InvariantCulture);
        }

        private static string Fmt(double seconds)
        {
            if (seconds <= 0) return "—";
            if (seconds < 1) return (seconds * 1000).ToString("F0", CultureInfo.InvariantCulture) + " ms";
            return seconds.ToString("F2", CultureInfo.InvariantCulture) + " s";
        }

        /// <summary>
        /// Exports the current plot in one go (comment #2): the figure twice — <c>base.png</c>
        /// (raster) and <c>base.pdf</c> (true vector, journal-ready) — plus the data behind the
        /// curves. The data is one file per plotted result file, following the reference scripts:
        /// <c>base.bin.gz</c> for a single LD source, <c>base.&lt;PopID&gt;.bin.gz</c> per source
        /// when several are plotted (Plot_MultiPop.pl's <c>$output.$PopID</c>), and
        /// <c>base.ehh.gz</c> — or <c>base.&lt;curve&gt;.ehh.gz</c> — in the reference tool's own
        /// six-column layout when the plot is EHH. Two files plus one per source, in other words,
        /// which is why the log names them from what the writers actually returned.
        /// The canvas size — and therefore the aspect ratio, square through wide — comes from the
        /// 导出尺寸 / Export size (px) boxes; the file name and folder come from the save dialog.
        /// </summary>
        private void OnExportImage(object sender, RoutedEventArgs e)
        {
            if (!Plot.HasData || _lastSeries == null || _lastSeries.Count == 0)
            { Log(_english ? "No plot to export yet." : "暂无图可导出，请先生成图片。"); return; }

            var dlg = new SaveFileDialog
            {
                Filter = "Plot bundle: PNG + vector PDF + data|*.png",
                DefaultExt = "png",
                FileName = "LDdecay.png",
            };
            if (dlg.ShowDialog() != true) return;

            string basePath = dlg.FileName.EndsWith(".png", StringComparison.OrdinalIgnoreCase)
                ? dlg.FileName.Substring(0, dlg.FileName.Length - 4)
                : dlg.FileName;

            // Canvas size in px; ratio is fully user-chosen (e.g. 900×900 square, 1600×900 wide).
            // A bad value is reported, not silently replaced by a different size. The upper bound
            // is lower than the command line's (which writes only the PDF): the PNG is a bitmap
            // in memory, 4 bytes per pixel.
            int w, h;
            try
            {
                w = IntField(ExportWBox, _english ? "Export width" : "导出宽度", ParameterRules.CanvasMin, ParameterRules.PngCanvasMax);
                h = IntField(ExportHBox, _english ? "Export height" : "导出高度", ParameterRules.CanvasMin, ParameterRules.PngCanvasMax);
            }
            catch (ParameterInputException ex) { WarnParameter(ex); return; }

            // Every file the export writes is known before any is written; none may be one of
            // the result files on the chart (exporting a plotted table under its own name would
            // replace it with its re-binned copy).
            // The selected result files count too, including any the plot left out for having no points.
            string overwritten = PlotExport.OverwrittenInput(basePath, _lastSeries, true, _statFiles);
            if (overwritten != null)
            {
                Warn($"导出会覆盖所选的结果文件 {Path.GetFileName(overwritten)}，请换一个导出文件名。",
                     $"The export would overwrite {Path.GetFileName(overwritten)}, one of the selected result files — choose another name.");
                return;
            }

            try
            {
                // PNG: render a detached offscreen copy at the requested size, so the live
                // plot's layout is never disturbed (arranging the live element at export size
                // leaves it stuck there — WPF re-runs self-invalidated elements with the
                // cached constraint, which the manual Measure/Arrange would have clobbered).
                var offscreen = new DecayPlotView();
                offscreen.SetSeries(_lastSeries);
                offscreen.Measure(new Size(w, h));
                offscreen.Arrange(new Rect(0, 0, w, h));
                var rtb = new RenderTargetBitmap(w, h, 96, 96, PixelFormats.Pbgra32);
                rtb.Render(offscreen);
                var png = new PngBitmapEncoder();
                png.Frames.Add(BitmapFrame.Create(rtb));
                PopLD.Domain.IO.AtomicFile.Write(basePath + ".png", fs => png.Save(fs));

                // PDF: true vector output from the same shared layout (not a wrapped bitmap).
                // Base-14 Helvetica cannot carry CJK glyphs — warn instead of failing silently.
                foreach (var s in _lastSeries)
                {
                    string label = PlotLayout.TrimName(s.Name);
                    if (!PdfPlotWriter.CanEncode(label))
                        Log(_english
                            ? $"NOTE: \"{label}\" contains characters the PDF legend cannot show (replaced with '?'); PNG is unaffected. Consider ASCII file names."
                            : $"提示：图例“{label}”含 PDF 无法显示的字符（将以 ? 代替）；PNG 不受影响。建议使用英文文件名。");
                }
                PdfPlotWriter.Write(basePath + ".pdf", w, h, _lastSeries);

                // Data file(s). An EHH plot exports the reference tool's own *.ehh layout
                // (Chr/Site/Dist/EHH_all/EHH_0/EHH_1) rather than the reduced plot dump,
                // which would drop Site, EHH_0 and EHH_1 and rewrite distances in kb.
                // Collect the names as they are written: neither writer produces a single
                // predictable file — an EHH plot writes one per curve, and PlotDataWriter one
                // per SOURCE stat file — so a hardcoded ".bin.gz" would name a file that is not
                // on disk whenever more than one result file is plotted.
                var written = new List<string> { basePath + ".png", basePath + ".pdf" };
                var p = _lastPlotParams;
                written.AddRange(PlotExport.WriteData(basePath, _lastSeries, _lastMeasure, p.Bin1Bp, p.Bin2Bp, p.BreakBp));

                // One name per file, all in the folder the save dialog chose.
                var names = new List<string>(written.Count);
                foreach (var f in written) names.Add(Path.GetFileName(f));
                Log((_english
                        ? $"Exported {names.Count} file(s) at {w}×{h} to {Path.GetDirectoryName(basePath)}: "
                        : $"已导出 {names.Count} 个文件（{w}×{h}），目录 {Path.GetDirectoryName(basePath)}：")
                    + string.Join(", ", names));
            }
            catch (Exception ex) { Log((_english ? "Export failed: " : "导出失败：") + ex.Message); }
        }

        // ---- helpers ----
        private void OnToggleLanguage(object sender, RoutedEventArgs e)
        {
            _english = !_english;
            Title = _english
                ? "PopLDdecay GUI - Linkage Disequilibrium Decay Analysis"
                : "PopLDdecay GUI - 连锁不平衡衰减分析工具";
            Translate(this, _english);
            // These are composed in code, so they need re-rendering rather than tag lookup.
            ApplySampleScope();
            UpdateTiming();
            UpdatePlotHeader(_lastSeries);
            if (LogBox.Text == LogPlaceholderZh || LogBox.Text == LogPlaceholderEn)
                LogBox.Text = _english ? LogPlaceholderEn : LogPlaceholderZh;
            SetRunButtonLabel(_cts != null);
        }

        /// <summary>Swaps every Tag="中文|English" Button/TextBlock to the selected language.</summary>
        private static void Translate(DependencyObject node, bool en)
        {
            foreach (object child in LogicalTreeHelper.GetChildren(node))
            {
                if (!(child is DependencyObject d)) continue;
                if (d is Button b && b.Tag is string bt && bt.Contains("|"))
                    b.Content = bt.Split('|')[en ? 1 : 0];
                else if (d is TextBlock t && t.Tag is string tt && tt.Contains("|"))
                    t.Text = tt.Split('|')[en ? 1 : 0];
                else if (d is ComboBoxItem ci && ci.Tag is string cit && cit.Contains("|"))
                    ci.Content = cit.Split('|')[en ? 1 : 0];
                else if (d is RadioButton rb && rb.Tag is string rbt && rbt.Contains("|"))
                    rb.Content = rbt.Split('|')[en ? 1 : 0];
                Translate(d, en);
            }
        }

        /// <summary>
        /// Walks through the window as it is actually laid out: the numbered stages of the left
        /// rail, then the title-bar actions and the status bar underneath. Button names here are
        /// the ones on the controls, so the text can be followed literally.
        /// </summary>
        private void OnHelp(object sender, RoutedEventArgs e)
        {
            if (_english)
            {
                Log("The left rail runs top to bottom: stage 1 \"Data & Computation\", stage 2 \"Plot & Export\"; the chart fills the rest, with this log and the status bar below it.");
                Log("1) Stage 1: \"Browse\" a VCF, set the sample scope — \"All samples\", or \"Sample list\" and then \"Select\" the list file — and fill in MaxDist / MAF / Het / Miss.");
                Log("2) \"Analysis\" = what is COMPUTED: 1 = r², 2 = r² + D', 3 = EHH around an anchor site (\"EHH site\", written chr:pos) -> *.ehh.gz. Then press \"Run Analysis\"; it reads \"Cancel\" while the run is going, and the result is plotted as soon as it lands.");
                Log("   \"Unphased LD\" only matters for a VCF written with '/': \"PopLDdecay rule\" reproduces the original tool (each heterozygote read as major/minor); \"Maximum likelihood\" estimates each pair's haplotype frequencies from the genotypes and is less biased for outbred samples (written as *.ml.LDdecay.stat.gz). Phased ('|') VCFs always use their haplotypes.");
                Log("3) Stage 2 replots without recomputing: \"Select\" existing .stat.gz / .ehh.gz files and press \"Generate Plot\" (one kind at a time — LD and EHH axes differ).");
                Log("4) \"Binning & range\" (bin1 / bin2 / break / maxX) shapes the curve; editing MaxDist in stage 1 copies the value into maxX, which you can still adjust.");
                Log("5) \"Y axis\" = what is PLOTTED, and its choices come from the result files selected in stage 2 — NOT from the stage-1 \"Analysis\" setting. An r²-only file, or an EHH file, locks the box to that one statistic; a file computed with analysis type 2 offers r², D' and both on twin axes, starting on r² with D' one click away. So to plot D' it is enough to select a type-2 result file: nothing is recomputed, and the stage-1 setting does not have to be touched.");
                Log("6) \"Export Image+Data\" writes the figure twice at the \"Export size\" in px — <name>.png (raster)");
                Log("   and <name>.pdf (true vector, for journals) — plus the plotted values, ONE data file per");
                Log("   result file on the chart: <name>.bin.gz for a single LD file, <name>.<result>.bin.gz for each");
                Log("   of several; an EHH plot writes <name>.ehh.gz (one per curve) in the reference *.ehh layout.");
                Log("   So a one-file plot leaves 3 files and a three-file plot leaves 5; the log lists them by name.");
                Log("Title bar: \"Reset\" clears the file selections, the chart and the cached results; \"中文 / English\" switches language. A re-run with identical inputs and parameters is served from the CAIR cache instead of being recomputed.");
            }
            else
            {
                Log("左侧栏自上而下分为：第 1 步“数据与计算”、第 2 步“作图与导出”；右侧为图表区，下方是本日志面板与状态栏。");
                Log("1) 第 1 步：点“浏览”选择 VCF，选择样本范围——“全部样本”，或“指定样本列表”后再点“选择”指定列表文件——并填写 MaxDist / MAF / Het / Miss。");
                Log("2) “分析类型” = 算什么：1 = r²，2 = r² + D'，3 = EHH（在“EHH 位点”填锚点 chr:pos，输出 *.ehh.gz）。随后点“开始计算”，计算过程中该按钮显示“取消”，算完自动作图。");
                Log("   “非定相 LD”只对用 '/' 书写的 VCF 起作用：“PopLDdecay 规则”与原版一致（每个杂合子按主/次等位读取）；“最大似然”由基因型估计每对位点的单倍型频率，对异交群体偏差更小（结果写为 *.ml.LDdecay.stat.gz）。已定相（'|'）VCF 始终使用其单倍型。");
                Log("3) 第 2 步可只作图不重算：点“选择”载入已有 .stat.gz / .ehh.gz，再点“生成图形”（两类结果坐标轴不同，需分开作图）。");
                Log("4) “分箱与范围”（bin1 / bin2 / break / maxX）决定曲线形状；修改第 1 步的 MaxDist 会同步填入 maxX，之后仍可自行调整。");
                Log("5) “纵坐标” = 画什么：其可选项来自第 2 步已选的结果文件，而不是第 1 步的“分析类型”。仅含 r² 的文件、或 EHH 文件，会把纵坐标锁定为该项；由分析类型 2 生成的文件则可选 r²、D'、或两者同图（双坐标轴），默认停在 r²，改选 D' 只需一次点击。因此要画 D' 只需选中一个类型 2 的结果文件即可：既不会重新计算，也不必去改第 1 步的设置。");
                Log("6) “导出图片+数据”按“导出尺寸”(px) 导出两份图——<名称>.png（位图）与 <名称>.pdf（真矢量图，投稿用）——");
                Log("   外加曲线数值：图上每个结果文件各一份。LD 衰减单个文件为 <名称>.bin.gz，多个文件则每个生成");
                Log("   <名称>.<结果文件>.bin.gz；EHH 为 <名称>.ehh.gz（与原版 *.ehh 同格式，多条曲线各一份）。");
                Log("   因此单文件作图共 3 个文件，三文件作图共 5 个；日志会逐一列出实际文件名。");
                Log("标题栏：“复位”清空文件选择、当前图与全部缓存结果；“中文 / English”切换界面语言。输入与参数完全相同的重复运行会直接命中 CAIR 缓存，无需重算。");
            }
        }

        /// <summary>True when the analysis dropdown is on EHH (index 2).</summary>
        private bool EhhMode => OutTypeBox != null && SelectedOutType == LdOutputType.Ehh;

        /// <summary>The analysis the dropdown is on (r², r² + D', EHH in that order).</summary>
        private LdOutputType SelectedOutType
            => OutTypeBox.SelectedIndex == 2 ? LdOutputType.Ehh
             : OutTypeBox.SelectedIndex == 1 ? LdOutputType.R2AndDPrime
             : LdOutputType.R2;

        /// <summary>Reads the Y-axis choice from the box, defaulting to r².</summary>
        private PlotMeasure SelectedMeasure()
        {
            var item = MeasureBox == null ? null : MeasureBox.SelectedItem as ComboBoxItem;
            if (item == null) return PlotMeasure.R2;
            string tag = item.Tag as string ?? "";
            if (tag.StartsWith("两者", StringComparison.Ordinal)) return PlotMeasure.Both;
            return (item.Content as string) == "D'" ? PlotMeasure.DPrime : PlotMeasure.R2;
        }

        /// <summary>Plain label for the current Y-axis choice, so log lines quote the box
        /// instead of restating what the code is assumed to have selected.</summary>
        private string MeasureLabel()
        {
            // EHH is its own single choice and maps to PlotMeasure.R2, so read the item directly
            // rather than reporting "r²" for an EHH selection.
            var item = MeasureBox == null ? null : MeasureBox.SelectedItem as ComboBoxItem;
            if ((item == null ? null : item.Content as string) == "EHH") return "EHH";
            switch (SelectedMeasure())
            {
                case PlotMeasure.Both: return "r² + D'";
                case PlotMeasure.DPrime: return "D'";
                default: return "r²";
            }
        }

        private ComboBoxItem MeasureItem(string zh, string en)
            => new ComboBoxItem { Content = _english ? en : zh, Tag = zh + "|" + en };

        /// <summary>
        /// Offers exactly the statistics the plot can actually draw, and selects the sensible
        /// default. Once result files are selected the choices come from THEIR CONTENT, probed by
        /// <see cref="ResultFileProbe"/> — an EHH selection offers EHH, an r²-only .stat.gz offers
        /// r², and a file carrying D' offers r², D' and the twin-axis combination with r² selected,
        /// which is also the reference plotter's default (Plot_OnePop.pl:68, <c>$measure||="r2"</c>).
        /// D' is offered only when every selected file carries it, so a mixed set cannot ask for a
        /// curve that half the files lack.
        /// <para>With nothing selected yet the stage-1 analysis type stands in, so the box is never
        /// empty before any file has been picked. A file that cannot be read or parsed leaves all
        /// choices available and the mismatch is reported at plot time the way the reference
        /// reports it (Plot_OnePop.pl:626-631) — see <see cref="WarnNoDPrime"/>.</para>
        /// </summary>
        /// <param name="dataChanged">
        /// True when the result-file selection itself just changed, which resets the axis to the
        /// default for the new data (r², or EHH). False for an incidental rebuild, where an
        /// explicit D' choice the user made is kept if the new list still offers it.
        /// </param>
        private void ApplyMeasureOptions(bool dataChanged = false)
        {
            if (MeasureBox == null || OutTypeBox == null) return;

            // What the box should offer: driven by the selected files, else by the stage-1 type.
            bool ehh, withDPrime;
            if (_statFiles.Count > 0)
            {
                switch (ResultFileProbe.ProbeAll(_statFiles))
                {
                    case ResultContent.Ehh: ehh = true; withDPrime = false; break;
                    case ResultContent.R2Only: ehh = false; withDPrime = false; break;
                    case ResultContent.R2AndDPrime: ehh = false; withDPrime = true; break;
                    default: ehh = false; withDPrime = true; break;   // unreadable: stay permissive
                }
            }
            else
            {
                ehh = SelectedOutType == LdOutputType.Ehh;
                withDPrime = SelectedOutType == LdOutputType.R2AndDPrime;
            }

            // Preserve the user's choice across a rebuild when the new list still offers it, so
            // re-probing after an unrelated change does not silently reset D' back to r².
            PlotMeasure keep = SelectedMeasure();
            bool hadItems = MeasureBox.Items.Count > 0;

            MeasureBox.Items.Clear();
            if (ehh)
            {
                MeasureBox.Items.Add(MeasureItem("EHH", "EHH"));
            }
            else
            {
                MeasureBox.Items.Add(MeasureItem("r²", "r²"));
                if (withDPrime)
                {
                    MeasureBox.Items.Add(MeasureItem("D'", "D'"));
                    MeasureBox.Items.Add(MeasureItem("两者（双坐标轴）", "Both (twin axes)"));
                }
            }

            int index = 0;   // r² (or EHH) — the default for newly loaded data, D'-capable or not
            if (!dataChanged && hadItems && !ehh && withDPrime)
            {
                if (keep == PlotMeasure.DPrime) index = 1;
                else if (keep == PlotMeasure.Both) index = 2;
            }
            MeasureBox.SelectedIndex = index;
            MeasureBox.IsEnabled = MeasureBox.Items.Count > 1;
        }

        /// <summary>Y-axis choices in the current language, for the log line after a re-probe.</summary>
        private string MeasureChoices()
        {
            var names = new List<string>(MeasureBox.Items.Count);
            foreach (var o in MeasureBox.Items)
            {
                var it = o as ComboBoxItem;
                if (it != null) names.Add(it.Content as string ?? "");
            }
            return string.Join(_english ? " / " : "、", names.ToArray());
        }

        /// <summary>
        /// Shows the anchor-site box and its hint only for EHH. The binning controls stay
        /// visible but are ignored in EHH mode, which plots every SNP in the region unbinned.
        /// </summary>
        private void OnOutTypeChanged(object sender, SelectionChangedEventArgs e)
        {
            if (EhhSitePanel == null) return;   // during InitializeComponent
            var vis = EhhMode ? Visibility.Visible : Visibility.Collapsed;
            EhhSitePanel.Visibility = vis;
            EhhHint.Visibility = vis;
            if (UnphasedPanel != null)
                UnphasedPanel.Visibility = EhhMode ? Visibility.Collapsed : Visibility.Visible;
            ApplyMeasureOptions();
            if (!IsInitialized) return;
            if (EhhMode)
                Log(_english
                    ? "Analysis: EHH — enter the anchor site as chr:pos (e.g. 22:17000000). Output is *.ehh.gz."
                    : "分析类型：EHH — 请填写锚点位点 chr:pos（如 22:17000000），输出 *.ehh.gz。");
            else if (OutTypeBox.SelectedIndex != 1)
                Log(_english ? "Analysis: LD decay, r²." : "分析类型：LD 衰减，r²。");
            // ApplyMeasureOptions has just rebuilt the Y-axis box, so report what it actually
            // ended up on instead of promising D': computing D' does not select it, exactly as
            // the reference plotter keeps -measure at r2 whatever -OutType produced the file
            // (Plot_OnePop.pl:68 "$measure||=\"r2\"").
            else if (MeasureBox.Items.Count > 1)
                Log(_english
                    ? $"Analysis: LD decay, r² and D'. Y axis is set to {MeasureLabel()}; change it in stage 2 to plot the other."
                    : $"分析类型：LD 衰减，r² 与 D'；当前纵坐标为 {MeasureLabel()}，可在第 2 步更改。");
            else
                // The Y-axis box is following the result files ALREADY selected in stage 2, which
                // carry only one statistic, so it offers nothing to switch to. Saying "change it
                // in stage 2" here would send the user after a choice that is not on the box —
                // and changing the analysis type cannot put it there, only new results can.
                Log(_english
                    ? $"Analysis: LD decay, r² and D'. The Y axis follows the result files selected in stage 2, which offer {MeasureLabel()} only; this run's own results will offer D' once they land."
                    : $"分析类型：LD 衰减，r² 与 D'。纵坐标取决于第 2 步已选的结果文件，当前仅可选 {MeasureLabel()}；本次计算的结果写出后即可改选 D'。");
        }

        private bool UnphasedMl => UnphasedBox != null && UnphasedBox.SelectedIndex == 1;

        private void OnUnphasedChanged(object sender, SelectionChangedEventArgs e)
        {
            if (!IsInitialized) return;
            Log(UnphasedMl
                ? (_english
                    ? "Unphased LD: maximum likelihood — haplotype frequencies of each SNP pair are estimated from the genotypes. Phased VCFs are unaffected; results are written as *.ml.LDdecay.stat.gz."
                    : "非定相 LD：最大似然——由基因型估计每对 SNP 的单倍型频率。已定相 VCF 不受影响；结果写为 *.ml.LDdecay.stat.gz。")
                : (_english
                    ? "Unphased LD: PopLDdecay rule — each heterozygote is read as (major, minor), identical to the original tool. For outbred samples this inflates background r² and misses repulsion-phase LD."
                    : "非定相 LD：PopLDdecay 规则——每个杂合子按（主, 次）等位读取，与原版完全一致。对异交群体会抬高背景 r²，并丢失反向连锁。"));
        }

        private void SetBusy(bool busy)
        {
            SetRunButtonLabel(busy);
            // The analysis inputs are fixed for the run (they were read when it started), so their
            // controls are locked until it ends; Cancel, Reset and the plot side stay usable.
            foreach (var c in new Control[]
                     { BrowseVcfBtn, ScopeAllBox, ScopeSingleBox, SampleListBtn, MaxDistBox, MafBox,
                       HetBox, MissBox, OutTypeBox, UnphasedBox, EhhBox })
                c.IsEnabled = !busy;
            Progress.IsIndeterminate = busy;   // animated marquee = clearly "working"
            if (!busy) Progress.Value = 0;
            if (busy) SetStatus("计算中…", "Running…", "Accent");
            else if (_outcome == RunOutcome.Failed) SetStatus("失败", "Failed", "WarnCol");
            else if (_outcome == RunOutcome.Cancelled) SetStatus("已取消", "Cancelled", "WarnCol");
            // A warning raised during the run (Warn) has to survive the return to idle: the run
            // did finish, but not cleanly, and a green "Ready" would hide that.
            else if (_outcome == RunOutcome.Warning) SetStatus("已完成，有警告", "Finished with warnings", "WarnCol");
            else SetStatus("就绪", "Ready", "OkCol");
        }

        private void SetRunButtonLabel(bool running)
        {
            if (running)
            {
                GenBtn.Content = _english ? "Cancel" : "取消";
                GenBtn.Tag = "取消|Cancel";
            }
            else
            {
                GenBtn.Content = _english ? "Run Analysis" : "开始计算";
                GenBtn.Tag = "开始计算|Run Analysis";
            }
        }

        /// <summary>A parameter box holding something the analysis cannot use, in both languages.</summary>
        private sealed class ParameterInputException : Exception
        {
            public readonly string Zh, En;
            public ParameterInputException(string zh, string en) : base(en) { Zh = zh; En = en; }
        }

        /// <summary>A whole number in [min, max] from a box, by the rules the command line applies.</summary>
        private static int IntField(TextBox box, string name, int min, int max)
        {
            string t = box.Text;
            if (!ParameterRules.TryParseInteger(t, out int v))
                throw new ParameterInputException($"{name} 需要整数，当前为“{t}”", ParameterRules.NotAnInteger(name, t));
            string bad = ParameterRules.CheckRange(name, v, min, max);
            if (bad != null)
                throw new ParameterInputException($"{name} 应在 {min} 到 {max} 之间，当前为 {v}", bad);
            return v;
        }

        /// <summary>
        /// A number in [min, max] from a box. '.' is the decimal point on every machine; a comma is
        /// refused rather than read as a thousands separator ("0,005" would otherwise become 5).
        /// </summary>
        private static double NumField(TextBox box, string name, double min, double max)
        {
            var inv = CultureInfo.InvariantCulture;
            string t = box.Text;
            if (!ParameterRules.TryParseNumber(t, out double v))
                throw new ParameterInputException($"{name} 需要数字（小数点请用英文句点“.”），当前为“{t}”",
                    ParameterRules.NotANumber(name, t));
            string bad = ParameterRules.CheckRange(name, v, min, max);
            if (bad != null)
                throw new ParameterInputException(
                    $"{name} 应在 {min.ToString(inv)} 到 {max.ToString(inv)} 之间，当前为 {v.ToString(inv)}", bad);
            return v;
        }

        /// <summary>Every parameter of a run (stage 1 and the plot drawn after it), validated.</summary>
        private AnalysisParameters ReadParameters()
        {
            var p = ReadPlotParameters();
            p.MaxDistKb = IntField(MaxDistBox, "MaxDist(kb)", ParameterRules.MaxDistKbMin, ParameterRules.MaxDistKbMax);
            p.Maf = NumField(MafBox, "MAF", ParameterRules.MafMin, ParameterRules.MafMax);
            p.Het = NumField(HetBox, "Het", ParameterRules.HetMin, ParameterRules.HetMax);
            p.Miss = NumField(MissBox, "Miss", ParameterRules.MissMin, ParameterRules.MissMax);
            p.EhhSite = string.IsNullOrWhiteSpace(EhhBox.Text) ? null : EhhBox.Text.Trim();
            p.OutType = SelectedOutType;
            p.UnphasedEstimator = UnphasedMl ? UnphasedLdEstimator.MaximumLikelihood : UnphasedLdEstimator.PopLDdecay;
            return p;
        }

        /// <summary>
        /// Only the plot's own parameters (bin1, bin2, break, maxX), validated. Re-plotting existing
        /// files does not depend on the analysis boxes, so a half-typed MAF cannot block it.
        /// </summary>
        private AnalysisParameters ReadPlotParameters()
        {
            return new AnalysisParameters
            {
                Bin1Bp = IntField(Bin1Box, "bin1", ParameterRules.BinMin, ParameterRules.BinMax),
                Bin2Bp = IntField(Bin2Box, "bin2", ParameterRules.BinMin, ParameterRules.BinMax),
                BreakBp = IntField(BreakBox, "break", ParameterRules.BreakMin, ParameterRules.BreakMax),
                MaxXKb = IntField(MaxXBox, "maxX", ParameterRules.MaxXKbMin, ParameterRules.MaxXKbMax),
            };
        }

        /// <summary>Replaces every character a file name cannot hold (and ':') with '_'.</summary>
        private static string SafeNamePart(string s)
        {
            char[] bad = Path.GetInvalidFileNameChars();
            var sb = new System.Text.StringBuilder(s.Length);
            foreach (char c in s) sb.Append(c == ':' || Array.IndexOf(bad, c) >= 0 ? '_' : c);
            return sb.ToString();
        }

        /// <summary>The output prefix for one input; the rule is in <see cref="ResultNaming"/>.</summary>
        private static string PrefixFor(string dir, string baseName, bool ehh, string vcf, string sampleList)
            => ResultNaming.PrefixFor(dir, baseName, ehh, vcf, sampleList);

        private static string StripVcf(string name)
        {
            if (name.EndsWith(".vcf.gz", StringComparison.OrdinalIgnoreCase)) return name.Substring(0, name.Length - 7);
            if (name.EndsWith(".vcf", StringComparison.OrdinalIgnoreCase)) return name.Substring(0, name.Length - 4);
            return name;
        }
    }
}
