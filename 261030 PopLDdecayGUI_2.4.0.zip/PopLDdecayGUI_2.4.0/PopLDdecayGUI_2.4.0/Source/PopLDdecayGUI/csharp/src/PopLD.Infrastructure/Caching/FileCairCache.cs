using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Security.Cryptography;
using System.Text;
using PopLD.Domain.Abstractions;
using PopLD.Domain.IO;
using PopLD.Domain.Services;

namespace PopLD.Infrastructure.Caching
{
    /// <summary>
    /// File-based CAIR store. Each entry is two files under the cache root:
    /// <c>&lt;key&gt;.stat.gz</c> (the result) and <c>&lt;key&gt;.meta</c> (its MaxDist, the
    /// SHA-256 of the result file, and the warnings and notes its run reported about the input,
    /// which a hit hands back so they are reported again). A request is served from an entry whose MaxDist is >= the
    /// requested one; if strictly larger, the stat file is distance-truncated on the way out, so
    /// no pairwise work reruns.
    /// <para>Robustness: an entry is served only if its data still matches the recorded hash,
    /// and a damaged or incomplete entry is deleted and reported as a miss (the run then
    /// recomputes and stores a fresh one) instead of failing every later run with the same key.
    /// Entries and served outputs are written atomically, and a named mutex keeps the GUI and the
    /// command line — which share this folder — from working on it at the same time.</para>
    /// </summary>
    public sealed class FileCairCache : ICacheStore
    {
        /// <summary>How long to wait for another process using the cache before doing without it.</summary>
        private static readonly TimeSpan LockTimeout = TimeSpan.FromSeconds(60);

        private readonly string _root;
        private readonly string _mutexName;

        public FileCairCache(string root)
        {
            _root = root;
            Directory.CreateDirectory(_root);
            _mutexName = NamedLock.NameFor("cache", _root);
        }

        private string DataPath(string key) => Path.Combine(_root, key + ".stat.gz");
        private string MetaPath(string key) => Path.Combine(_root, key + ".meta");

        public bool TryServe(string key, int requestedMaxDistBp, string outputStatPath, out IReadOnlyList<string> inputNotices)
        {
            IReadOnlyList<string> notices = null;
            bool served = WithLock(() =>
            {
                string data = DataPath(key), meta = MetaPath(key);
                Meta m;
                FileStream src;
                // Reading the entry is the cache's business: a failure here is a miss for the
                // caller. Writing the output below is the run's: a failure there is its own.
                try
                {
                    if (!File.Exists(data) || !File.Exists(meta)) return false;
                    m = ReadMeta(meta);
                    // An entry without its hash or its notices (written by an older build, or the
                    // meta write was interrupted), or whose data no longer matches the hash,
                    // cannot be trusted: drop it and recompute.
                    if (!m.Complete || !string.Equals(HashFile(data), m.Sha256, StringComparison.Ordinal))
                    {
                        Evict(key);
                        return false;
                    }
                    if (m.MaxDistBp < requestedMaxDistBp) return false;
                    src = new FileStream(data, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16);
                }
                catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException)
                {
                    throw new CacheUnavailableException("the cached result could not be read: " + ex.Message, ex);
                }

                try
                {
                    using (src)
                    {
                        if (m.MaxDistBp == requestedMaxDistBp)
                            AtomicFile.Write(outputStatPath, s => src.CopyTo(s));
                        else
                            AtomicFile.Write(outputStatPath, s => TruncateByDistance(src, s, requestedMaxDistBp));
                    }
                }
                catch (InvalidDataException)
                {
                    // The data hashed correctly but is not a valid stat file — never written by
                    // this store as such; treat the entry as damaged.
                    Evict(key);
                    return false;
                }
                notices = m.Notices;
                return true;
            }, false);
            inputNotices = served ? notices : new string[0];
            return served;
        }

        public void Put(string key, string statPath, int maxDistBp, IReadOnlyList<string> inputNotices)
        {
            WithLock(() =>
            {
                // (AtomicFile re-creates the folder should it have been removed since.)
                // Never trade a wider entry for a narrower one: an entry computed at a larger MaxDist
                // can serve every smaller request by truncation, so overwriting it with a
                // force-recomputed short run would lose reach for no gain.
                string meta = MetaPath(key), data = DataPath(key);
                if (File.Exists(meta) && File.Exists(data))
                {
                    Meta m = ReadMeta(meta);
                    if (m.Complete && m.MaxDistBp > maxDistBp &&
                        string.Equals(HashFile(data), m.Sha256, StringComparison.Ordinal))
                        return true;
                }
                string hash = null;
                AtomicFile.Write(data, s =>
                {
                    using (var src = File.OpenRead(statPath))
                    using (var sha = SHA256.Create())
                    using (var hashing = new CryptoStream(s, sha, CryptoStreamMode.Write))
                    {
                        src.CopyTo(hashing);
                        hashing.FlushFinalBlock();
                        hash = CacheKey.Hex(sha.Hash);
                    }
                });
                var inv = CultureInfo.InvariantCulture;
                var text = new StringBuilder();
                text.Append("maxDistBp=").Append(maxDistBp.ToString(inv)).Append('\n');
                text.Append("sha256=").Append(hash).Append('\n');
                text.Append("createdUtc=").Append(DateTime.UtcNow.ToString("o", inv)).Append('\n');
                int count = inputNotices?.Count ?? 0;
                text.Append("notices=").Append(count.ToString(inv)).Append('\n');
                for (int i = 0; i < count; i++)
                    text.Append("notice=").Append(OneLine(inputNotices[i])).Append('\n');
                // UTF-8 round-trips any text (sample names in a notice are Latin-1 decoded bytes).
                AtomicFile.WriteAllText(meta, text.ToString(), new UTF8Encoding(false));
                return true;
            }, false);
        }

        /// <summary>
        /// Deletes every cache entry — result, meta, and any data file left without its meta or
        /// temporary file left by an interrupted write — and returns the number of entries removed
        /// (counted by meta files). Files locked by another process are skipped rather than
        /// aborting the whole reset. Unlike a lookup, a reset that cannot get at the cache must
        /// say so: it throws <see cref="IOException"/> rather than report "0 removed".
        /// </summary>
        public int Clear()
        {
            if (!Directory.Exists(_root)) return 0;
            const int Busy = -1;
            int removedOrBusy = WithLock(() =>
            {
                int removed = 0;
                foreach (var meta in Directory.GetFiles(_root, "*.meta"))
                {
                    try
                    {
                        // Key may itself contain dots, so strip the exact ".meta" suffix.
                        string data = meta.Substring(0, meta.Length - ".meta".Length) + ".stat.gz";
                        if (File.Exists(data)) File.Delete(data);
                        File.Delete(meta);
                        removed++;
                    }
                    catch (IOException) { }
                    catch (UnauthorizedAccessException) { }
                }
                foreach (var pattern in new[] { "*.stat.gz", "*.tmp" })
                    foreach (var f in Directory.GetFiles(_root, pattern))
                        AtomicFile.TryDelete(f);
                return removed;
            }, Busy);
            if (removedOrBusy == Busy)
                throw new IOException("the result cache is in use by another PopLDdecay process; try the reset again when it has finished");
            return removedOrBusy;
        }

        private void Evict(string key)
        {
            AtomicFile.TryDelete(MetaPath(key));
            AtomicFile.TryDelete(DataPath(key));
        }

        /// <summary>
        /// Runs <paramref name="body"/> holding the cache's cross-process mutex. If another
        /// process holds it longer than <see cref="LockTimeout"/>, the cache is skipped
        /// (<paramref name="whenBusy"/>): a slow cache must never stall an analysis.
        /// </summary>
        private T WithLock<T>(Func<T> body, T whenBusy)
        {
            // A mutex that cannot be opened (another account's: an elevated and a normal instance
            // at once) counts as busy too, rather than failing the run.
            T result = whenBusy;
            NamedLock.TryRun(_mutexName, LockTimeout, () => result = body(), out _);
            return result;
        }

        private sealed class Meta
        {
            public int MaxDistBp = -1;
            public string Sha256;
            public int NoticeCount = -1;
            public readonly List<string> Notices = new List<string>();

            /// <summary>Every field present, and as many notices as the count says.</summary>
            public bool Complete => MaxDistBp >= 0 && Sha256 != null && Notices.Count == NoticeCount;
        }

        private static string OneLine(string s) => (s ?? "").Replace('\r', ' ').Replace('\n', ' ');

        private static Meta ReadMeta(string metaPath)
        {
            var m = new Meta();
            foreach (var line in File.ReadAllLines(metaPath, new UTF8Encoding(false)))
            {
                if (line.StartsWith("maxDistBp=", StringComparison.Ordinal) &&
                    int.TryParse(line.Substring("maxDistBp=".Length), NumberStyles.Integer, CultureInfo.InvariantCulture, out int v))
                    m.MaxDistBp = v;
                else if (line.StartsWith("sha256=", StringComparison.Ordinal) && line.Length == "sha256=".Length + 64)
                    m.Sha256 = line.Substring("sha256=".Length);
                else if (line.StartsWith("notices=", StringComparison.Ordinal) &&
                         int.TryParse(line.Substring("notices=".Length), NumberStyles.None, CultureInfo.InvariantCulture, out int c))
                    m.NoticeCount = c;
                else if (line.StartsWith("notice=", StringComparison.Ordinal))
                    m.Notices.Add(line.Substring("notice=".Length));
            }
            return m;
        }

        private static string HashFile(string path)
        {
            using (var sha = SHA256.Create())
            using (var fs = File.OpenRead(path))
                return CacheKey.Hex(sha.ComputeHash(fs));
        }

        /// <summary>Copies only rows with Dist &lt;= limit (rows are ascending by distance).</summary>
        private static void TruncateByDistance(Stream srcGz, Stream dst, int limitBp)
        {
            var inv = CultureInfo.InvariantCulture;
            using (var inGz = new GZipStream(srcGz, CompressionMode.Decompress, true))
            using (var r = new StreamReader(inGz, TextInput.Latin1))
            using (var outGz = new GZipStream(dst, CompressionLevel.Optimal, true))
            using (var w = new StreamWriter(outGz, TextInput.Latin1))
            {
                string line;
                while ((line = r.ReadLine()) != null)
                {
                    if (line.Length == 0) continue;
                    if (line[0] == '#') { w.Write(line); w.Write('\n'); continue; }
                    int tab = line.IndexOf('\t');
                    if (!int.TryParse(tab < 0 ? line : line.Substring(0, tab), NumberStyles.Integer, inv, out int dist))
                        throw new InvalidDataException("cached result has a malformed row");
                    if (dist > limitBp) break;
                    w.Write(line); w.Write('\n');
                }
            }
        }
    }
}
