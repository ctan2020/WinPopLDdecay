namespace PopLD.Domain.IO
{
    /// <summary>
    /// CRC-32 (IEEE 802.3, the polynomial gzip uses), slicing-by-8. Used to check each BGZF block
    /// and each gzip member against its trailer, as zlib checks every member it inflates.
    /// </summary>
    public static class Crc32
    {
        private static readonly uint[] Table = Build();

        private static uint[] Build()
        {
            var t = new uint[8 * 256];
            for (uint i = 0; i < 256; i++)
            {
                uint c = i;
                for (int k = 0; k < 8; k++) c = (c & 1) != 0 ? 0xEDB88320u ^ (c >> 1) : c >> 1;
                t[i] = c;
            }
            for (int i = 0; i < 256; i++)
                for (int s = 1; s < 8; s++)
                    t[s * 256 + i] = (t[(s - 1) * 256 + i] >> 8) ^ t[t[(s - 1) * 256 + i] & 0xFF];
            return t;
        }

        /// <summary>CRC-32 of <paramref name="count"/> bytes of <paramref name="data"/> from <paramref name="offset"/>.</summary>
        public static uint Compute(byte[] data, int offset, int count) => Append(0, data, offset, count);

        /// <summary>
        /// The CRC-32 of some data followed by these bytes, given <paramref name="crc"/>, the CRC-32
        /// of that data (0 for none) — zlib's <c>crc32(crc, buf, len)</c>.
        /// </summary>
        public static uint Append(uint crc, byte[] data, int offset, int count)
        {
            crc = ~crc;
            uint[] t = Table;
            int i = offset, end = offset + count;
            for (; i + 8 <= end; i += 8)
            {
                uint lo = crc ^ (uint)(data[i] | data[i + 1] << 8 | data[i + 2] << 16 | data[i + 3] << 24);
                crc = t[7 * 256 + (lo & 0xFF)] ^ t[6 * 256 + ((lo >> 8) & 0xFF)] ^
                      t[5 * 256 + ((lo >> 16) & 0xFF)] ^ t[4 * 256 + (lo >> 24)] ^
                      t[3 * 256 + data[i + 4]] ^ t[2 * 256 + data[i + 5]] ^
                      t[1 * 256 + data[i + 6]] ^ t[data[i + 7]];
            }
            for (; i < end; i++) crc = t[(crc ^ data[i]) & 0xFF] ^ (crc >> 8);
            return ~crc;
        }
    }
}
