using System;
using System.Security.Cryptography;
using System.Text;

namespace PopLD.Domain.Integrity
{
    /// <summary>
    /// Who this build is attributed to, in a form that can be checked rather than merely read.
    /// <para>The attribution is a fixed statement plus an ECDSA P-256 signature over it, made once
    /// with a private key that is not part of this source tree and ships in no binary. Only the
    /// public half is here, so a build can verify the statement and cannot forge one — editing the
    /// author name in this file breaks the signature instead of changing the answer.</para>
    /// <para>Nothing here touches a file the tool writes. It is read out on request and that is
    /// all it does.</para>
    /// </summary>
    public static class Authorship
    {
        // Public half of the key pair, as the two 32-byte coordinates. Publishing it costs
        // nothing: it verifies a signature and cannot produce one.
        private const string PublicQx = "dkpGmKro+qLeJv2siB+QR1o2K9rPb9NQDhbVXiwRfTI=";
        private const string PublicQy = "f3rlcaPScG2smYo3Xdn7Q3535kjir5Pa24vJinS3F5A=";

        /// <summary>SHA-256 over the two public coordinates, first 8 bytes — names the key pair.</summary>
        public const string KeyFingerprint = "cad77d6f914848b5";

        // Folded against a derived pad so a plain string scan of the binary does not list the
        // name; the pad is computed, not stored. Tidiness rather than secrecy — the signature,
        // not this, is what makes the attribution stand up.
        private const string PadSeed = "PopLDdecay.mark.pad.v1";
        private const string AuthorFolded = "kxrKycE/E7gFDA==";

        // Signature over Statement, made once with the private half.
        private const string StatementSignature =
            "K6kbTN82DQ0DLrS0CcbVp8cWDDPnZleFXdfSYnUH5fvMdnVUtpLxJ9I9R+CiIIJEVCO+RjJKMtoshX8uS7WMTA==";

        /// <summary>Who this build attributes itself to.</summary>
        public static string Author => Encoding.UTF8.GetString(Unfold(AuthorFolded));

        /// <summary>The exact bytes the shipped signature covers.</summary>
        public static string Statement =>
            "PopLDdecay-Authorship-v1|" + Author + "|" + KeyFingerprint;

        /// <summary>
        /// Checks the shipped signature against the shipped public key. False means the constants
        /// above have been edited: the pair only agrees for the holder of the private half.
        /// </summary>
        public static bool Verify()
        {
            try
            {
                using (var ec = ECDsa.Create())
                {
                    ec.ImportParameters(new ECParameters
                    {
                        Curve = ECCurve.NamedCurves.nistP256,
                        Q = new ECPoint
                        {
                            X = Convert.FromBase64String(PublicQx),
                            Y = Convert.FromBase64String(PublicQy),
                        },
                    });
                    return ec.VerifyData(Encoding.UTF8.GetBytes(Statement),
                                         Convert.FromBase64String(StatementSignature),
                                         HashAlgorithmName.SHA256);
                }
            }
            catch
            {
                // A platform without P-256 through CNG cannot answer the question; "not verified"
                // is the only honest report, and it is never worth taking the process down for.
                return false;
            }
        }

        private static byte[] Unfold(string folded)
        {
            byte[] v = Convert.FromBase64String(folded);
            byte[] pad;
            using (var sha = SHA256.Create()) pad = sha.ComputeHash(Encoding.UTF8.GetBytes(PadSeed));
            for (int i = 0; i < v.Length; i++) v[i] ^= pad[i % pad.Length];
            return v;
        }
    }
}
