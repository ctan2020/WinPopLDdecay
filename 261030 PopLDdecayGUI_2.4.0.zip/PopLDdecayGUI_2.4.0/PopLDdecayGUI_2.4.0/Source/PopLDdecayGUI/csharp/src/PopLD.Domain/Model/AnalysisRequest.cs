using System.Collections.Generic;

namespace PopLD.Domain.Model
{
    /// <summary>
    /// A single unit of work: one or more VCF inputs, an optional sub-population
    /// sample list, the parameters, and where the result should be written.
    /// </summary>
    public sealed class AnalysisRequest
    {
        public IReadOnlyList<string> VcfPaths { get; set; } = new List<string>();

        /// <summary>Optional sub-population sample-list file (SubPop). Null = all samples.</summary>
        public string SampleListPath { get; set; }

        public AnalysisParameters Parameters { get; set; } = new AnalysisParameters();

        /// <summary>Output prefix; the engine writes "&lt;prefix&gt;.stat.gz".</summary>
        public string OutputPrefix { get; set; }

        /// <summary>When true, skip cache lookup and recompute unconditionally (the fresh
        /// result still refreshes the cache). Lets users override CAIR when in doubt.</summary>
        public bool BypassCache { get; set; }
    }

    /// <summary>Outcome of one analysis run.</summary>
    public sealed class AnalysisResult
    {
        public bool Success { get; set; }
        public string StatFilePath { get; set; }
        public string Message { get; set; }
        public long PairsEvaluated { get; set; }

        /// <summary>True when the result was served from the CAIR cache (no recomputation).</summary>
        public bool FromCache { get; set; }

        /// <summary>Degree of parallelism the engine actually used (0 if served from cache).</summary>
        public int DegreeOfParallelism { get; set; }

        /// <summary>
        /// Where the LD values came from: "phased haplotypes", "PopLDdecay rule (unphased)" or
        /// "maximum likelihood (unphased)". Null when nothing was computed (cache hit, EHH).
        /// </summary>
        public string LdEstimator { get; set; }

        /// <summary>
        /// The "warning: …" and "note: …" progress lines the run reported about its input
        /// (sample-list names missing from the VCF, malformed records, …). They depend only on
        /// what the cache key holds, so they are stored with a cached result and reported again
        /// when it is served: the same input must give the same warnings, computed or not.
        /// </summary>
        public IReadOnlyList<string> InputNotices { get; set; }

        /// <summary>Per-step wall-clock timings (seconds); 0 when served from cache.</summary>
        public double ReadSeconds { get; set; }
        public double PairwiseSeconds { get; set; }
        public double WriteSeconds { get; set; }
    }
}
