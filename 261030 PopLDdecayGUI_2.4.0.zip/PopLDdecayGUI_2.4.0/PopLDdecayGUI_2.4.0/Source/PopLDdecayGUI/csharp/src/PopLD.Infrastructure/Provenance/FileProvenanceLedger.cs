using System;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using PopLD.Domain.Abstractions;
using PopLD.Domain.Model;
using PopLD.Domain.Services;

namespace PopLD.Infrastructure.Provenance
{
    /// <summary>
    /// Append-only, tab-separated reproducibility ledger. One line per run; greppable and
    /// diffable, no database. Each line starts with an id: the first 16 hex digits of the
    /// SHA-256 of the rest of the line. The line includes its timestamp, so the id identifies
    /// one record (one run), not the analysis — two identical runs get two ids; the cache key in
    /// the line is what identical analyses share.
    /// <para>The GUI and the command line append to the same file, so writers take a named,
    /// cross-process mutex and retry briefly while another process holds the file. A writer
    /// that cannot get the mutex in time writes nothing and throws an <see cref="IOException"/>:
    /// the caller reports the run as not recorded.</para>
    /// </summary>
    public sealed class FileProvenanceLedger : IProvenanceLedger
    {
        private readonly string _logPath;
        private readonly string _mutexName;
        private readonly TimeSpan _lockTimeout;

        public FileProvenanceLedger(string root) : this(root, TimeSpan.FromSeconds(30)) { }

        /// <param name="lockTimeout">How long a writer waits for another one to finish.</param>
        public FileProvenanceLedger(string root, TimeSpan lockTimeout)
        {
            Directory.CreateDirectory(root);
            _logPath = Path.Combine(root, "provenance.log");
            _mutexName = NamedLock.NameFor("ledger", _logPath);
            _lockTimeout = lockTimeout;
        }

        /// <summary>The cross-process mutex every writer of this ledger takes.</summary>
        public string MutexName => _mutexName;

        public string Append(ProvenanceRecord r)
        {
            string line = string.Join("\t",
                r.TimestampUtc,
                r.ToolVersion,
                r.CacheHit ? "cache" : "compute",
                "key=" + r.CacheKey,
                "pairs=" + r.PairsEvaluated.ToString(CultureInfo.InvariantCulture),
                "dop=" + r.DegreeOfParallelism.ToString(CultureInfo.InvariantCulture),
                "sec=" + r.ElapsedSeconds.ToString("F2", CultureInfo.InvariantCulture),
                "out=" + r.OutputPath,
                "in=[" + r.Inputs + "]",
                "params=[" + r.Parameters + "]");

            string id = CacheKey.Sha256Hex(line).Substring(0, 16);
            byte[] bytes = new UTF8Encoding(false).GetBytes(id + "\t" + line + Environment.NewLine);

            // Without the mutex another writer may be mid-line, so never write then.
            switch (NamedLock.TryRun(_mutexName, _lockTimeout, () => AppendHolding(bytes), out Exception error))
            {
                case NamedLock.Result.Busy:
                    throw new IOException("the provenance ledger " + _logPath + " is held by another process (waited " +
                                          _lockTimeout.TotalSeconds.ToString("0.#", CultureInfo.InvariantCulture) + " s)");
                case NamedLock.Result.Unopenable:
                    throw new IOException("the lock of the provenance ledger cannot be opened: " + error.Message, error);
            }
            return id;
        }

        private void AppendHolding(byte[] bytes)
        {
            // Even with the mutex, an external program (an editor, a backup tool) may hold the
            // file for a moment; retry before giving up.
            for (int attempt = 0; ; attempt++)
            {
                try
                {
                    using (var fs = new FileStream(_logPath, FileMode.Append, FileAccess.Write, FileShare.Read))
                        fs.Write(bytes, 0, bytes.Length);
                    return;
                }
                catch (IOException) when (attempt < 10)
                {
                    Thread.Sleep(100);
                }
            }
        }
    }
}
