using System;
using System.IO;
using System.Text;
using System.Threading;

namespace PopLD.Domain.IO
{
    /// <summary>
    /// Writes a file so that it is either the complete new content or still the previous file:
    /// the content goes to a temporary file in the same folder, which then replaces the target.
    /// A run that fails or is killed while writing therefore never leaves a half-written result
    /// where a complete one used to be.
    /// </summary>
    public static class AtomicFile
    {
        /// <summary>Writes <paramref name="path"/> through <paramref name="write"/>, atomically.</summary>
        public static void Write(string path, Action<Stream> write)
        {
            string full = Path.GetFullPath(path);
            string dir = Path.GetDirectoryName(full);
            if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
            string tmp = full + "." + Guid.NewGuid().ToString("N").Substring(0, 12) + ".tmp";
            bool existed = File.Exists(full);
            try
            {
                using (var fs = new FileStream(tmp, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1 << 16))
                    write(fs);
                Replace(tmp, full);
            }
            catch
            {
                // If the previous file is gone (a replacement that failed halfway and could not be
                // undone), the temporary file is the only copy of the result left: keep it.
                if (!existed || File.Exists(full)) TryDelete(tmp);
                throw;
            }
        }

        /// <summary>Writes text atomically.</summary>
        public static void WriteAllText(string path, string text, Encoding encoding)
        {
            byte[] bytes = encoding.GetBytes(text);
            Write(path, s => s.Write(bytes, 0, bytes.Length));
        }

        private const int ReplaceAttempts = 5;

        /// <summary>
        /// Moves <paramref name="source"/> over <paramref name="destination"/>; if that fails, the
        /// previous destination is still there. File.Replace is the atomic path. It is given a
        /// backup name, because without one a ReplaceFile that fails halfway may delete the old
        /// file (ERROR_UNABLE_TO_MOVE_REPLACEMENT); with one, the old file is either in place or
        /// under that name, and is put back. A sharing violation — a virus scanner or sync client
        /// opening the new file the moment it was closed — is usually brief, so it is retried.
        /// Where the volume cannot replace files, the old one is renamed aside, the new one moved
        /// in, and the old one put back if that fails. A read-only target is refused, not forced.
        /// </summary>
        public static void Replace(string source, string destination)
        {
            string backup = destination + "." + Guid.NewGuid().ToString("N").Substring(0, 12) + ".old.tmp";
            for (int attempt = 1; ; attempt++)
            {
                try
                {
                    // Re-checked on every attempt: a failed attempt may have left the target gone.
                    if (!File.Exists(destination)) File.Move(source, destination);
                    else File.Replace(source, destination, backup, true);
                    TryDelete(backup);
                    return;
                }
                catch (Exception ex) when (ex is IOException || ex is UnauthorizedAccessException ||
                                           ex is PlatformNotSupportedException)
                {
                    Restore(backup, destination);
                    if (ex is IOException && attempt < ReplaceAttempts && File.Exists(source))
                    {
                        Thread.Sleep(100 * attempt);
                        continue;
                    }
                    if (ex is UnauthorizedAccessException || !File.Exists(source) || !File.Exists(destination))
                        throw;
                    MoveAside(source, destination);
                    return;
                }
            }
        }

        /// <summary>Puts the old file back from its backup name if a failed replace left it there.</summary>
        private static void Restore(string backup, string destination)
        {
            if (!File.Exists(backup) || File.Exists(destination)) return;
            try { File.Move(backup, destination); }
            catch (IOException) { }                 // the old content stays under the backup name
            catch (UnauthorizedAccessException) { }
        }

        private static void MoveAside(string source, string destination)
        {
            string aside = destination + "." + Guid.NewGuid().ToString("N").Substring(0, 12) + ".tmp";
            File.Move(destination, aside);
            try
            {
                File.Move(source, destination);
            }
            catch
            {
                try { File.Move(aside, destination); }
                catch (IOException) { }               // the old content stays under the aside name
                catch (UnauthorizedAccessException) { }
                throw;
            }
            TryDelete(aside);
        }

        /// <summary>Deletes a file if it exists, ignoring failure (clean-up paths only).</summary>
        public static void TryDelete(string path)
        {
            try { if (File.Exists(path)) File.Delete(path); }
            catch (IOException) { }
            catch (UnauthorizedAccessException) { }
        }
    }
}
