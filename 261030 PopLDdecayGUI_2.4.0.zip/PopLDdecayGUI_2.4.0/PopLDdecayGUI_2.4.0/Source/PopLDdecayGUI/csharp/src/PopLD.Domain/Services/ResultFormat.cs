using System.Globalization;
using System.IO;

namespace PopLD.Domain.Services
{
    /// <summary>
    /// The original's result layouts, shared by the engine, which writes them from an analysis,
    /// and the plot export, which writes them back from what was read.
    /// </summary>
    public static class ResultFormat
    {
        /// <summary>The header line of a <c>*.stat.gz</c> and of the binned table a plot exports.</summary>
        public const string StatHeader = "#Dist\tMean_r^2\tMean_D'\tSum_r^2\tSum_D'\tNumberPairs\n";

        /// <summary>The two header lines of a <c>*.ehh.gz</c> holding <paramref name="snps"/> rows.</summary>
        public static void WriteEhhHeader(TextWriter w, int snps)
        {
            w.Write("#Chr\tSite\tDist\tEHH_all\tEHH_0\tEHH_1\n");
            w.Write("#SNP_Number\t" + snps.ToString(CultureInfo.InvariantCulture) + "\n");
        }

        /// <summary>One <c>*.ehh.gz</c> row, the values at the original's four decimals.</summary>
        public static void WriteEhhRow(TextWriter w, string chrom, long site, long dist,
            double all, double allele0, double allele1)
        {
            var inv = CultureInfo.InvariantCulture;
            w.Write(chrom); w.Write('\t');
            w.Write(site.ToString(inv)); w.Write('\t');
            w.Write(dist.ToString(inv)); w.Write('\t');
            w.Write(FixedFormat.F4(all, inv)); w.Write('\t');
            w.Write(FixedFormat.F4(allele0, inv)); w.Write('\t');
            w.Write(FixedFormat.F4(allele1, inv)); w.Write('\n');
        }
    }
}
