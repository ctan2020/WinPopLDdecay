using System;
using System.IO;

namespace PopLD.Domain.Abstractions
{
    /// <summary>
    /// The cache itself could not be read: an entry held open by another program, a cache folder
    /// that has become unreadable. <see cref="ICacheStore.TryServe"/> throws it so the caller can
    /// treat the lookup as a miss and compute instead. Any other exception from TryServe is about
    /// the output it was asked to write, which a computed run could not write either.
    /// </summary>
    public sealed class CacheUnavailableException : IOException
    {
        public CacheUnavailableException(string message, Exception inner) : base(message, inner) { }
    }
}
