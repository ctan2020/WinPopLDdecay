using System;
using System.Collections.Generic;
using System.IO;

namespace PopLD.Infrastructure.Plotting
{
    /// <summary>The statistic an LD-decay plot draws (the original's <c>-measure</c>).</summary>
    public enum PlotMeasure { R2, DPrime, Both }

    /// <summary>
    /// What happened to each file while a plot was loaded, reported in the order it happened.
    /// The GUI turns these into bilingual log lines and warnings, the command line into stdout and
    /// stderr lines; the decisions themselves are made once, in <see cref="PlotLoader"/>.
    /// </summary>
    public interface IPlotLoadReport
    {
        /// <summary>Rows of <paramref name="curve"/> were left out for a NaN or infinite value.</summary>
        void NonFinite(string file, DecayPoints curve);

        /// <summary>The file is a table exported by an earlier version and was binned again.</summary>
        void OlderExport(string file);

        /// <summary>The file gave no usable point at all and is left out.</summary>
        void NoPoints(string file, bool ehh);

        /// <summary>No bin carried a D'. <paramref name="leftOut"/>: nothing of the file is drawn.</summary>
        void NoDPrime(string file, bool leftOut);

        /// <summary>r² + D': the file has no usable r², so only its D' is drawn.</summary>
        void NoR2(string file);

        /// <summary>
        /// The file's curves were added (r² before D'). <paramref name="drawn"/> is "EHH", "r² and D'",
        /// "r² only", "D' only", or the measure of a single curve.
        /// </summary>
        void Loaded(string file, IReadOnlyList<DecayPoints> curves, string drawn);
    }

    /// <summary>The curves of one plot and the files they came from.</summary>
    public sealed class PlotLoad
    {
        public readonly List<DecayPoints> Series = new List<DecayPoints>();

        /// <summary>The files that contributed at least one curve, in the order given.</summary>
        public readonly List<string> Plotted = new List<string>();

        /// <summary>One curve per exported table among the inputs (those are plotted as written).</summary>
        public List<DecayPoints> Tables()
        {
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var tables = new List<DecayPoints>();
            foreach (var s in Series)
                if (s.TableRows != null && seen.Add(s.SourcePath)) tables.Add(s);
            return tables;
        }
    }

    /// <summary>
    /// Reads the files of one plot the same way for the command line and the GUI: EHH results as
    /// written, LD results binned in the chosen statistic; curves without a point are left out (a
    /// legend entry over nothing would read as a result); on an r² + D' chart the axes are chosen
    /// for the whole chart.
    /// </summary>
    public static class PlotLoader
    {
        /// <summary>
        /// Marks which files are EHH results (by name or header) and returns how many are. EHH and
        /// LD decay share no axis, so the callers refuse a mix before reading anything.
        /// </summary>
        public static int ClassifyEhh(IReadOnlyList<string> files, out bool[] isEhh)
        {
            isEhh = new bool[files.Count];
            int n = 0;
            for (int i = 0; i < files.Count; i++)
                if (isEhh[i] = ResultFileProbe.IsEhh(files[i])) n++;
            return n;
        }

        /// <summary>The measure as the exported table's parameter comment writes it.</summary>
        public static string Describe(PlotMeasure measure)
            => measure == PlotMeasure.Both ? "r^2+D'" : measure == PlotMeasure.DPrime ? "D'" : "r^2";

        /// <summary>A result file's name without ".stat.gz" or ".ehh.gz", as legends show it.</summary>
        public static string Stem(string path)
        {
            string n = Path.GetFileName(path);
            if (n.EndsWith(".stat.gz", StringComparison.OrdinalIgnoreCase)) return n.Substring(0, n.Length - 8);
            if (n.EndsWith(".ehh.gz", StringComparison.OrdinalIgnoreCase)) return n.Substring(0, n.Length - 7);
            return n;
        }

        public static PlotLoad Load(IReadOnlyList<string> files, bool[] isEhh, PlotMeasure measure,
            int bin1Bp, int bin2Bp, int breakBp, int maxXbp, IPlotLoadReport report)
        {
            var load = new PlotLoad();
            for (int fi = 0; fi < files.Count; fi++)
            {
                string f = files[fi];
                // EHH results are per-SNP and two-sided, so they are read, not binned.
                if (isEhh[fi])
                {
                    var e = EhhFileReader.Read(f);
                    if (e.SkippedNonFinite > 0) report.NonFinite(f, e);
                    // An .ehh.gz whose rows are all comments or unusable would join the chart as an
                    // invisible curve and a caption spanning "0.0 … 0.0 kb".
                    if (e.XKb.Length == 0) { report.NoPoints(f, true); continue; }
                    Add(load, f, report, "EHH", e);
                    continue;
                }
                if (measure == PlotMeasure.Both)
                {
                    // r² on the left axis, D' on the right (the original's "-measure both").
                    var r2 = StatFileBinner.ReadBinned(f, bin1Bp, bin2Bp, breakBp, maxXbp, false);
                    var dp = StatFileBinner.ReadBinned(f, bin1Bp, bin2Bp, breakBp, maxXbp, true);
                    r2.Name = Stem(f) + " r²";
                    dp.Name = Stem(f) + " D'";
                    if (r2.SkippedNonFinite > 0) report.NonFinite(f, r2);
                    if (r2.OlderExport) report.OlderExport(f);
                    if (dp.SkippedNonFinite > 0) report.NonFinite(f, dp);
                    bool haveR2 = r2.XKb.Length > 0, haveDPrime = dp.XKb.Length > 0;
                    if (!haveR2 && !haveDPrime) { report.NoPoints(f, false); continue; }
                    // Each curve stands on its own: a file whose r² rows were all unusable still
                    // shows its D' (which axis it goes on is settled for the whole chart below).
                    if (!haveR2) report.NoR2(f);
                    if (!haveDPrime) report.NoDPrime(f, false);
                    var curves = new List<DecayPoints>(2);
                    if (haveR2) curves.Add(r2);
                    if (haveDPrime) curves.Add(dp);
                    // Name what was drawn: a file without D' contributes r² alone.
                    Add(load, f, report, haveR2 && haveDPrime ? "r² and D'" : haveR2 ? "r² only" : "D' only", curves.ToArray());
                    continue;
                }

                var pts = StatFileBinner.ReadBinned(f, bin1Bp, bin2Bp, breakBp, maxXbp, measure == PlotMeasure.DPrime);
                if (pts.SkippedNonFinite > 0) report.NonFinite(f, pts);
                if (pts.OlderExport) report.OlderExport(f);
                if (pts.XKb.Length == 0)
                {
                    // For D' the reference plotter refuses the same combination outright
                    // (Plot_OnePop.pl:626-631, where "$Cal_D==0" means no bin carried a D'); an
                    // empty r² means the file itself yielded no bins.
                    if (measure == PlotMeasure.DPrime) report.NoDPrime(f, true);
                    else report.NoPoints(f, false);
                    continue;
                }
                Add(load, f, report, pts.Measure, pts);
            }
            if (measure == PlotMeasure.Both) PlotLayout.AssignTwinAxes(load.Series);
            return load;
        }

        private static void Add(PlotLoad load, string file, IPlotLoadReport report, string drawn, params DecayPoints[] curves)
        {
            load.Series.AddRange(curves);
            load.Plotted.Add(file);
            report.Loaded(file, curves, drawn);
        }
    }
}
