using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using PopLD.Domain.Abstractions;
using PopLD.Domain.IO;
using PopLD.Domain.Model;
using PopLD.Domain.Services;

namespace PopLD.Infrastructure.Io
{
    /// <summary>
    /// File-based result store (no database). Keeps the original on-disk formats and
    /// writes a per-run provenance sidecar next to each result for reproducibility.
    /// </summary>
    public sealed class FileResultRepository : IResultRepository
    {
        /// <summary>Version stamped into every provenance sidecar (read from the assembly).</summary>
        public static string ToolVersion => PopLD.Domain.ToolInfo.Version;

        public void WriteProvenance(AnalysisRequest request, AnalysisResult result)
        {
            if (result == null || string.IsNullOrEmpty(result.StatFilePath))
                return;

            // Numbers in the invariant culture ("0.005" on every machine — a German or French
            // Windows would otherwise write "0,005"), doubles round-trip.
            var inv = CultureInfo.InvariantCulture;
            var p = request.Parameters;
            var w = new StringBuilder();
            void Line(string name, string value) => w.Append(name).Append('\t').Append(value).Append('\n');

            w.Append("# PopLDdecayGUI run provenance\n");
            Line("timestamp", DateTime.UtcNow.ToString("o", inv));
            Line("tool_version", ToolVersion);
            Line("input", string.Join(";", request.VcfPaths));
            if (!string.IsNullOrEmpty(request.SampleListPath))
                Line("sampleList", request.SampleListPath);
            Line("maxDistKb", p.MaxDistKb.ToString(inv));
            Line("maf", p.Maf.ToString("R", inv));
            Line("het", p.Het.ToString("R", inv));
            Line("miss", p.Miss.ToString("R", inv));
            Line("outType", ((int)p.OutType).ToString(inv));
            bool ehh = p.OutType == LdOutputType.Ehh;
            if (ehh)
                Line("ehhSite", p.EhhSite ?? "");
            else
            {
                // The estimator the numbers came from, spelled as the CLI's --unphased value — taken
                // from what the engine applied, not from what was asked: on a phased VCF an "ml"
                // request changes nothing, and the record must describe the file beside it.
                string requested = p.UnphasedEstimator == UnphasedLdEstimator.MaximumLikelihood ? "ml" : "popld";
                string applied = AppliedEstimator(result.LdEstimator);
                Line("unphasedEstimator", applied ?? requested);
                if (applied != null && applied != requested)
                    Line("unphasedEstimatorRequested", requested);
                if (p.IgnorePhase)
                    Line("ignorePhase", "true");
                if (!string.IsNullOrEmpty(result.LdEstimator))
                    Line("ldEstimator", result.LdEstimator);
            }
            // For EHH this counts the fully-called SNP used, not SNP pairs. A cached result is
            // replayed without evaluating anything, so report the original's missing-value
            // token "NA" (FileDeal.h:1347) instead of a literal 0, which would read as "this
            // file was produced from no pairs at all".
            Line(ehh ? "sitesUsed" : "pairsEvaluated", result.FromCache ? "NA" : result.PairsEvaluated.ToString(inv));
            // Threads the pairwise step ran on (1 = the fixed, sequential summation order).
            Line("degreeOfParallelism", result.FromCache ? "NA" : result.DegreeOfParallelism.ToString(inv));
            // Whether the neighbouring result file was just computed or replayed from the CAIR
            // cache. A cache hit rewrites the .stat.gz too (truncated when the cached run was
            // wider), so the sidecar is rewritten on both paths and this line says which one
            // produced the bytes on disk.
            Line("resultSource", result.FromCache ? "cache" : "computed");

            AtomicFile.WriteAllText(OutputPaths.ProvenanceFor(result.StatFilePath), w.ToString(), new UTF8Encoding(false));
        }

        /// <summary>"none (phased input)", "ml" or "popld" from the engine's estimator description; null if unknown.</summary>
        private static string AppliedEstimator(string ldEstimator)
        {
            switch (ldEstimator)
            {
                case "phased haplotypes": return "none (phased input)";
                case "maximum likelihood (unphased)": return "ml";
                case "PopLDdecay rule (unphased)": return "popld";
                default: return null;
            }
        }
    }
}
