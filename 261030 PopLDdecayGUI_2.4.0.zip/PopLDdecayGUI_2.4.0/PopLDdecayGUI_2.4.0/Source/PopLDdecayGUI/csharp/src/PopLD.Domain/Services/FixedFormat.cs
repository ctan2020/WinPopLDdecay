using System;
using System.Globalization;
using System.Numerics;

namespace PopLD.Domain.Services
{
    /// <summary>
    /// Prints a double the way the original tool's C++ does. Every numeric column of the
    /// <c>.stat</c> and <c>.ehh</c> files is written with
    /// <c>setprecision(4) &lt;&lt; setiosflags(ios::fixed)</c> (FileDeal.h:1347/1361,
    /// EHHDeal.h), which libstdc++ routes to <c>snprintf("%.4f")</c>: the EXACT binary value of
    /// the double is rounded once, and a value that is exactly a midpoint goes to even.
    /// <para>
    /// Neither .NET spelling reproduces that. <c>ToString("F4")</c> rounds midpoints away from
    /// zero, and <c>Math.Round(v, 4, ToEven)</c> is worse: it scales by 10^4 first, which turns a
    /// value one ulp ABOVE a midpoint into an exact tie and then rounds it the wrong way — e.g.
    /// the reachable r² value 0.30625000000000002… prints as 0.3063 in C++ and 0.3062 that way.
    /// So the digits are derived here from the double's own bits, exactly.
    /// </para>
    /// </summary>
    public static class FixedFormat
    {
        private const int Scale = 10000;   // 4 decimals

        /// <summary>Formats <paramref name="v"/> exactly as C's <c>%.4f</c> does.</summary>
        public static string F4(double v, IFormatProvider provider)
        {
            if (double.IsNaN(v)) return "nan";
            if (double.IsInfinity(v)) return v > 0 ? "inf" : "-inf";

            bool negative = v < 0 || (v == 0.0 && 1.0 / v < 0);
            BigInteger scaled = ScaledRoundHalfEven(Math.Abs(v));

            BigInteger whole = BigInteger.Divide(scaled, Scale);
            int frac = (int)(scaled - whole * Scale);

            string text = whole.ToString(provider) + "." + frac.ToString("D4", provider);
            // C prints "-0.0000" for a negative value that rounds to zero, and so does this.
            return negative ? "-" + text : text;
        }

        /// <summary>
        /// Returns round-half-to-even(<paramref name="v"/> * 10^4) computed on the double's exact
        /// value. A finite double is mantissa × 2^exponent, so the product is an exact rational
        /// and the comparison against the midpoint is exact — no intermediate rounding anywhere.
        /// </summary>
        private static BigInteger ScaledRoundHalfEven(double v)
        {
            if (v == 0.0) return BigInteger.Zero;

            long bits = BitConverter.DoubleToInt64Bits(v);
            int rawExponent = (int)((bits >> 52) & 0x7FF);
            long rawMantissa = bits & 0xFFFFFFFFFFFFFL;

            // Normal numbers carry an implicit leading 1; subnormals do not and sit one exponent up.
            BigInteger mantissa;
            int exponent;
            if (rawExponent == 0)
            {
                mantissa = rawMantissa;
                exponent = -1074;
            }
            else
            {
                mantissa = rawMantissa | (1L << 52);
                exponent = rawExponent - 1075;
            }

            BigInteger numerator = mantissa * Scale;
            if (exponent >= 0) return numerator << exponent;   // exact integer, nothing to round

            BigInteger denominator = BigInteger.One << (-exponent);
            BigInteger remainder;
            BigInteger quotient = BigInteger.DivRem(numerator, denominator, out remainder);

            int twiceRemainder = (remainder << 1).CompareTo(denominator);
            if (twiceRemainder > 0) return quotient + 1;
            if (twiceRemainder < 0) return quotient;
            return quotient.IsEven ? quotient : quotient + 1;   // exact tie -> to even
        }
    }
}
