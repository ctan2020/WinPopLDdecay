using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using PopLD.Domain.IO;
using PopLD.Domain.Model;

namespace PopLD.Infrastructure.Plotting
{
    /// <summary>
    /// One row of an EHH result, kept alongside the plotted curve so an export can reproduce
    /// the reference tool's six-column <c>*.ehh</c> file instead of a reduced plot dump.
    /// </summary>
    public struct EhhRow
    {
        public string Chrom;
        public long Site;
        public long Dist;
        public double All;
        public double Allele0;
        public double Allele1;
    }

    /// <summary>
    /// One bin of the reference plotter's table: the sums and pair counts the original
    /// <c>*.bin</c> file carries (Plot_OnePop.pl, the MeanBin section, lines 590-623). Kept
    /// alongside the plotted curve so an export can reproduce that file exactly rather than a
    /// reduced two-column plot dump.
    /// </summary>
    public struct BinRow
    {
        /// <summary>Bin distance in bp — the bin's EXCLUSIVE upper edge <c>(k+1)*bin</c>, which
        /// is the x the reference prints (Plot_OnePop.pl lines 601/606/616/621).</summary>
        public long DistBp;
        /// <summary>Σ Sum_r^2 over the file rows in this bin (<c>hash_RR_sum</c>/<c>Small_RR_sum</c>).</summary>
        public double SumR2;
        /// <summary>Σ Sum_D' over the rows whose D' column is not "NA" (<c>hash_D_sum</c>/<c>Small_D_sum</c>).</summary>
        public double SumD;
        /// <summary>Σ NumberPairs (<c>hash_cout</c>/<c>Small_cout</c>) — the divisor of Mean_r^2.</summary>
        public long PairsR2;
        /// <summary>Σ NumberPairs over the rows that carried a D' (<c>hash_coutV2</c>/
        /// <c>Small_coutV2</c>) — the divisor of Mean_D', and a separate counter from
        /// <see cref="PairsR2"/>. 0 means the bin has no D' at all, which prints as "NA".</summary>
        public long PairsD;
    }

    /// <summary>Binned decay curve ready for plotting: distance (kb) vs bin-mean r² or D'.</summary>
    public sealed class DecayPoints
    {
        /// <summary>Full EHH rows behind this curve; null for LD-decay series.</summary>
        public EhhRow[] EhhRows;

        /// <summary>The data rows of an exported table this curve was read from as written (see
        /// <c>StatFileBinner.ReadTable</c>), kept verbatim so a re-export writes the same table;
        /// null otherwise. Such a series has no <see cref="Bins"/>.</summary>
        public string[] TableRows;

        /// <summary>The parameter comment of that table (without its '#'): the binning that made it.</summary>
        public string TableParams;

        /// <summary>Full binned table behind this curve, in the reference plotter's own row
        /// order (fine grid first, then coarse); null for EHH series, which are not binned.
        /// Holds every bin, including the ones past <see cref="MaxXKb"/> — the reference never
        /// drops bins, -maxX only crops the view.</summary>
        public BinRow[] Bins;

        /// <summary>The <c>.stat.gz</c> this curve was binned from. Two series read from one
        /// file (r² and D' on twin axes) share it and therefore share one exported table.</summary>
        public string SourcePath;

        public string Name;
        public double[] XKb;
        public double[] Y;
        /// <summary>Statistic the Y values carry: "r²" (default), "D'" or "EHH".</summary>
        public string Measure = "r²";
        /// <summary>Left edge of the X axis in kb. 0 for LD decay; negative for EHH, whose
        /// curve extends to both sides of the anchor site.</summary>
        public double MinXKb;
        /// <summary>Plot this series against the secondary (right-hand) Y axis. Used when r²
        /// and D' share one chart: they have different natural ranges.</summary>
        public bool UseRightAxis;
        public double MaxXKb;
        public double MaxY;
        /// <summary>X-axis caption; defaults to plain distance, EHH overrides it.</summary>
        public string XAxisLabel = "Distance (kb)";
        /// <summary>Rows of the file left out of this curve because the plotted value, its pair
        /// count or its distance was not a finite number (NaN, infinity). Callers report it: a
        /// curve that lost rows, or that has none left, must not pass for a complete plot.</summary>
        public int SkippedNonFinite;
        /// <summary>The file is a table exported by a version before this one (its parameter
        /// comment is the last line, not line 2). It was binned again like a result file, which
        /// moves every point one bin to the right and may change D'; callers warn.</summary>
        public bool OlderExport;
    }

    /// <summary>
    /// Reads a PopLDdecay <c>.stat.gz</c> file and re-bins it the way <c>ReadFile2HashV2</c> does
    /// in the reference plotter (Plot_OnePop.pl lines 784-866): TWO INDEPENDENT bin grids, both
    /// anchored at 0 — a row with Dist &gt;= break goes to bin int(Dist/bin2), every other row to
    /// bin int(Dist/bin1) — so no bin ever straddles the break point. Mean over a bin is
    /// sum(Sum_stat)/sum(NumberPairs), so binning stays statistically faithful.
    /// <para>All three of the reference's row layouts are accepted, chosen from the header the
    /// same way (see <see cref="StatLayout"/>): the 6-field MeanBin file a core -OutType 1/2 run
    /// writes, and the pair-wise 3- and 5-field files of -OutType 5 / -OutType 4.</para>
    /// </summary>
    public static class StatFileBinner
    {
        /// <summary>Accumulators for one bin: the four hashes <c>ReadFile2HashV2</c> fills.</summary>
        private sealed class Acc
        {
            public double SumR2, SumD;
            public long PairsR2, PairsD;
        }

        /// <summary>Perl's bare <c>split</c> cuts on runs of whitespace and drops empty fields.</summary>
        internal static readonly char[] FieldSep = { ' ', '\t' };

        /// <summary>
        /// Row layout of a reference result file. <c>ReadFile2HashV2</c> picks one from the field
        /// count of line 1 and nothing else (Plot_OnePop.pl lines 770-782), and each layout gets
        /// its own accumulate rule, so the same header drives the reader here.
        /// </summary>
        internal enum StatLayout
        {
            /// <summary>6 fields, <c>#Dist Mean_r^2 Mean_D' Sum_r^2 Sum_D' NumberPairs</c> — what
            /// a core <c>-OutType 1/2</c> run writes and what this tool exports.</summary>
            MeanBin,
            /// <summary>3 fields, <c>#Dist R^2 R^2_count</c> — core <c>-OutType 5</c>
            /// (PariWiseCal.h line 46).</summary>
            R2Count,
            /// <summary>5 fields, <c>#Dist R^2 R^2_count D' D_count</c> — core <c>-OutType 4</c>
            /// (PariWiseCal.h line 120).</summary>
            R2AndDCount,
        }

        public static DecayPoints ReadBinned(string statGzPath, int bin1Bp, int bin2Bp, int breakBp, int maxXbp)
            => ReadBinned(statGzPath, bin1Bp, bin2Bp, breakBp, maxXbp, false);

        /// <summary>
        /// <paramref name="dPrime"/> selects the statistic: false = r², true = D' (written only by
        /// OutType 2 and OutType 4 runs; an OutType 1 file carries "NA" in that column and an
        /// OutType 5 file has no such column, so both yield an empty series — which callers
        /// should surface to the user).
        /// <para><paramref name="maxXbp"/> never filters data. In both reference scripts -maxX
        /// only reaches R as <c>xlim=c(0,maxX)</c>: the whole stat file is binned and every bin
        /// is emitted, so the value here just sets <see cref="DecayPoints.MaxXKb"/>, the plotted
        /// x range. Pass 0 to get the reference's default — the largest Dist in the file.</para>
        /// <para>A bin width or break point of 0 means the default (10, 100, 100), exactly as the
        /// reference reads it: <c>$bin1||=10; $bin2||=100; $break||=100</c> (Plot_OnePop.pl:64-67).
        /// The file may be gzipped or plain text; the content decides, as Perl's reader handles
        /// both.</para>
        /// </summary>
        public static DecayPoints ReadBinned(string statGzPath, int bin1Bp, int bin2Bp, int breakBp, int maxXbp, bool dPrime)
        {
            int bin1 = ParameterRules.EffectiveBin(bin1Bp, ParameterRules.DefaultBin1);   // $Small_bin
            int bin2 = ParameterRules.EffectiveBin(bin2Bp, ParameterRules.DefaultBin2);   // $bin
            int brk = ParameterRules.EffectiveBreak(breakBp);                            // $break
            var fine = new Dictionary<long, Acc>();     // Small_* : rows with Dist <  break
            var coarse = new Dictionary<long, Acc>();   // hash_*  : rows with Dist >= break
            long maxDistBp = 0;                         // $maxX_tmp
            // Rows whose r² (or D') could not be used: a NaN or infinity in the value, its pair
            // count or its distance. The reference would add the NaN into the bin and plot an
            // invisible point; here the row is left out of that statistic and counted, so the
            // caller can say so — and a file with nothing finite in it yields an empty curve.
            int skippedR2 = 0, skippedD = 0;
            bool trailingParams = false;

            using (var r = TextInput.OpenText(statGzPath, 1 << 16))
            {
                // Line 1 names the layout, exactly as in the reference; it is a '#' line, so the
                // loop below would have skipped it anyway.
                StatLayout layout = DetectLayout(r.ReadLine(), statGzPath);

                // This tool's own exported table says so on line 2 (PlotDataWriter). It is already
                // binned, so it is read as written rather than binned a second time.
                string line = r.ReadLine();
                if (layout == StatLayout.MeanBin && line != null &&
                    line.StartsWith(PlotDataWriter.ParamsCommentPrefix, StringComparison.Ordinal))
                    return ReadTable(r, statGzPath, line, maxXbp, dPrime);

                for (; line != null; line = r.ReadLine())
                {
                    // The reference skips every line carrying a '#' (next if ($_=~s/#/#/)),
                    // which covers the header and any comment row wherever it sits. A parameter
                    // comment as the LAST line is how earlier versions wrote their exported
                    // tables; such a table is binned again here, and the caller says so.
                    if (line.Length == 0) continue;
                    if (line.IndexOf('#') >= 0)
                    {
                        if (line.StartsWith(PlotDataWriter.ParamsCommentPrefix, StringComparison.Ordinal)) trailingParams = true;
                        continue;
                    }
                    trailingParams = false;
                    string[] f = line.Split(FieldSep, StringSplitOptions.RemoveEmptyEntries);

                    long pairs, pairsD;
                    double sumR2, sumD;
                    // The value can be used; the row carries that statistic at all.
                    bool r2Ok, dOk, hasR2 = true, hasD;
                    if (layout == StatLayout.MeanBin)
                    {
                        // Dist \t Mean_r^2 \t Mean_D' \t Sum_r^2 \t Sum_D' \t NumberPairs
                        if (f.Length < 6) continue;
                        // $inf[-1] NumberPairs, $inf[-2] Sum_D', $inf[-3] Sum_r^2 — the reference
                        // indexes from the end of the row, so trailing columns cannot shift them.
                        bool pairsOk = TryCount(f[f.Length - 1], out pairs);
                        // "NA" for r² means the row has none, as it does for D' below. The
                        // reference never writes it; this tool's own table does, for a bin that
                        // only D' reached, so such a table reads back as it was written.
                        string rText = f[f.Length - 3];
                        hasR2 = rText != "NA";
                        if (hasR2) r2Ok = TryNum(rText, out sumR2) & pairsOk;
                        else { sumR2 = 0; r2Ok = false; }
                        // D' has its own counter: only rows whose Sum_D' is not "NA" feed it, and
                        // Mean_D' divides by that counter, not by NumberPairs.
                        string dText = f[f.Length - 2];
                        hasD = dText != "NA";
                        if (hasD) { pairsD = pairs; dOk = TryNum(dText, out sumD) & pairsOk; }
                        else { pairsD = 0; sumD = 0; dOk = false; }
                    }
                    else
                    {
                        // The pair-wise layouts hold ALREADY-MEANED values with their own counts,
                        // indexed from the FRONT, and the reference re-weights each value by its
                        // count so that sum/count still comes out as the mean: cout += $inf[2],
                        // RR_sum += $inf[1]*$inf[2] (lines 826-834), and for the 5-field layout
                        // also coutV2 += $inf[4], D_sum += $inf[4]*$inf[3] (lines 851-863).
                        hasD = layout == StatLayout.R2AndDCount;
                        if (f.Length < (hasD ? 5 : 3)) continue;
                        r2Ok = TryCount(f[2], out pairs) & TryNum(f[1], out double r2);
                        sumR2 = r2 * pairs;
                        if (hasD) { dOk = TryCount(f[4], out pairsD) & TryNum(f[3], out double d); sumD = d * pairsD; }
                        else { pairsD = 0; sumD = 0; dOk = false; }
                    }

                    if (!TryCount(f[0], out long dist)) { r2Ok = false; dOk = false; }
                    if (hasR2 && !r2Ok) skippedR2++;
                    if (hasD && !dOk) skippedD++;
                    if (!r2Ok && !dOk) continue;
                    if (dist > maxDistBp) maxDistBp = dist;

                    // The two grids are independent and both start at 0; a bin never spans the
                    // break, which is why the old "walk a cursor from 0" scheme disagreed
                    // whenever break was not an exact multiple of both bin sizes.
                    Dictionary<long, Acc> grid;
                    long key;
                    if (dist >= brk) { grid = coarse; key = dist / bin2; }
                    else { grid = fine; key = dist / bin1; }

                    Acc a;
                    if (!grid.TryGetValue(key, out a)) { a = new Acc(); grid.Add(key, a); }
                    if (r2Ok) { a.PairsR2 += pairs; a.SumR2 += sumR2; }
                    if (dOk) { a.PairsD += pairsD; a.SumD += sumD; }
                }
            }

            var bins = new List<BinRow>(fine.Count + coarse.Count);
            AppendBins(fine, bin1, bins);     // the reference prints the fine grid first (lines 594-608)
            AppendBins(coarse, bin2, bins);   // then the coarse grid (lines 610-623)

            var xs = new List<double>(bins.Count);
            var ys = new List<double>(bins.Count);
            double maxY = 0;
            for (int i = 0; i < bins.Count; i++)
            {
                BinRow b = bins[i];
                double y;
                if (dPrime)
                {
                    // No D' in this bin: the reference row reads "NA" there and R plots nothing
                    // for it, so it contributes no point to the D' curve.
                    if (b.PairsD <= 0) continue;
                    y = b.SumD / b.PairsD;
                }
                else
                {
                    // A bin that only D' reached (every r² in it unusable) has no r² point.
                    if (b.PairsR2 <= 0) continue;
                    y = b.SumR2 / b.PairsR2;
                }
                xs.Add(b.DistBp / 1000.0);
                ys.Add(y);
                if (y > maxY) maxY = y;
            }

            return new DecayPoints
            {
                Name = Path.GetFileName(statGzPath),
                SourcePath = statGzPath,
                Bins = bins.ToArray(),
                XKb = xs.ToArray(),
                Y = ys.ToArray(),
                Measure = dPrime ? "D'" : "r²",
                // View setting only. Unset (0) falls back to the reference's own default,
                // int($maxX_tmp/1000) — the largest Dist in the file (lines 586-588).
                MaxXKb = maxXbp > 0 ? maxXbp / 1000.0 : Math.Floor(maxDistBp / 1000.0),
                MaxY = maxY,
                SkippedNonFinite = dPrime ? skippedD : skippedR2,
                OlderExport = trailingParams,
            };
        }

        /// <summary>
        /// Reads an exported table — this tool's own binned <c>.bin</c>, recognised by the parameter
        /// comment it carries on line 2 — as it was written: one point per row at x = Dist, y = the
        /// mean the earlier plot showed (Mean_r^2 or Mean_D'; "NA" = none in that bin), and the
        /// rows are kept verbatim so a re-export writes the same table. Binning it again would move
        /// every point one bin to the right (Dist is a bin's upper edge, the reference's x) and could
        /// merge bins, so a plotted-and-exported curve would not come back as it was drawn. The
        /// binning that made it is the one in the comment; bin widths given now do not apply.
        /// </summary>
        private static DecayPoints ReadTable(StreamReader r, string path, string paramsLine, int maxXbp, bool dPrime)
        {
            var xs = new List<double>();
            var ys = new List<double>();
            var rows = new List<string>();
            long maxDistBp = 0;
            double maxY = 0;
            int skipped = 0;
            string line;
            while ((line = r.ReadLine()) != null)
            {
                if (line.Length == 0 || line.IndexOf('#') >= 0) continue;
                // Dist, Mean_r^2, Mean_D', Sum_r^2, Sum_D', NumberPairs
                string[] f = line.Split(FieldSep, StringSplitOptions.RemoveEmptyEntries);
                if (f.Length < 6) continue;

                // The same rule as for a result file: a statistic is used only when its value,
                // the pair count and the distance are all finite; r² and D' are judged each on
                // its own. A pair count of 0 holds nothing to draw.
                bool rowOk = TryCount(f[0], out long dist) & TryCount(f[5], out long pairs);
                int r2 = TableValue(f[1], f[3], out double yR2);
                int dp = TableValue(f[2], f[4], out double yD);
                if (!rowOk) { r2 = r2 == 0 ? 0 : -1; dp = dp == 0 ? 0 : -1; }
                if ((dPrime ? dp : r2) < 0) skipped++;
                if (rowOk && pairs <= 0) continue;
                if (r2 <= 0 && dp <= 0) continue;              // nothing usable left in this row

                // Kept for a re-export: verbatim when whole, else with the unusable statistic as
                // "NA", so the table written back never carries a NaN.
                rows.Add(r2 >= 0 && dp >= 0 ? line : string.Join("\t", f[0],
                    r2 > 0 ? f[1] : "NA", dp > 0 ? f[2] : "NA", r2 > 0 ? f[3] : "NA", dp > 0 ? f[4] : "NA", f[5]));
                if (dist > maxDistBp) maxDistBp = dist;
                if ((dPrime ? dp : r2) <= 0) continue;         // none of the asked statistic here
                double y = dPrime ? yD : yR2;
                xs.Add(dist / 1000.0);
                ys.Add(y);
                if (y > maxY) maxY = y;
            }

            // The comment records the x range the plot used; it is the default view again.
            double maxXKb = maxXbp > 0 ? maxXbp / 1000.0 : Math.Floor(maxDistBp / 1000.0);
            int at = paramsLine.IndexOf("maxX_kb=", StringComparison.Ordinal);
            if (maxXbp <= 0 && at >= 0)
            {
                int from = at + "maxX_kb=".Length, end = from;
                while (end < paramsLine.Length && end - from < 18 && char.IsDigit(paramsLine[end])) end++;
                if (long.TryParse(paramsLine.Substring(from, end - from), NumberStyles.None,
                                  CultureInfo.InvariantCulture, out long recorded) && recorded > 0)
                    maxXKb = recorded;
            }

            return new DecayPoints
            {
                Name = Path.GetFileName(path),
                SourcePath = path,
                TableRows = rows.ToArray(),
                TableParams = paramsLine.Substring(1),
                XKb = xs.ToArray(),
                Y = ys.ToArray(),
                Measure = dPrime ? "D'" : "r²",
                MaxXKb = maxXKb,
                MaxY = maxY,
                SkippedNonFinite = skipped,
            };
        }

        /// <summary>
        /// One statistic of an exported-table row: 0 when the bin has none ("NA" for both its mean
        /// and its sum), 1 when both are usable, -1 otherwise (a NaN, an infinity, a number out of
        /// range, or only one of the two given).
        /// </summary>
        private static int TableValue(string mean, string sum, out double y)
        {
            y = 0;
            bool meanNa = mean == "NA", sumNa = sum == "NA";
            if (meanNa && sumNa) return 0;
            if (meanNa || sumNa) return -1;
            return TryNum(mean, out y) & TryNum(sum, out _) ? 1 : -1;
        }

        /// <summary>
        /// Picks the row layout from line 1's field count, as ReadFile2HashV2 does (Plot_OnePop.pl
        /// lines 770-782): 6 fields = MeanBin, 3 = R2Count, 5 = R2AndDCount, and any other count
        /// keeps MeanBin — the value the reference initialises <c>$FileType</c> to and leaves in
        /// place when no branch matches (line 759).
        /// <para>A first line without <c>#Dist</c> is the reference's fatal case (it prints and
        /// exits), and it is fatal here too: such a file is not a result file, and binning it to
        /// an empty curve would show the user "no LD in this data" instead of "wrong file".</para>
        /// </summary>
        private static StatLayout DetectLayout(string header, string path)
            => LayoutOf(header) ?? throw new InvalidDataException(
                   "Input File " + path + " Format wrong,Can't found [#Dist] at first line");

        /// <summary>
        /// The layout a <c>#Dist</c> header announces by its field count, or null without one. The
        /// probe that offers the Y-axis choices uses the same rule, so the two always agree.
        /// </summary>
        internal static StatLayout? LayoutOf(string header)
        {
            if (header == null || header.IndexOf("#Dist", StringComparison.Ordinal) < 0) return null;
            switch (header.Split(FieldSep, StringSplitOptions.RemoveEmptyEntries).Length)
            {
                case 3: return StatLayout.R2Count;
                case 5: return StatLayout.R2AndDCount;
                default: return StatLayout.MeanBin;
            }
        }

        /// <summary>
        /// Emits one grid's bins in ascending bin index (the reference sorts its hash keys
        /// numerically) at x = (k+1)*bin — the bin's exclusive upper edge, not its centre.
        /// </summary>
        private static void AppendBins(Dictionary<long, Acc> grid, int binBp, List<BinRow> rows)
        {
            if (grid.Count == 0) return;
            var keys = new List<long>(grid.Keys);
            keys.Sort();
            for (int i = 0; i < keys.Count; i++)
            {
                Acc a = grid[keys[i]];
                // A bin with no pairs in either statistic — only malformed rows, or an -OutType 4
                // bin whose rows all carried count 0 — has nothing to show (Perl would die on the
                // division). A bin that only D' reached is kept: its r² rows were unusable, its D'
                // ones are not, and dropping the bin would drop those too.
                if (a.PairsR2 <= 0 && a.PairsD <= 0) continue;
                rows.Add(new BinRow
                {
                    DistBp = (keys[i] + 1) * binBp,
                    SumR2 = a.SumR2,
                    SumD = a.SumD,
                    PairsR2 = a.PairsR2,
                    PairsD = a.PairsD,
                });
            }
        }

        /// <summary>
        /// Reads a value as Perl does inside an addition — a non-numeric field ("NA") counts as 0,
        /// so a single odd row can never abort a plot — and returns false for a number that is
        /// not finite (NaN, infinity), which cannot be plotted or summed.
        /// </summary>
        private static bool TryNum(string s, out double v)
        {
            switch (Classify(s, out v))
            {
                case FieldKind.Finite: return true;
                case FieldKind.Text: v = 0; return true;
                default: return false;
            }
        }

        /// <summary>What a numeric field holds.</summary>
        public enum FieldKind
        {
            /// <summary>A finite number.</summary>
            Finite,
            /// <summary>A number that is not finite: NaN, an infinity, or one too large for a double.</summary>
            NonFinite,
            /// <summary>Not a number at all ("NA", a word).</summary>
            Text,
        }

        /// <summary>
        /// Reads a field the same way on every runtime. .NET Framework refuses a number too large
        /// for a double ("1e309") where .NET Core 3.0+ reads it as infinity, and parses neither
        /// "nan" nor "inf"; any field written like a number is therefore classified by its
        /// spelling, so the same file gives the same plot on both.
        /// </summary>
        public static FieldKind Classify(string s, out double v)
        {
            // The common case first: an ordinary number parses at once.
            if (double.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out v))
                return double.IsNaN(v) || double.IsInfinity(v) ? FieldKind.NonFinite : FieldKind.Finite;
            v = 0;
            return IsNonFiniteText(s) || IsNumberSpelling(s) ? FieldKind.NonFinite : FieldKind.Text;
        }

        /// <summary>
        /// True for a decimal number as written — optional sign, digits with at most one point,
        /// an optional exponent, surrounding spaces — in one pass over the text. (A regular
        /// expression for this backtracks on a long run of digits that ends in another character,
        /// which made a 16 KB malformed field take seconds.)
        /// </summary>
        public static bool IsNumberSpelling(string s)
        {
            if (s == null) return false;
            int i = 0, n = s.Length;
            while (i < n && char.IsWhiteSpace(s[i])) i++;
            if (i < n && (s[i] == '+' || s[i] == '-')) i++;
            int digits = 0;
            while (i < n && s[i] >= '0' && s[i] <= '9') { i++; digits++; }
            if (i < n && s[i] == '.')
            {
                i++;
                while (i < n && s[i] >= '0' && s[i] <= '9') { i++; digits++; }
            }
            if (digits == 0) return false;
            if (i < n && (s[i] == 'e' || s[i] == 'E'))
            {
                i++;
                if (i < n && (s[i] == '+' || s[i] == '-')) i++;
                int expDigits = 0;
                while (i < n && s[i] >= '0' && s[i] <= '9') { i++; expDigits++; }
                if (expDigits == 0) return false;
            }
            while (i < n && char.IsWhiteSpace(s[i])) i++;
            return i == n;
        }

        /// <summary>
        /// A NaN or infinity as C's printf spells it — "nan", "-nan", "inf", "nan(ind)", or the old
        /// Microsoft runtime's "1.#QNAN" / "1.#INF" — which .NET Framework does not parse (only
        /// "NaN" and "Infinity"), so without this the same file would be read as NaN on one
        /// runtime and as Perl's 0 on the other.
        /// </summary>
        internal static bool IsNonFiniteText(string s)
        {
            if (string.IsNullOrEmpty(s)) return false;
            string t = s.Trim().TrimStart('+', '-').ToLowerInvariant();
            return t == "nan" || t.StartsWith("nan(", StringComparison.Ordinal) ||
                   t == "inf" || t == "infinity" || t == "∞" ||
                   t.Contains("#qnan") || t.Contains("#snan") || t.Contains("#ind") || t.Contains("#inf");
        }

        /// <summary>A count or distance, read the same way; false when it is not finite.</summary>
        private static bool TryCount(string s, out long v)
        {
            if (long.TryParse(s, NumberStyles.Integer, CultureInfo.InvariantCulture, out v)) return true;
            bool ok = TryNum(s, out double d) && Math.Abs(d) < 9.2e18;
            v = ok ? (long)d : 0;
            return ok;
        }
    }
}
