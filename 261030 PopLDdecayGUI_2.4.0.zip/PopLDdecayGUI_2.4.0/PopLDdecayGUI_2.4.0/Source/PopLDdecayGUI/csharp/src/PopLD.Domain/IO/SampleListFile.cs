using System;
using System.Collections.Generic;

namespace PopLD.Domain.IO
{
    /// <summary>
    /// The one reader of a SubPop sample list. The engine selects samples with it and the cache
    /// key is built from it, so the two can never disagree about which samples a list names.
    /// </summary>
    public static class SampleListFile
    {
        private static readonly char[] Separators = { ' ', '\t', '\r', '\n' };

        /// <summary>
        /// One name per whitespace-separated token, '#' comment lines skipped — the original's
        /// rule: every sample-list loop in FileDeal.h opens with
        /// <c>if (line.length()&lt;=0 || line[0] == '#') continue;</c> and splits on " \t".
        /// The file may be gzipped (the original opens it through igzstream).
        /// </summary>
        public static HashSet<string> Load(string path)
        {
            var set = new HashSet<string>(StringComparer.Ordinal);
            using (var reader = TextInput.OpenText(path, 1 << 16))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.Length == 0 || line[0] == '#') continue;
                    foreach (var tok in line.Split(Separators, StringSplitOptions.RemoveEmptyEntries))
                        set.Add(tok);
                }
            }
            return set;
        }
    }
}
