using System.Globalization;
using System.Security.Cryptography;
using System.Text;

namespace PopLD.Domain.Services
{
    /// <summary>Deterministic content key for the CAIR cache (SHA-256 of canonical material).</summary>
    public static class CacheKey
    {
        public static string Sha256Hex(string material)
        {
            using (var sha = SHA256.Create())
                return Hex(sha.ComputeHash(Encoding.UTF8.GetBytes(material ?? string.Empty)));
        }

        /// <summary>Lower-case hexadecimal, two digits per byte.</summary>
        public static string Hex(byte[] bytes)
        {
            var sb = new StringBuilder(bytes.Length * 2);
            for (int i = 0; i < bytes.Length; i++) sb.Append(bytes[i].ToString("x2", CultureInfo.InvariantCulture));
            return sb.ToString();
        }
    }
}
