using System;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace PopLD.App
{
    /// <summary>WPF application entry point.</summary>
    public partial class App : Application
    {
        private bool _showingError;

        protected override void OnStartup(StartupEventArgs e)
        {
            // An error nothing else caught must end in a message the user can read and report,
            // not in the program vanishing. On the UI thread the program keeps running.
            DispatcherUnhandledException += OnDispatcherUnhandledException;
            AppDomain.CurrentDomain.UnhandledException += OnDomainUnhandledException;
            // A failed background task nobody awaited is noted instead of tearing the process down.
            TaskScheduler.UnobservedTaskException += (s, a) => a.SetObserved();
            base.OnStartup(e);
        }

        private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            e.Handled = true;
            // One dialog at a time: an error that repeats (say, on every layout pass) would
            // otherwise stack dialogs faster than they can be closed.
            if (_showingError) return;
            _showingError = true;
            try { ShowError(e.Exception); }
            finally { _showingError = false; }
            // If the main window never came up (it failed while being built), there is nothing
            // left to keep running: end the process rather than leave it alive without a window.
            if (MainWindow == null || !MainWindow.IsLoaded) Shutdown(1);
        }

        private static void OnDomainUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            if (e.ExceptionObject is Exception ex) ShowError(ex);
        }

        private static void ShowError(Exception ex)
        {
            MessageBox.Show(
                "程序遇到未处理的错误 / An unexpected error occurred:\n\n" + Describe(ex),
                "PopLDdecay GUI", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        /// <summary>
        /// The exception and its inner exceptions: a window that fails while loading arrives
        /// wrapped (XamlParseException, TargetInvocationException), the cause innermost.
        /// </summary>
        private static string Describe(Exception ex)
        {
            var sb = new StringBuilder();
            int depth = 0;
            for (var x = ex; x != null && depth < 6; x = x.InnerException, depth++)
            {
                if (depth > 0) sb.Append("\n→ ");
                sb.Append(x.GetType().Name).Append(": ").Append(x.Message);
            }
            return sb.ToString();
        }
    }
}
