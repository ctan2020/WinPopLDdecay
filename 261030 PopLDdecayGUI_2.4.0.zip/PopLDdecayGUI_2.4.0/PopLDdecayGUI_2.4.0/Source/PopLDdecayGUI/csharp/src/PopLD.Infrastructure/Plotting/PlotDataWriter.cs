using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Text;
using PopLD.Domain.IO;
using PopLD.Domain.Services;

namespace PopLD.Infrastructure.Plotting
{
    /// <summary>
    /// Writes the binned plotting data in the reference plotter's own <c>*.bin</c> layout — a
    /// TSV whose first line is exactly
    /// <c>#Dist\tMean_r^2\tMean_D'\tSum_r^2\tSum_D'\tNumberPairs</c> and which then carries one
    /// row per bin (Plot_OnePop.pl lines 590-623, Plot_MultiPop.pl lines 260-295). That is the
    /// file the original scripts hand to R, so an exported table can be re-plotted by R, by the
    /// Perl scripts, or opened straight in a spreadsheet.
    /// <para>One file per source stat file, as in Plot_MultiPop.pl, which writes
    /// <c>$output.$PopID</c> for each input: an r²+D' twin-axis plot reads one stat file into
    /// two series but they share a single table.</para>
    /// </summary>
    public static class PlotDataWriter
    {
        /// <summary>
        /// How the parameter comment starts. It is line 2 of every exported table, which is how a
        /// reader recognises this tool's own table (already binned) and reads it as written.
        /// </summary>
        public const string ParamsCommentPrefix = "#measure=";

        /// <summary>
        /// The parameter comment written into a binned table, in the one spelling the command
        /// line and the GUI share: the measure plotted ("r^2", "D'" or "r^2+D'") and the binning
        /// actually applied — defaults resolved, maxX as the plot used it.
        /// </summary>
        public static string Describe(string measure, int bin1, int bin2, int breakBp, long maxXKb)
        {
            var inv = CultureInfo.InvariantCulture;
            return "measure=" + measure + ";bin1=" + bin1.ToString(inv) + ";bin2=" + bin2.ToString(inv) +
                   ";break=" + breakBp.ToString(inv) + ";maxX_kb=" + maxXKb.ToString(inv);
        }

        /// <summary>
        /// The comment for a re-exported table: bin1, bin2 and break from the table (how its rows
        /// were binned), measure and maxX_kb from the current plot (what is drawn now). Either
        /// side's missing keys are taken from the other.
        /// </summary>
        public static string MergeParams(string tableParams, string current)
        {
            var table = ParseParams(tableParams);
            var now = ParseParams(current);
            string Pick(string key, bool fromCurrent)
            {
                string v;
                if (fromCurrent && now.TryGetValue(key, out v)) return v;
                if (table.TryGetValue(key, out v)) return v;
                return now.TryGetValue(key, out v) ? v : null;
            }
            var parts = new List<string>();
            foreach (var key in new[] { "measure", "bin1", "bin2", "break", "maxX_kb" })
            {
                string v = Pick(key, key == "measure" || key == "maxX_kb");
                if (v != null) parts.Add(key + "=" + v);
            }
            return string.Join(";", parts);
        }

        private static Dictionary<string, string> ParseParams(string text)
        {
            var d = new Dictionary<string, string>(StringComparer.Ordinal);
            if (string.IsNullOrEmpty(text)) return d;
            foreach (string part in text.TrimStart('#').Split(';'))
            {
                int eq = part.IndexOf('=');
                if (eq > 0) d[part.Substring(0, eq).Trim()] = part.Substring(eq + 1).Trim();
            }
            return d;
        }

        /// <summary>The x range the plot shows, in whole kb: the widest series' extent.</summary>
        public static long EffectiveMaxXKb(IReadOnlyList<DecayPoints> series)
        {
            double m = 0;
            foreach (var s in series) if (s != null && s.MaxXKb > m) m = s.MaxXKb;
            return (long)m;
        }

        /// <summary>
        /// Writes the table(s) and returns the files actually written. <paramref name="path"/>
        /// is the caller's requested name and is kept as given: a trailing <c>.gz</c> means the
        /// same reference text, gzipped, because a default reference run ends with
        /// <c>gzip $output.bin</c> (Plot_OnePop.pl lines 731-735) — <c>$output.bin.gz</c> is the
        /// file the original actually leaves on disk, and only <c>-keepR</c> keeps it plain.
        /// <paramref name="paramsDescription"/> is written as a <c>#</c> comment on line 2 — R's
        /// read.table and both Perl readers skip '#' lines wherever they are, and the reference
        /// header has to stay on line 1 for ReadFile2HashV2 to recognise the file (Plot_OnePop.pl
        /// lines 770-782). On line 2 it also tells this tool's reader that the table is already
        /// binned. A series read from such a table is written back row for row with its own
        /// comment, so plotting and exporting a table again reproduces it.
        /// </summary>
        public static string[] Write(string path, IReadOnlyList<DecayPoints> series, string paramsDescription)
        {
            if (string.IsNullOrEmpty(path)) throw new ArgumentNullException("path");
            List<DecayPoints> tables = Tables(series);
            string[] targets = Targets(path, tables);
            for (int i = 0; i < tables.Count; i++) WriteOne(targets[i], tables[i], paramsDescription);
            return targets;
        }

        /// <summary>
        /// The files <see cref="Write"/> writes for these series, in its order — known before
        /// anything is written, so a caller can check that none of them is one of its inputs.
        /// </summary>
        public static string[] TargetPaths(string path, IReadOnlyList<DecayPoints> series)
            => Targets(path, Tables(series));

        private static string[] Targets(string path, List<DecayPoints> tables)
        {
            if (tables.Count == 0) return new string[0];
            if (tables.Count == 1) return new[] { path };
            string[] tags = UniqueTags(tables);
            var paths = new string[tables.Count];
            for (int i = 0; i < tables.Count; i++) paths[i] = Decorate(path, tags[i]);
            return paths;
        }

        /// <summary>
        /// One table per source stat file; two series off the same file (r² and D' on twin axes)
        /// carry the same bins, and the reference writes that file once.
        /// </summary>
        private static List<DecayPoints> Tables(IReadOnlyList<DecayPoints> series)
        {
            var tables = new List<DecayPoints>();
            if (series == null) return tables;
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var s in series)
            {
                if (s == null) continue;
                string key = !string.IsNullOrEmpty(s.SourcePath) ? s.SourcePath : s.Name;
                if (!string.IsNullOrEmpty(key) && !seen.Add(key)) continue;
                tables.Add(s);
            }
            return tables;
        }

        private static void WriteOne(string path, DecayPoints s, string paramsDescription)
            => AtomicFile.Write(path, fs => WriteBody(fs, path, s, paramsDescription));

        private static void WriteBody(Stream fs, string path, DecayPoints s, string paramsDescription)
        {
            var inv = CultureInfo.InvariantCulture;
            // A ".gz" name carries the identical text, gzipped — the state the reference leaves
            // $output.bin in after `gzip $output.bin` (Plot_OnePop.pl line 734).
            using (var body = path.EndsWith(".gz", StringComparison.OrdinalIgnoreCase)
                       ? (Stream)new GZipStream(fs, CompressionMode.Compress, true)
                       : fs)
            using (var w = new StreamWriter(body, new UTF8Encoding(false), 1 << 16))
            {
                w.Write(ResultFormat.StatHeader);
                // Line 2: the binning behind the rows and the view of this plot. For a table read
                // back as written, the binning is the one that made it (today's bin widths never
                // touched it), while the measure and maxX are this plot's.
                string desc = s.TableRows != null && !string.IsNullOrEmpty(s.TableParams)
                    ? MergeParams(s.TableParams, paramsDescription)
                    : paramsDescription;
                if (!string.IsNullOrEmpty(desc)) w.Write("#" + desc + "\n");
                if (s.TableRows != null)
                {
                    foreach (string row in s.TableRows) { w.Write(row); w.Write('\n'); }
                }
                else if (s.Bins != null)
                {
                    for (int i = 0; i < s.Bins.Length; i++)
                    {
                        BinRow b = s.Bins[i];
                        w.Write(b.DistBp.ToString(inv));
                        w.Write('\t');
                        if (b.PairsR2 <= 0)
                        {
                            // A bin only D' reached (its r² rows were NaN or infinite): r² is "NA",
                            // and NumberPairs carries the D' count, which is what a reader of this
                            // layout divides Sum_D' by — so the table reads back as written.
                            w.Write("NA\t");
                            w.Write(Num(b.SumD / b.PairsD, inv));
                            w.Write("\tNA\t");
                            w.Write(Num(b.SumD, inv));
                            w.Write('\t');
                            w.Write(b.PairsD.ToString(inv));
                            w.Write('\n');
                            continue;
                        }
                        w.Write(Num(b.SumR2 / b.PairsR2, inv));
                        w.Write('\t');
                        // The reference has two print branches: with D' it prints Mean_D' and
                        // Sum_D', without it prints "NA" in both columns. Mean_D' divides by the
                        // D'-only pair counter (Small_coutV2/hash_coutV2), never by NumberPairs.
                        if (b.PairsD > 0)
                        {
                            double meanD = b.SumD / b.PairsD;
                            // One NumberPairs serves both statistics in this layout, and every
                            // reader divides Sum_D' by it. Where D' had its own pair count (rows
                            // with "NA" or an unusable D', pair-wise inputs), Sum_D' is written as
                            // Mean_D' x NumberPairs, so any reader — the reference's included —
                            // recovers the mean that was plotted. For an analysis-type-2 result
                            // the two counts are equal and this is the plain sum.
                            double sumD = b.PairsD == b.PairsR2 ? b.SumD : meanD * b.PairsR2;
                            w.Write(Num(meanD, inv));
                            w.Write('\t');
                            w.Write(Num(b.SumR2, inv));
                            w.Write('\t');
                            w.Write(Num(sumD, inv));
                        }
                        else
                        {
                            w.Write("NA\t");
                            w.Write(Num(b.SumR2, inv));
                            w.Write("\tNA");
                        }
                        w.Write('\t');
                        w.Write(b.PairsR2.ToString(inv));
                        w.Write('\n');
                    }
                }
                else
                {
                    WriteUnbinned(w, s, inv);
                }
            }
        }

        /// <summary>
        /// Fallback for a curve that was never binned (an EHH series that reached this writer
        /// because it carries no <c>*.ehh</c> rows). The reference has no format for that, so
        /// keep its column count and fill in only what is known: distance in bp and the plotted
        /// mean, "NA" everywhere else.
        /// </summary>
        private static void WriteUnbinned(TextWriter w, DecayPoints s, IFormatProvider inv)
        {
            if (s.XKb == null) return;
            bool dPrime = s.Measure == "D'";
            for (int i = 0; i < s.XKb.Length; i++)
            {
                w.Write(Math.Round(s.XKb[i] * 1000.0).ToString("F0", inv));
                w.Write('\t');
                w.Write(dPrime ? "NA" : Num(s.Y[i], inv));
                w.Write('\t');
                w.Write(dPrime ? Num(s.Y[i], inv) : "NA");
                w.Write("\tNA\tNA\tNA\n");
            }
        }

        /// <summary>
        /// Names the per-series file of a multi-population export: <c>base.PopID.bin</c>, after
        /// Plot_MultiPop.pl's <c>$output.$PopID</c> (line 258), with the extension kept so the
        /// files stay recognisable on Windows.
        /// </summary>
        private static string Decorate(string target, string tag)
        {
            string stem = target;
            string ext = "";
            // Longest suffix first: "base.bin.gz" must split as "base" + ".bin.gz", not
            // "base.bin" + ".gz", or the tag would land in the middle of the extension.
            foreach (string suffix in new[] { ".bin.gz", ".bin", ".gz" })
            {
                if (!stem.EndsWith(suffix, StringComparison.OrdinalIgnoreCase)) continue;
                ext = stem.Substring(stem.Length - suffix.Length);
                stem = stem.Substring(0, stem.Length - suffix.Length);
                break;
            }
            return stem + "." + tag + (ext.Length > 0 ? ext : ".bin");
        }

        /// <summary>
        /// One distinct, file-name-safe tag per table (or EHH curve, whose exporter names its
        /// per-curve files by the same rule). Plot_MultiPop.pl can assume its <c>$PopID</c>s differ
        /// because they come from one population list; here the tables come from arbitrary paths,
        /// and two stat files with the same base name in different folders would otherwise name
        /// one file twice — writing it once, overwriting silently, while both names were reported
        /// back as written.
        /// </summary>
        public static string[] UniqueTags(IReadOnlyList<DecayPoints> tables)
        {
            var tags = new string[tables.Count];
            for (int i = 0; i < tables.Count; i++) tags[i] = BaseTag(tables[i], i);

            // Qualify EVERY member of a colliding set with its containing folder, so the names
            // stay symmetrical: "runA_PopA" and "runB_PopA", not "PopA" and "runB_PopA", where
            // the unqualified one looks like the canonical table.
            var counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (string t in tags)
            {
                int c;
                counts[t] = counts.TryGetValue(t, out c) ? c + 1 : 1;
            }
            for (int i = 0; i < tags.Length; i++)
            {
                if (counts[tags[i]] < 2) continue;
                string folder = Sanitize(FolderName(tables[i].SourcePath));
                if (folder.Length > 0) tags[i] = folder + "_" + tags[i];
            }

            // Whatever is still ambiguous — same folder name too, or no path at all — gets a
            // counter. Uniqueness is the guarantee the caller's "written" list depends on.
            var used = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < tags.Length; i++)
            {
                string t = tags[i];
                for (int n = 2; !used.Add(t); n++)
                    t = tags[i] + "_" + n.ToString(CultureInfo.InvariantCulture);
                tags[i] = t;
            }
            return tags;
        }

        /// <summary>
        /// The table's own name tag: the POPULATION (source file), never the statistic. A
        /// twin-axis chart reads one stat file into an r² series and a D' series whose Names are
        /// legend captions ("PopA r²"), and one table holds both — so naming it after the legend
        /// both describes half the file and drags a space and a "²" into the file name. The
        /// source path is the population identity, so use it and fall back to Name only when a
        /// series carries no path.
        /// </summary>
        private static string BaseTag(DecayPoints s, int index)
        {
            string name = !string.IsNullOrEmpty(s.SourcePath) ? Path.GetFileName(s.SourcePath) : s.Name;
            if (!string.IsNullOrEmpty(name))
            {
                foreach (string ext in new[] { ".stat.gz", ".ehh.gz" })
                    if (name.EndsWith(ext, StringComparison.OrdinalIgnoreCase))
                    {
                        name = name.Substring(0, name.Length - ext.Length);
                        break;
                    }
                // A Name fallback may still carry the legend's measure tag; drop it too.
                foreach (string tag in new[] { " r²", " D'" })
                    if (name.EndsWith(tag, StringComparison.Ordinal))
                    {
                        name = name.Substring(0, name.Length - tag.Length);
                        break;
                    }
            }
            name = Sanitize(name);
            return name.Length == 0 ? "series" + (index + 1).ToString(CultureInfo.InvariantCulture) : name;
        }

        /// <summary>Name of the folder holding <paramref name="path"/>, "" if it has none.</summary>
        private static string FolderName(string path)
        {
            if (string.IsNullOrEmpty(path)) return "";
            string dir = Path.GetDirectoryName(path);
            return string.IsNullOrEmpty(dir) ? "" : Path.GetFileName(dir.TrimEnd(Path.DirectorySeparatorChar,
                Path.AltDirectorySeparatorChar));
        }

        /// <summary>
        /// Reduces a tag to what is unambiguous in a file name — letters, digits, '-' and '_' —
        /// collapsing any run of everything else to a single '_'. That drops the space and the
        /// '²' a legend caption drags in, every path separator, and every character Windows
        /// refuses in a name: none of those is a letter or a digit.
        /// <para>Letters are NOT limited to ASCII. This tag is the only thing saying which
        /// population a table holds, and these users name their populations in their own script;
        /// folding those to nothing leaves the caller with two files it cannot tell apart — the
        /// same unattributable output that <see cref="UniqueTags"/> exists to prevent. Holding the
        /// tag to ASCII would not buy an ASCII path either: the folder and base name around it
        /// come from the user untouched.</para>
        /// </summary>
        private static string Sanitize(string name)
        {
            if (string.IsNullOrEmpty(name)) return "";
            var sb = new StringBuilder(name.Length);
            foreach (char c in name)
            {
                bool ok = char.IsLetterOrDigit(c) || c == '-' || c == '_';
                if (ok) sb.Append(c);
                else if (sb.Length > 0 && sb[sb.Length - 1] != '_') sb.Append('_');
            }
            return sb.ToString().Trim('_');
        }

        /// <summary>
        /// Perl stringifies a number with 15 significant digits and no trailing zeros, which is
        /// what the reference rows show. "G15" applies the same rule — same digits, and the same
        /// switch to exponent form below 1e-5 / at 1e15 — but spells the exponent with a capital
        /// "E" where Perl writes a lowercase "e" ("1E-07" vs "1e-07"), so lower it back down.
        /// </summary>
        private static string Num(double v, IFormatProvider inv)
            => v.ToString("G15", inv).Replace("E", "e");
    }
}
