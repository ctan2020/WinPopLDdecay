using System;
using System.Collections.Generic;
using System.Globalization;

namespace PopLD.Infrastructure.Plotting
{
    /// <summary>Axis-aligned rectangle in plot device units (y grows downward).</summary>
    public struct PlotRect
    {
        public double X, Y, W, H;
        public PlotRect(double x, double y, double w, double h) { X = x; Y = y; W = w; H = h; }
        public double Right => X + W;
        public double Bottom => Y + H;
    }

    /// <summary>A straight line segment.</summary>
    public sealed class PlotLine
    {
        public double X1, Y1, X2, Y2;
        public PlotLine(double x1, double y1, double x2, double y2) { X1 = x1; Y1 = y1; X2 = x2; Y2 = y2; }
    }

    /// <summary>A text label anchored at its top-left corner.</summary>
    public sealed class PlotText
    {
        public string Text;
        public double X, Y;
        public PlotText(string text, double x, double y) { Text = text; X = x; Y = y; }
    }

    /// <summary>One series polyline, already scaled to device coordinates.</summary>
    public sealed class PlotSeriesGeometry
    {
        public double[] Xs, Ys;
        public int ColorIndex;
    }

    /// <summary>One legend row: color swatch rectangle + its label.</summary>
    public sealed class PlotLegendItem
    {
        public PlotRect Swatch;
        public PlotText Label;
        public int ColorIndex;
    }

    /// <summary>
    /// Device-independent layout of the LD-decay plot. Both the WPF screen view
    /// (DecayPlotView) and the vector-PDF writer (PdfPlotWriter) render from this single
    /// geometry, so the exported figure matches what the user sees. Coordinates are in
    /// device units with the origin at the top-left (y grows downward); painters that use
    /// a bottom-left origin (PDF) flip y themselves.
    /// </summary>
    public sealed class PlotLayout
    {
        public readonly List<PlotLine> GridLines = new List<PlotLine>();
        public readonly List<PlotLine> AxisLines = new List<PlotLine>();
        public readonly List<PlotText> TickLabels = new List<PlotText>();
        public PlotText XAxisLabel, YAxisLabel;
        /// <summary>Secondary Y-axis caption; null unless some series opts into the right axis.</summary>
        public PlotText RightAxisLabel;
        public readonly List<PlotSeriesGeometry> Series = new List<PlotSeriesGeometry>();
        public bool HasLegend;
        public PlotRect LegendBox;
        public readonly List<PlotLegendItem> LegendItems = new List<PlotLegendItem>();

        /// <summary>
        /// Computes the full plot geometry for a canvas of <paramref name="width"/> ×
        /// <paramref name="height"/>. <paramref name="textWidth"/> measures a label string in
        /// the painter's font (WPF and PDF fonts differ slightly, so each painter supplies its
        /// own measurer); <paramref name="textHeight"/> is that font's line height.
        /// </summary>
        public static PlotLayout Compute(double width, double height, IReadOnlyList<DecayPoints> series,
            Func<string, double> textWidth, double textHeight)
        {
            var inv = CultureInfo.InvariantCulture;
            var lay = new PlotLayout();

            // A secondary axis needs room on the right for its tick labels.
            bool anyRight = false;
            for (int i = 0; i < series.Count; i++) if (series[i].UseRightAxis) { anyRight = true; break; }

            // Right margin must hold the secondary tick labels plus its axis caption.
            double ml = 64, mr = anyRight ? 10 + textWidth("0.00") + 4 + textWidth("D'") + 8 : 28;
            double mt = 24, mb = 52;
            var plot = new PlotRect(ml, mt, Math.Max(1, width - ml - mr), Math.Max(1, height - mt - mb));

            double maxX = double.NegativeInfinity, minX = double.PositiveInfinity;
            double maxY = 0.1, maxYRight = 0.1;
            for (int i = 0; i < series.Count; i++)
            {
                if (series[i].MaxXKb > maxX) maxX = series[i].MaxXKb;
                if (series[i].MinXKb < minX) minX = series[i].MinXKb;
                if (series[i].UseRightAxis)
                {
                    if (series[i].MaxY > maxYRight) maxYRight = series[i].MaxY;
                }
                else if (series[i].MaxY > maxY) maxY = series[i].MaxY;
            }
            if (double.IsInfinity(maxX)) maxX = 1;
            if (double.IsInfinity(minX)) minX = 0;
            if (maxX - minX < 1e-9) maxX = minX + 1;   // degenerate range guard
            double spanX = maxX - minX;
            maxY = NiceCeil(maxY);
            maxYRight = NiceCeil(maxYRight);

            // gridlines + tick labels (6 divisions per axis, like the original view)
            for (int k = 0; k <= 5; k++)
            {
                double fy = (double)k / 5;
                double y = plot.Bottom - fy * plot.H;
                lay.GridLines.Add(new PlotLine(plot.X, y, plot.Right, y));
                string yl = (fy * maxY).ToString("0.00", inv);
                lay.TickLabels.Add(new PlotText(yl, plot.X - 8 - textWidth(yl), y - textHeight / 2));
                if (anyRight)
                {
                    string yr = (fy * maxYRight).ToString("0.00", inv);
                    lay.TickLabels.Add(new PlotText(yr, plot.Right + 8, y - textHeight / 2));
                }

                double fx = (double)k / 5;
                double x = plot.X + fx * plot.W;
                lay.GridLines.Add(new PlotLine(x, plot.Y, x, plot.Bottom));
                string xl = (minX + fx * spanX).ToString("0.#", inv);
                lay.TickLabels.Add(new PlotText(xl, x - textWidth(xl) / 2, plot.Bottom + 6));
            }

            lay.AxisLines.Add(new PlotLine(plot.X, plot.Y, plot.X, plot.Bottom));
            lay.AxisLines.Add(new PlotLine(plot.X, plot.Bottom, plot.Right, plot.Bottom));
            if (anyRight)
                lay.AxisLines.Add(new PlotLine(plot.Right, plot.Y, plot.Right, plot.Bottom));

            string xTitle = series.Count > 0 && !string.IsNullOrEmpty(series[0].XAxisLabel)
                ? series[0].XAxisLabel : "Distance (kb)";
            lay.XAxisLabel = new PlotText(xTitle, plot.X + plot.W / 2 - textWidth(xTitle) / 2, height - 20);
            // Axis captions name the statistic on each side, so a dual-axis chart is readable
            // without the legend: left = whatever the first left-axis series measures.
            // Scan every series: the left and right captions come from the first series on each
            // axis, so neither loop may stop early at the other axis's series.
            string measure = null, rightMeasure = null;
            for (int i = 0; i < series.Count; i++)
            {
                if (string.IsNullOrEmpty(series[i].Measure)) continue;
                if (series[i].UseRightAxis) { if (rightMeasure == null) rightMeasure = series[i].Measure; }
                else if (measure == null) measure = series[i].Measure;
            }
            if (measure == null) measure = "r²";
            lay.YAxisLabel = new PlotText(measure, 16, plot.Y + plot.H / 2 - textHeight / 2);
            if (anyRight && rightMeasure != null)
            {
                // Sits just past the right tick labels, clamped inside the canvas.
                double x = plot.Right + 10 + textWidth("0.00") + 4;
                x = Math.Min(x, width - textWidth(rightMeasure) - 2);
                lay.RightAxisLabel = new PlotText(rightMeasure, x, plot.Y + plot.H / 2 - textHeight / 2);
            }

            // series polylines scaled into the plot area, each against its own Y axis
            for (int si = 0; si < series.Count; si++)
            {
                var s = series[si];
                double scaleY = s.UseRightAxis ? maxYRight : maxY;
                var xs = new double[s.XKb.Length];
                var ys = new double[s.XKb.Length];
                for (int i = 0; i < s.XKb.Length; i++)
                {
                    xs[i] = plot.X + ((s.XKb[i] - minX) / spanX) * plot.W;
                    ys[i] = plot.Bottom - (s.Y[i] / scaleY) * plot.H;
                }
                // maxX crops the view, it does not drop bins: the reference bins the whole stat
                // file and only hands maxX to R as xlim (Plot_OnePop.pl line 637), so a curve
                // routinely carries points past the right edge. R clips them at the panel
                // boundary; clip here too, or the tail is painted over the margins, the tick
                // labels and the canvas beyond them.
                AddClipped(lay, xs, ys, plot, si % PlotPalette.Colors.Length);
            }

            // legend anchored to the top-right corner inside the plot area
            int n = series.Count;
            if (n > 0)
            {
                const double pad = 10, sw = 14, gap = 6, rowH = 20;
                var labels = new string[n];
                double maxLabel = 0;
                for (int i = 0; i < n; i++)
                {
                    labels[i] = TrimName(series[i].Name);
                    double w = textWidth(labels[i]);
                    if (w > maxLabel) maxLabel = w;
                }

                double boxW = pad + sw + gap + maxLabel + pad;
                double boxH = pad + n * rowH;
                double boxX = plot.Right - pad - boxW;
                double boxY = plot.Y + pad;
                lay.HasLegend = true;
                lay.LegendBox = new PlotRect(boxX, boxY, boxW, boxH);

                for (int i = 0; i < n; i++)
                {
                    double rowY = boxY + pad * 0.5 + i * rowH;
                    lay.LegendItems.Add(new PlotLegendItem
                    {
                        Swatch = new PlotRect(boxX + pad, rowY + (rowH - 10) / 2, sw, 10),
                        Label = new PlotText(labels[i], boxX + pad + sw + gap, rowY + (rowH - textHeight) / 2),
                        ColorIndex = i % PlotPalette.Colors.Length,
                    });
                }
            }
            return lay;
        }

        /// <summary>
        /// Adds one series polyline to <paramref name="lay"/>, clipped to <paramref name="clip"/>.
        /// A segment that crosses the boundary is CUT there rather than dropped, so the drawn
        /// curve still reaches the edge of the panel instead of stopping at the last point that
        /// happened to fall inside. A curve that leaves and re-enters becomes several geometries
        /// sharing one colour — never a single polyline with a chord bridging the gap, which
        /// would draw a straight line through data that is not there.
        /// </summary>
        private static void AddClipped(PlotLayout lay, double[] xs, double[] ys, PlotRect clip, int colorIndex)
        {
            int n = xs.Length;
            if (n == 0) return;
            if (n == 1)
            {
                // A lone bin has no segment to clip; keep it if it is inside, as before.
                if (xs[0] >= clip.X && xs[0] <= clip.Right && ys[0] >= clip.Y && ys[0] <= clip.Bottom)
                    lay.Series.Add(new PlotSeriesGeometry
                    {
                        Xs = new[] { xs[0] },
                        Ys = new[] { ys[0] },
                        ColorIndex = colorIndex,
                    });
                return;
            }

            var runX = new List<double>(n);
            var runY = new List<double>(n);
            for (int i = 0; i + 1 < n; i++)
            {
                double ax = xs[i], ay = ys[i], bx = xs[i + 1], by = ys[i + 1];
                if (!ClipSegment(clip, ref ax, ref ay, ref bx, ref by))
                {
                    Emit(lay, runX, runY, colorIndex);   // wholly outside: the visible run ends here
                    continue;
                }
                // Extend the current run only if this piece starts exactly where the last one
                // ended; anything else means the curve went outside in between.
                const double eps = 1e-9;
                if (runX.Count == 0 ||
                    Math.Abs(runX[runX.Count - 1] - ax) > eps || Math.Abs(runY[runY.Count - 1] - ay) > eps)
                {
                    Emit(lay, runX, runY, colorIndex);
                    runX.Add(ax);
                    runY.Add(ay);
                }
                runX.Add(bx);
                runY.Add(by);
            }
            Emit(lay, runX, runY, colorIndex);
        }

        /// <summary>Moves one finished visible run into the layout and clears it for the next.</summary>
        private static void Emit(PlotLayout lay, List<double> xs, List<double> ys, int colorIndex)
        {
            if (xs.Count > 0)
                lay.Series.Add(new PlotSeriesGeometry
                {
                    Xs = xs.ToArray(),
                    Ys = ys.ToArray(),
                    ColorIndex = colorIndex,
                });
            xs.Clear();
            ys.Clear();
        }

        /// <summary>
        /// Liang-Barsky clip of one segment against <paramref name="r"/>. Returns false when the
        /// segment misses the rectangle completely; otherwise the endpoints are pulled onto the
        /// boundary and true is returned.
        /// </summary>
        private static bool ClipSegment(PlotRect r, ref double x0, ref double y0, ref double x1, ref double y1)
        {
            double dx = x1 - x0, dy = y1 - y0;
            double t0 = 0, t1 = 1;

            // For one edge: p is how fast the segment crosses it, q the start point's distance
            // inside it. p == 0 is a segment parallel to that edge, which survives only if it
            // starts on the inside; otherwise the crossing at q/p tightens the entry (p < 0) or
            // the exit (p > 0), and the two meeting means the segment is outside.
            bool Keep(double p, double q)
            {
                if (p == 0) return q >= 0;
                double t = q / p;
                if (p < 0) { if (t > t1) return false; if (t > t0) t0 = t; }
                else { if (t < t0) return false; if (t < t1) t1 = t; }
                return true;
            }

            if (!Keep(-dx, x0 - r.X) || !Keep(dx, r.Right - x0) ||
                !Keep(-dy, y0 - r.Y) || !Keep(dy, r.Bottom - y0)) return false;

            // Far end first: computing it needs the ORIGINAL start point, which the near-end
            // assignment below overwrites.
            x1 = x0 + t1 * dx; y1 = y0 + t1 * dy;
            x0 = x0 + t0 * dx; y0 = y0 + t0 * dy;
            return true;
        }

        /// <summary>
        /// The axis rule of an r² + D' ("both") chart, for the chart as a whole and whatever the
        /// order of the files: when any r² curve is on it, every D' curve goes on the right axis;
        /// when there is none, D' takes the left axis. Deciding it file by file put one file's D'
        /// on the left and another's on the right, on different scales under mixed captions.
        /// </summary>
        public static void AssignTwinAxes(IList<DecayPoints> series)
        {
            bool anyR2 = false;
            foreach (var s in series) if (s != null && s.Measure == "r²") anyR2 = true;
            foreach (var s in series)
            {
                if (s == null) continue;
                if (s.Measure == "D'") s.UseRightAxis = anyR2;
                else if (s.Measure == "r²") s.UseRightAxis = false;
            }
        }

        /// <summary>
        /// Shortens a result-file name for the legend: strips the extension and caps the length.
        /// A trailing measure tag (" r²" / " D'") is preserved through truncation — on a twin-axis
        /// chart it is the only thing telling two curves of the same file apart.
        /// </summary>
        public static string TrimName(string name)
        {
            if (string.IsNullOrEmpty(name)) return "";

            string tag = "";
            foreach (var suffix in new[] { " r²", " D'" })
                if (name.EndsWith(suffix, StringComparison.Ordinal)) { tag = suffix; break; }
            if (tag.Length > 0) name = name.Substring(0, name.Length - tag.Length);

            // Only a trailing extension, in any letter case ("PopA.STAT.GZ" too); an
            // ".ehh.gz" in the middle of a name is part of the name.
            foreach (var ext in new[] { ".stat.gz", ".ehh.gz", ".stat", ".ehh" })
                if (name.EndsWith(ext, StringComparison.OrdinalIgnoreCase))
                {
                    name = name.Substring(0, name.Length - ext.Length);
                    break;
                }

            int cap = 16;
            if (name.Length > cap)
            {
                int keep = cap - 1;
                // Never cut a surrogate pair in half: that leaves an unpaired char, which shows
                // as a broken glyph and is not valid text.
                if (char.IsHighSurrogate(name[keep - 1])) keep--;
                name = name.Substring(0, keep) + "…";
            }
            return name + tag;
        }

        /// <summary>
        /// Rounds a data maximum up to a friendly axis maximum. The ladder is fine-grained
        /// enough that the curve fills the panel: a peak of 0.26 tops the axis at 0.30 rather
        /// than throwing away the upper half of the plot at 0.50.
        /// </summary>
        public static double NiceCeil(double v)
        {
            if (v <= 0) return 0.1;
            foreach (double step in new[]
                     { 0.02, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.75, 0.8, 1.0 })
                if (v <= step) return step;
            return Math.Ceiling(v * 2) / 2;
        }
    }
}
