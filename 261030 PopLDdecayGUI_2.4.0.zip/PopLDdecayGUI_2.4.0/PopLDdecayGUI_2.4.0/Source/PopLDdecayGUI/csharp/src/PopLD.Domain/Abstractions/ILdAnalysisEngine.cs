using System;
using System.Threading;
using System.Threading.Tasks;
using PopLD.Domain.Model;

namespace PopLD.Domain.Abstractions
{
    /// <summary>Progress notification emitted while an analysis runs.</summary>
    public struct AnalysisProgress
    {
        public double Fraction { get; set; }   // 0..1
        public string Stage { get; set; }
    }

    /// <summary>
    /// The LD computation core (r^2 / D' decay). Implemented by PopLD.Engine, but the
    /// application layer depends only on this abstraction so the engine stays replaceable.
    /// </summary>
    public interface ILdAnalysisEngine
    {
        Task<AnalysisResult> RunAsync(
            AnalysisRequest request,
            IProgress<AnalysisProgress> progress,
            CancellationToken cancellationToken);

        /// <summary>
        /// The settings <see cref="RunAsync"/> will apply to this request, decided without running
        /// it (reads the input's first record). The single place that decides whether an unphased
        /// option has any effect, so the cache key, the output name and the engine never disagree.
        /// </summary>
        EffectiveSettings Resolve(AnalysisRequest request);
    }
}
