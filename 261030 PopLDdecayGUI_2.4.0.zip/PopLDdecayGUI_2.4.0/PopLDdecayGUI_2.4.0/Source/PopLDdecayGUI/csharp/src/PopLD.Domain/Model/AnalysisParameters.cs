namespace PopLD.Domain.Model
{
    /// <summary>
    /// Immutable-by-convention set of LD analysis parameters. Field names and default
    /// values mirror the original PopLDdecay C++ tool and the existing GUI, so the same
    /// inputs select the same retained SNP set and distance range.
    /// </summary>
    public sealed class AnalysisParameters
    {
        /// <summary>Maximum pairwise distance to evaluate, in kilobases (-MaxDist).</summary>
        public int MaxDistKb { get; set; } = 300;

        /// <summary>Minor allele frequency threshold (-MAF).</summary>
        public double Maf { get; set; } = 0.005;

        /// <summary>Maximum heterozygosity per site (-Het).</summary>
        public double Het { get; set; } = 0.88;

        /// <summary>Maximum missing rate per site (-Miss).</summary>
        public double Miss { get; set; } = 0.25;

        /// <summary>Statistic output mode (-OutType).</summary>
        public LdOutputType OutType { get; set; } = LdOutputType.R2;

        /// <summary>First (fine) bin size in base pairs, used for short distances (-bin1).</summary>
        public int Bin1Bp { get; set; } = 10;

        /// <summary>Second (coarse) bin size in base pairs, used past the break point (-bin2).</summary>
        public int Bin2Bp { get; set; } = 100;

        /// <summary>Distance in base pairs where binning switches from bin1 to bin2 (-break).</summary>
        public int BreakBp { get; set; } = 100;

        /// <summary>Maximum X-axis distance for plotting, in kilobases (maxX).</summary>
        public int MaxXKb { get; set; } = 300;

        /// <summary>Optional EHH anchor site, e.g. "chr1:5000000". Null/empty disables EHH.</summary>
        public string EhhSite { get; set; }

        /// <summary>
        /// r^2/D' estimator for unphased genotypes. The default reproduces the original tool;
        /// it has no effect on a phased VCF unless <see cref="IgnorePhase"/> is set.
        /// </summary>
        public UnphasedLdEstimator UnphasedEstimator { get; set; } = UnphasedLdEstimator.PopLDdecay;

        /// <summary>
        /// Treat a phased ('|') VCF as unphased: discard the recorded phase and read it exactly as
        /// the same genotypes written with '/'. Lets the unphased estimators be compared with the
        /// phased truth on one file, without rewriting it.
        /// </summary>
        public bool IgnorePhase { get; set; }

        /// <summary>Creates a copy so parameter sweeps can vary one field without side effects.</summary>
        public AnalysisParameters Clone()
        {
            return (AnalysisParameters)MemberwiseClone();
        }
    }
}
