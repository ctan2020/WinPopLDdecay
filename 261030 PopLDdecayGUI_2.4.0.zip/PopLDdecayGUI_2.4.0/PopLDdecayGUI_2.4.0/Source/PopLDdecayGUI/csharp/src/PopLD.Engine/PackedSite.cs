namespace PopLD.Engine
{
    /// <summary>
    /// A retained site with its haplotype alleles bit-packed for the popcount kernel.
    /// <see cref="Ones"/> marks minor-allele (value 1) haplotypes. <see cref="Valid"/> marks
    /// non-missing (value 0 or 1) haplotypes, but is <c>null</c> when the site has no missing
    /// data (the common case for called/imputed data): the kernel then treats validity as
    /// "all haplotypes", so we skip allocating and populating a second bit-plane per site.
    /// </summary>
    public sealed class PackedSite
    {
        public long Pos;
        public ulong[] Ones;
        public ulong[] Valid;   // null == no missing (all haplotypes valid)
        public int OnesCount;   // popcount(Ones), precomputed
        public bool AnyMissing;

        // Genotype planes, one bit per SAMPLE, built by PackGenotypes for the unphased
        // maximum-likelihood estimator (Pack leaves them null, PackGenotypes leaves Ones null).
        // Hom marks two minor alleles, Car at least one, so a heterozygote is Car & ~Hom and the
        // dosage is Hom + Car. A sample missing at this site has neither bit set.
        public ulong[] Hom;
        public ulong[] Car;
        public ulong[] SampleValid;   // null == every sample called
        public int HomCount;
        public int CarCount;
        public int SampleCount;

        /// <summary>
        /// The site packed for the kernel a run uses: dosage planes for the unphased maximum-likelihood
        /// estimator, haplotypes for everything else.
        /// </summary>
        public static PackedSite For(Vcf.GenotypeSite site, bool genotypeMl)
            => genotypeMl ? PackGenotypes(site.Pos, site.Alleles) : Pack(site.Pos, site.Alleles);

        /// <summary>
        /// Packs the dosage planes of one site from its two-slots-per-sample allele vector. The
        /// slot order is irrelevant here (dosage ignores phase); a sample is missing when either
        /// of its slots is.
        /// </summary>
        public static PackedSite PackGenotypes(long pos, byte[] alleles)
        {
            int n = alleles.Length >> 1;
            int words = (n + 63) >> 6;
            var hom = new ulong[words];
            var car = new ulong[words];
            bool anyMissing = false;
            int homCount = 0, carCount = 0;

            for (int s = 0; s < n; s++)
            {
                byte a = alleles[2 * s], b = alleles[2 * s + 1];
                if (a == 2 || b == 2) { anyMissing = true; continue; }
                int dose = a + b;
                if (dose == 0) continue;
                ulong bit = 1UL << (s & 63);
                car[s >> 6] |= bit; carCount++;
                if (dose == 2) { hom[s >> 6] |= bit; homCount++; }
            }

            ulong[] valid = null;
            if (anyMissing)
            {
                valid = new ulong[words];
                for (int s = 0; s < n; s++)
                    if (alleles[2 * s] != 2 && alleles[2 * s + 1] != 2) valid[s >> 6] |= 1UL << (s & 63);
            }

            return new PackedSite
            {
                Pos = pos,
                Hom = hom,
                Car = car,
                SampleValid = valid,
                HomCount = homCount,
                CarCount = carCount,
                SampleCount = n,
                AnyMissing = anyMissing,
            };
        }

        public static PackedSite Pack(long pos, byte[] alleles)
        {
            int n = alleles.Length;
            int words = (n + 63) >> 6;
            var ones = new ulong[words];
            bool anyMissing = false;
            int onesCount = 0;

            // Pass 1: minor-allele plane + missing detection. No Valid plane is built here,
            // so fully-called sites cost a single array.
            for (int i = 0; i < n; i++)
            {
                byte v = alleles[i];
                if (v == 1) { ones[i >> 6] |= 1UL << (i & 63); onesCount++; }
                else if (v == 2) anyMissing = true; // missing/other
            }

            // Pass 2 (rare): only when the site actually has missing data, build the Valid plane.
            ulong[] valid = null;
            if (anyMissing)
            {
                valid = new ulong[words];
                for (int i = 0; i < n; i++)
                    if (alleles[i] != 2) valid[i >> 6] |= 1UL << (i & 63);
            }

            return new PackedSite
            {
                Pos = pos,
                Ones = ones,
                Valid = valid,
                OnesCount = onesCount,
                AnyMissing = anyMissing,
            };
        }
    }
}
