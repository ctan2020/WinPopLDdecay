using System;
using System.Collections.Generic;
using System.IO;
using PopLD.Domain.IO;
using PopLD.Domain.Model;

namespace PopLD.Engine.Vcf
{
    /// <summary>
    /// Streaming VCF / VCF.gz reader that reproduces both of PopLDdecay's read modes:
    /// Read_VCF_IN_Phase (phased) and Read_VCF_IN (unphased), which share the same
    /// indel/Miss/Het/mono-multi/MAF filters but encode genotypes differently — the unphased
    /// mode canonicalises every heterozygote to (major, minor), the phased mode keeps the
    /// recorded order. The mode is chosen exactly as FileDeal.h::DeleVCFPhase chooses it,
    /// from the first data record alone. Sites are yielded one at a time to keep memory
    /// bounded regardless of file size (foundation for the HAPE engine).
    /// </summary>
    public sealed class VcfGenotypeReader
    {
        /// <summary>
        /// Picks the read mode the way the original's DeleVCFPhase (FileDeal.h) does:
        /// from the FIRST data record's FIRST sample only. One '/' later in the file does not
        /// change the verdict, which matters for merged callsets that mix separators.
        /// </summary>
        public static bool IsPhased(string path)
        {
            using (var reader = TextInput.OpenText(path))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    if (line.Length == 0 || line[0] == '#') continue;
                    int gt = FirstGenotypeFieldStart(line);
                    if (gt < 0) return false;
                    // Exactly the reference's test: character index 1 of the first sample field,
                    // and only '|' counts. Scanning further into the field would call a haploid
                    // GT with a phased FORMAT extra ("0:1|2") phased, which the original does not.
                    return gt + 1 < line.Length && line[gt + 1] == '|';
                }
            }
            return false;
        }

        /// <summary>
        /// Streams retained sites. Mirrors the original filter order — indel/SV → Miss → Het →
        /// mono/multi-allelic → MAF — and the original's two encoders, selected by
        /// <paramref name="phased"/>: pass the result of <see cref="IsPhased"/>.
        /// </summary>
        public IEnumerable<GenotypeSite> ReadSites(string path, AnalysisParameters p, ReaderStats stats,
            ISet<string> subPop, bool phased)
        {
            if (stats == null) stats = new ReaderStats();

            using (var reader = TextInput.OpenText(path))
            {
                string[] names = ReadHeaderSamples(reader);
                if (names == null || names.Length == 0) yield break;

                // SubPop: keep only listed samples (null = all). Pairwise stats are invariant to
                // sample order, so matching the sample SET yields the same per-pair values as the
                // original's SubPop mode (whole-file totals still differ only by pair completeness).
                bool[] keep = null;
                int nSamples = names.Length;   // number of sample COLUMNS declared by the header
                int sampleNum = names.Length;  // number of KEPT samples (== nSamples unless SubPop)
                if (subPop != null)
                {
                    keep = new bool[names.Length];
                    sampleNum = 0;
                    for (int i = 0; i < names.Length; i++)
                        if (subPop.Contains(names[i])) { keep[i] = true; sampleNum++; }
                }
                stats.SampleCount = sampleNum;
                if (sampleNum <= 0) yield break;

                // Reused, allocation-free per-line scratch (this iterator runs single-threaded).
                var tab = new int[9];            // positions of the first 9 tabs
                var alChar = new char[8];        // distinct allele chars seen on the line
                var alCnt = new int[8];          // their counts (Tally starts each new one at 1)

                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    int len = line.Length;
                    if (len == 0) continue;

                    // --- locate the first 9 tab boundaries (fixed VCF columns) in one scan ---
                    int found = 0;
                    for (int idx = 0; idx < len && found < 9; idx++)
                        if (line[idx] == '\t') tab[found++] = idx;
                    // Not even the nine fixed columns: counted with the other ragged records, so
                    // the skip counters add up to the number of data lines.
                    if (found < 9) { stats.SkippedShortLine++; continue; }
                    int sampleStart = tab[8] + 1;

                    // --- indel / SV: longest of REF (field 3) and ALT (field 4) alleles > 1bp ---
                    int baseLen = tab[3] - tab[2] - 1;              // REF length
                    int seg = 0;
                    for (int k = tab[3] + 1; k < tab[4]; k++)        // ALT, comma-separated
                    {
                        if (line[k] == ',') { if (seg > baseLen) baseLen = seg; seg = 0; }
                        else seg++;
                    }
                    if (seg > baseLen) baseLen = seg;
                    if (baseLen > 1) { stats.SkippedIndelOrSv++; continue; }

                    // --- pass 1: tally alleles + heterozygosity + missingness (kept samples only) ---
                    int distinct = 0, hetCount = 0, missCount = 0;
                    // Sample columns actually present on this line. Counted in the body, not by
                    // the for-update: the loop leaves through `break` on the last field (no
                    // trailing tab), which would skip an update expression.
                    int seen = 0;
                    // A kept sample column that is empty ("\t\t" inside the line, or a tab at its
                    // very end). The original points into the whole line, so it reads such a call
                    // from the bytes around it: the tab itself and a character of the next call
                    // (past the end of the line for the last column). Usually that makes three
                    // "alleles" and drops the site; before a "." call it keeps the site with a tab
                    // as an allele. Neither is a reading worth reproducing, and taking the column
                    // as no call would invent a homozygous-major sample, so the record is treated
                    // as malformed below, like a short one.
                    bool emptyKept = false;
                    // Stop after nSamples columns: some merged callsets carry a stray extra field
                    // on a few lines; like the reference tool we read the declared columns and
                    // ignore any surplus (never index past the sample array).
                    for (int fs = sampleStart; fs <= len && seen < nSamples; )
                    {
                        int fe = fs;
                        while (fe < len && line[fe] != '\t') fe++;
                        if ((keep == null || keep[seen]) && fe == fs) emptyKept = true;
                        else if (keep == null || keep[seen])
                        {
                            char c0 = line[fs];
                            if (c0 == '.') { missCount++; }
                            else
                            {
                                // A call of one character ("0", "1": a haploid call) has no second
                                // allele and is read as homozygous (hemizygous), as PLINK reads it.
                                // The original reads spline[jj][2] here, a pointer into the whole
                                // line: the first character of the NEXT sample's call (and past the
                                // end of the line for the last sample — undefined behaviour), so it
                                // pairs the call with a neighbour's allele or drops the site. VCFs
                                // with bare haploid calls are therefore the one input on which the
                                // two can differ; on every diploid call they agree byte for byte.
                                char c2 = (fs + 2 < fe) ? line[fs + 2] : c0;
                                if (c0 != c2) hetCount++;
                                distinct = Tally(alChar, alCnt, distinct, c0);
                                distinct = Tally(alChar, alCnt, distinct, c2);
                            }
                        }
                        seen++;
                        fs = fe + 1;
                        if (fe >= len) break;
                    }

                    // A line with FEWER sample columns than the header is malformed (truncated
                    // write, ragged merge). The reference drops such a record — its splitter runs
                    // off the end and the resulting junk allele characters trip the multi-allelic
                    // filter — so drop it here too, deliberately rather than by accident. Encoding
                    // it would silently turn the absent tail into homozygous-major calls.
                    if (seen < nSamples || emptyKept) { stats.SkippedShortLine++; continue; }

                    if ((double)missCount / sampleNum > p.Miss) { stats.SkippedMiss++; continue; }
                    if ((double)hetCount / sampleNum > p.Het) { stats.SkippedHet++; continue; }

                    // --- most / second-most common allele ---
                    // Scan in ascending allele-character order: the original walks a
                    // std::map<char,int>, so on an exact count tie the SMALLER character wins
                    // "most common". Scanning in first-seen order instead would swap the 0/1
                    // coding at tied sites — invisible to r^2/|D'| (both relabel-invariant) but
                    // it transposes EHH's per-allele columns.
                    SortTallyByChar(alChar, alCnt, distinct);
                    char best = 'N', sed = 'N';
                    int max = 0, seD = 0, baseCount = 0;
                    for (int a = 0; a < distinct; a++)
                    {
                        // The original's loop skips the character 'N' — it is never the major or
                        // minor allele and does not count as a distinct allele (FileDeal.h,
                        // Read_VCF_IN and Read_VCF_IN_Phase: "if ((it->first) == 'N') continue").
                        if (alChar[a] == 'N') continue;
                        int v = alCnt[a];
                        if (v > max) { seD = max; sed = best; max = v; best = alChar[a]; }
                        else if (v >= seD) { seD = v; sed = alChar[a]; }
                        baseCount++;
                    }
                    if (baseCount == 1 || baseCount > 2) { stats.SkippedMonoOrMulti++; continue; }
                    if ((double)seD / (seD + max) < p.Maf) { stats.SkippedMaf++; continue; }

                    // --- pass 2: encode each kept haplotype (major=0, minor=1, missing/other=2) ---
                    var alleles = new byte[2 * sampleNum];
                    int w = 0;
                    int s2 = 0;
                    // Same counting rule as pass 1 — the loop leaves through `break`, so the
                    // column index is advanced in the body.
                    for (int fs = sampleStart; fs <= len && s2 < nSamples; )
                    {
                        int fe = fs;
                        while (fe < len && line[fe] != '\t') fe++;
                        if ((keep == null || keep[s2]) && fs < len)
                        {
                            char c0 = line[fs];
                            char a0, a1;
                            if (c0 == '.') { a0 = 'N'; a1 = 'N'; }
                            else { a0 = c0; a1 = (fs + 2 < fe) ? line[fs + 2] : c0; }
                            if (!phased && a0 != a1 && c0 != '.')
                            {
                                // Unphased: the original discards the recorded order of every
                                // heterozygous call and stores (best_base, sed_base) — see
                                // FileDeal.h, Read_VCF_IN — so a het always encodes to (0,1). Without
                                // this, slot pairing is inconsistent between an ALT-major site and
                                // a REF-major site and the 2x2 haplotype table comes out wrong.
                                a0 = best; a1 = sed;
                            }
                            alleles[w++] = Encode(a0, best, sed);
                            alleles[w++] = Encode(a1, best, sed);
                        }
                        s2++;
                        fs = fe + 1;
                        if (fe >= len) break;
                    }

                    string chrom = line.Substring(0, tab[0]);
                    if (!TryParsePos(line, tab[0] + 1, tab[1], out long pos)) stats.MalformedPos++;
                    stats.Kept++;
                    yield return new GenotypeSite(chrom, pos, alleles);
                }
            }
        }

        /// <summary>Adds one occurrence of allele char <paramref name="c"/>; returns new distinct count.</summary>
        private static int Tally(char[] ch, int[] cnt, int distinct, char c)
        {
            for (int i = 0; i < distinct; i++)
                if (ch[i] == c) { cnt[i]++; return distinct; }
            if (distinct < ch.Length) { ch[distinct] = c; cnt[distinct] = 1; return distinct + 1; }
            return distinct; // overflow guard (multi-allelic will be filtered anyway)
        }

        /// <summary>
        /// Orders the tallied alleles by character ascending, so the best/second scan sees them
        /// in the same order the original's std::map does. Insertion sort: distinct is 1-3 in
        /// practice and capped at 8.
        /// </summary>
        private static void SortTallyByChar(char[] ch, int[] cnt, int distinct)
        {
            for (int i = 1; i < distinct; i++)
            {
                char c = ch[i];
                int v = cnt[i];
                int j = i - 1;
                while (j >= 0 && ch[j] > c) { ch[j + 1] = ch[j]; cnt[j + 1] = cnt[j]; j--; }
                ch[j + 1] = c;
                cnt[j + 1] = v;
            }
        }

        /// <summary>
        /// POS as the original reads it — <c>istringstream &gt;&gt; Site</c> (strtoll in the SubPop
        /// readers): leading white space, an optional sign, then digits up to the first other
        /// character; no digits gives 0, and a value beyond the range of long saturates. Returns
        /// false when the field is not a plain run of digits, so the caller can report it.
        /// </summary>
        internal static bool TryParsePos(string s, int start, int end, out long value)
        {
            int i = start;
            while (i < end && (s[i] == ' ' || (s[i] >= '\t' && s[i] <= '\r'))) i++;
            bool negative = false;
            if (i < end && (s[i] == '+' || s[i] == '-')) { negative = s[i] == '-'; i++; }
            int firstDigit = i;
            long v = 0;
            bool overflow = false;
            for (; i < end && s[i] >= '0' && s[i] <= '9'; i++)
            {
                int d = s[i] - '0';
                if (v > (long.MaxValue - d) / 10) overflow = true;
                else v = v * 10 + d;
            }
            bool digits = i > firstDigit;
            if (overflow) v = long.MaxValue;
            value = !digits ? 0 : negative ? (overflow ? long.MinValue : -v) : v;
            // Plain = digits only, nothing before or after them.
            return digits && !overflow && firstDigit == start && i == end;
        }

        private static byte Encode(char allele, char best, char sed)
        {
            if (allele == best) return 0;
            if (allele == sed) return 1;
            return 2;
        }

        private static readonly char[] Tab = { '\t' };

        /// <summary>
        /// Reads the #CHROM header and returns the sample names (columns 9+), following the
        /// original's header loop (FileDeal.h, Read_VCF_IN): empty lines are skipped wherever they
        /// are, "##" lines are meta-information, a '#' line that is not "#CHROM" is ignored, and a
        /// data line before the header is fatal (null here).
        /// <para>The original splits the header with <c>split(line, inf, " \t")</c>, which drops
        /// empty fields, so a stray tab at the end of the line (or two tabs in a row) does not
        /// add an empty sample. Empty fields are dropped here too. Unlike the original, a SPACE is
        /// not a separator — it splits names such as "NA 12878" into two and shifts every column
        /// after it — but spaces around a name are trimmed, which is all the original's rule
        /// does for well-formed names.</para>
        /// </summary>
        private static string[] ReadHeaderSamples(StreamReader reader)
        {
            string line;
            while ((line = reader.ReadLine()) != null)
            {
                if (line.Length == 0) continue;
                if (line.Length >= 2 && line[0] == '#' && line[1] == '#') continue;
                if (line[0] == '#')
                {
                    var fields = new List<string>();
                    foreach (var part in line.Split(Tab))
                    {
                        string t = part.Trim(' ');
                        if (t.Length > 0) fields.Add(t);
                    }
                    if (fields.Count == 0 || fields[0] != "#CHROM") continue;
                    if (fields.Count <= 9) return new string[0];
                    return fields.GetRange(9, fields.Count - 9).ToArray();
                }
                break; // data before header -> malformed
            }
            return null;
        }

        /// <summary>
        /// Result of matching a SubPop list against a VCF header — the join the original
        /// reports before it reads a single record (FileDeal.h:184-203).
        /// </summary>
        public sealed class SubPopJoin
        {
            /// <summary>Header columns whose sample name is in the list (a repeated name counts twice).</summary>
            public int Matched;
            /// <summary>List entries absent from the header.</summary>
            public List<string> Missing = new List<string>();
            /// <summary>List entries that appear more than once in the header.</summary>
            public List<string> Repeated = new List<string>();
        }

        /// <summary>
        /// <paramref name="sites"/> with only the first record at each CHROM/POS: the original keeps
        /// sites in a std::map keyed by position, so a second record there is dropped.
        /// <paramref name="onDuplicate"/> is called for each record dropped.
        /// </summary>
        public static IEnumerable<GenotypeSite> FirstAtEachPosition(IEnumerable<GenotypeSite> sites, Action onDuplicate = null)
        {
            var seen = new Dictionary<string, HashSet<long>>(StringComparer.Ordinal);
            foreach (var s in sites)
            {
                if (!seen.TryGetValue(s.Chrom, out var positions)) seen[s.Chrom] = positions = new HashSet<long>();
                if (positions.Add(s.Pos)) yield return s;
                else onDuplicate?.Invoke();
            }
        }

        /// <summary>
        /// The sample names in the <c>#CHROM</c> header, or null when the file has no usable
        /// header. The reference reports that case ("VCF Header something wrong, can't find sample
        /// info before site info", FileDeal.h) rather than analysing nothing in silence.
        /// </summary>
        public static string[] ReadHeader(string path)
        {
            using (var reader = TextInput.OpenText(path))
                return ReadHeaderSamples(reader);
        }

        /// <summary>
        /// Matches a SubPop list against the VCF header's sample names (<see cref="ReadHeader"/>)
        /// before any record is read, so a mistyped or mismatched list is reported before the run
        /// instead of silently producing an empty result. Mirrors the original's per-name warnings;
        /// the caller enforces the original's "fewer than 3 samples is fatal" rule.
        /// </summary>
        public static SubPopJoin JoinSubPop(string[] headerNames, ISet<string> subPop)
        {
            var join = new SubPopJoin();
            if (subPop == null) return join;

            var seen = new Dictionary<string, int>(StringComparer.Ordinal);
            foreach (var name in subPop) seen[name] = 0;

            if (headerNames != null)
            {
                foreach (var n in headerNames)
                    if (seen.ContainsKey(n)) { seen[n]++; join.Matched++; }
            }

            foreach (var kv in seen)
            {
                if (kv.Value == 0) join.Missing.Add(kv.Key);
                else if (kv.Value > 1) join.Repeated.Add(kv.Key);
            }
            join.Missing.Sort(StringComparer.Ordinal);
            join.Repeated.Sort(StringComparer.Ordinal);
            return join;
        }

        /// <summary>
        /// Loads a SubPop sample list (see <see cref="SampleListFile.Load"/>, which the cache key
        /// is built from as well, so the two always agree on the samples a list names).
        /// </summary>

        private static int FirstGenotypeFieldStart(string line)
        {
            int tabs = 0;
            for (int i = 0; i < line.Length; i++)
            {
                if (line[i] == '\t')
                {
                    tabs++;
                    if (tabs == 9) return i + 1;
                }
            }
            return -1;
        }

        /// <summary>Plain, gzip or BGZF, recognised from the content (see <see cref="TextInput"/>).</summary>
    }
}
