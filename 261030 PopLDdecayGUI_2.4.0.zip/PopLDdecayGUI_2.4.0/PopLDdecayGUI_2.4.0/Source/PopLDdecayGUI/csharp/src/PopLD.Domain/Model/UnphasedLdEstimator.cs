namespace PopLD.Domain.Model
{
    /// <summary>
    /// How r^2 and D' are obtained when the genotypes are unphased ('/'). Phased input ('|')
    /// always uses the observed haplotypes, so this choice only matters for unphased data.
    /// </summary>
    public enum UnphasedLdEstimator
    {
        /// <summary>
        /// The original PopLDdecay's rule (default, reference-identical output): every
        /// heterozygote is read as (major, minor), so a sample heterozygous at both sites is
        /// always counted as carrying the two minor alleles on the same haplotype. Biased
        /// for outbred samples: background r^2 is inflated and repulsion-phase LD is lost.
        /// </summary>
        PopLDdecay = 0,

        /// <summary>
        /// Two-locus haplotype frequencies estimated by maximum likelihood from the 3x3
        /// genotype table (the EM fixed point solved exactly as a cubic), then the same r^2
        /// and D' formulas as for phased data.
        /// </summary>
        MaximumLikelihood = 1,
    }
}
