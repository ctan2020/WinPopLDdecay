using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Runtime.ExceptionServices;
using System.Threading;
using System.Threading.Tasks;
using PopLD.Domain.Abstractions;
using PopLD.Domain.IO;
using PopLD.Domain.Model;
using PopLD.Domain.Services;
using PopLD.Engine.Hape;
using PopLD.Engine.Vcf;

namespace PopLD.Engine
{
    /// <summary>
    /// LD decay engine. Uses a bit-packed popcount kernel and the hardware-adaptive parallel
    /// scheduler (HAPE) to saturate available cores, producing r^2 (OutType 1) and r^2+D'
    /// (OutType 2) output.
    ///
    /// This engine implements the exhaustive all-pairs-within-MaxDist algorithm described in
    /// the PopLDdecay paper (Zhang et al., Bioinformatics 2019): every retained SNP is compared
    /// against every other SNP up to MaxDist. Its NumberPairs output was validated TWO ways and
    /// matches both exactly: (1) an independent first-principles recomputation from the raw VCF,
    /// and (2) the original PopLDdecay C++ compiled from the master source and run on Linux CI —
    /// identical NumberPairs at every distance bin. The per-pair r^2/D' math is a faithful port
    /// of Calculate.h (Mean_r^2 agrees). (A previously-supplied reference *.stat file showed
    /// fewer long-range pairs, but that was traced to how that particular file was generated —
    /// a different build/params — not to this algorithm or the master source.) The Deterministic
    /// flag forces single-thread, fixed-order accumulation for run-to-run reproducibility.
    /// </summary>
    public sealed class LdAnalysisEngine : ILdAnalysisEngine
    {
        /// <summary>When true, forces single-thread, fixed-order accumulation for run-to-run
        /// reproducibility (removes floating-point non-determinism from parallel merge order).</summary>
        public bool Deterministic { get; set; }

        /// <summary>If &gt; 0, forces this degree of parallelism (benchmarks); otherwise HAPE decides.</summary>
        public int ForcedDop { get; set; }

        /// <summary>
        /// Cache-blocking tile size (SNPs per block). A fixed default, not measured from the
        /// machine: 128 sites of a 1000-Genomes-sized sample (~280 bytes per packed site) keep
        /// two blocks far inside any L2 cache. Adjustable with the CLI's --block.
        /// </summary>
        public int BlockSize { get; set; } = 128;

        /// <summary>The smallest block the tiling uses; a smaller <see cref="BlockSize"/> is raised to it.</summary>
        public const int MinBlockSize = 8;

        /// <summary>Per-distance accumulators owned by one parallel worker (merged lock-free at the end).</summary>
        private sealed class Acc
        {
            public readonly double[] SumRR;
            public readonly double[] SumD;
            public readonly long[] Count;
            public long Pairs;
            public Acc(int maxDistBp, bool withDPrime)
            {
                SumRR = new double[maxDistBp + 2];
                Count = new long[maxDistBp + 2];
                SumD = withDPrime ? new double[maxDistBp + 2] : null;
            }
        }

        public Task<AnalysisResult> RunAsync(
            AnalysisRequest request,
            IProgress<AnalysisProgress> progress,
            CancellationToken cancellationToken)
        {
            return Task.Run(() => Run(request, progress, cancellationToken), cancellationToken);
        }

        public EffectiveSettings Resolve(AnalysisRequest request)
        {
            var p = request.Parameters;
            bool ehh = p.OutType == LdOutputType.Ehh;
            string vcf = request.VcfPaths.Count > 0 ? request.VcfPaths[0] : null;
            // Phase is judged as the reader judges it, from the first record. An input that cannot
            // be read counts as unphased here; the run itself then reports why it cannot be read.
            bool filePhased;
            try { filePhased = vcf != null && File.Exists(vcf) && VcfGenotypeReader.IsPhased(vcf); }
            catch (Exception) { filePhased = false; }
            bool phased = filePhased && !p.IgnorePhase;
            bool ml = !phased && !ehh && p.UnphasedEstimator == UnphasedLdEstimator.MaximumLikelihood;

            var effective = p;
            bool estimatorIdle = p.UnphasedEstimator != UnphasedLdEstimator.PopLDdecay && !ml;
            // EHH keeps the flag: combined with EHH it is an error the run must still report.
            bool ignoreIdle = p.IgnorePhase && !filePhased && !ehh;
            if (estimatorIdle || ignoreIdle)
            {
                effective = p.Clone();
                if (estimatorIdle) effective.UnphasedEstimator = UnphasedLdEstimator.PopLDdecay;
                if (ignoreIdle) effective.IgnorePhase = false;
            }
            return new EffectiveSettings
            {
                Parameters = effective,
                ReadAsPhased = phased,
                LdEstimator = ehh ? null
                    : phased ? "phased haplotypes"
                    : ml ? "maximum likelihood (unphased)" : "PopLDdecay rule (unphased)",
                // Asked for, but not applied: a warning, so the CLI sends it to stderr.
                IgnoredOptionWarning = !ehh && phased && p.UnphasedEstimator == UnphasedLdEstimator.MaximumLikelihood
                    ? "warning: phased VCF, so the observed haplotypes are used and the unphased estimator does not apply"
                    : null,
            };
        }

        private AnalysisResult Run(
            AnalysisRequest request,
            IProgress<AnalysisProgress> progress,
            CancellationToken ct)
        {
            var p = request.Parameters;
            int maxDistBp = p.MaxDistKb * 1000;
            bool withDPrime = p.OutType == LdOutputType.R2AndDPrime;
            string vcf = request.VcfPaths.Count > 0 ? request.VcfPaths[0] : null;
            if (vcf == null)
                return new AnalysisResult { Success = false, Message = "No VCF input." };

            // Warnings and notes about the input itself. Each is reported as it arises and also
            // kept for the result, so a cache hit on this input can report the same ones.
            var notices = new List<string>();
            void Notice(double fraction, string stage)
            {
                notices.Add(stage);
                progress?.Report(new AnalysisProgress { Fraction = fraction, Stage = stage });
            }

            // --- load retained sites grouped by chromosome, bit-packing as we go ---
            System.Collections.Generic.HashSet<string> subPop = null;
            if (!string.IsNullOrWhiteSpace(request.SampleListPath))
                subPop = SampleListFile.Load(request.SampleListPath);

            // Without a usable #CHROM header there are no sample columns to read, and analysing
            // nothing must not look like a successful empty analysis.
            string[] headerSamples = VcfGenotypeReader.ReadHeader(vcf);
            if (headerSamples == null || headerSamples.Length == 0)
                return new AnalysisResult
                {
                    Success = false,
                    Message = "This file has no usable VCF header: no '#CHROM ... FORMAT <sample> …' " +
                              "line with sample columns was found before the first data record.",
                };

            // Report the SubPop join before reading records, as the original does: the number
            // that matters is how many list entries were found in the VCF header, not how many
            // names the file contains. Fewer than 3 is fatal there, so it is fatal here too.
            string subPopStage = "reading VCF";
            if (subPop != null)
            {
                var join = VcfGenotypeReader.JoinSubPop(headerSamples, subPop);
                // One message per category rather than one per name: a mistyped list can hold
                // thousands of unmatched names, and IProgress callbacks are not guaranteed to
                // arrive in order, so a single report keeps the warning readable and intact.
                if (join.Missing.Count > 0)
                    Notice(0.0, $"warning: {join.Missing.Count} listed sample(s) are not in the VCF " +
                                $"header: {Summarize(join.Missing)}");
                if (join.Repeated.Count > 0)
                    Notice(0.0, $"warning: {join.Repeated.Count} listed sample(s) appear more than once " +
                                $"in the VCF header: {Summarize(join.Repeated)}");
                if (join.Matched < 3)
                    return new AnalysisResult
                    {
                        Success = false,
                        Message = $"SubPop is too small: only {join.Matched} of the {subPop.Count} listed " +
                                  "samples were found in the VCF header (the original tool requires at " +
                                  "least 3). Check that the list matches this VCF's sample names.",
                    };
                subPopStage = $"reading VCF (SubPop: {join.Matched} of {subPop.Count} listed samples found)";
            }

            progress?.Report(new AnalysisProgress { Fraction = 0.0, Stage = subPopStage });
            var swRead = System.Diagnostics.Stopwatch.StartNew();
            var reader = new VcfGenotypeReader();
            var settings = Resolve(request);
            bool phased = settings.ReadAsPhased;
            // Phased input always uses its haplotypes; the estimator choice is for '/' genotypes.
            // EHH is refused on unphased data further down, so it never takes the genotype path.
            bool genotypeMl = settings.Parameters.UnphasedEstimator == UnphasedLdEstimator.MaximumLikelihood;
            string estimator = settings.LdEstimator;
            if (p.OutType != LdOutputType.Ehh)
            {
                // The ignored-option warning belongs to the request (the cache key leaves the option
                // out), so it is not one of the input's notices; the rest describe the input.
                if (settings.IgnoredOptionWarning != null)
                    progress?.Report(new AnalysisProgress { Fraction = 0.0, Stage = settings.IgnoredOptionWarning });
                else if (phased)
                    progress?.Report(new AnalysisProgress { Fraction = 0.0, Stage = "phased VCF: r^2 from the observed haplotypes" });
                else if (genotypeMl)
                    progress?.Report(new AnalysisProgress { Fraction = 0.0, Stage = "unphased VCF: haplotype frequencies estimated by maximum likelihood" });
                else
                    Notice(0.0, "note: unphased VCF: each heterozygote is read as (major, minor), as in PopLDdecay; " +
                                "for outbred samples the maximum-likelihood estimator is less biased");
            }
            var stats = new ReaderStats();
            var byChrom = new Dictionary<string, List<PackedSite>>();
            int read = 0, duplicates = 0;
            // A second retained record at the same CHROM/POS is dropped, as in the original.
            foreach (var site in VcfGenotypeReader.FirstAtEachPosition(reader.ReadSites(vcf, p, stats, subPop, phased),
                                                                       () => duplicates++))
            {
                ct.ThrowIfCancellationRequested();
                if (!byChrom.TryGetValue(site.Chrom, out var list)) byChrom[site.Chrom] = list = new List<PackedSite>();
                list.Add(PackedSite.For(site, genotypeMl));
                if ((++read & 0x3FFFF) == 0) // every ~262k kept SNPs, show it's alive
                    progress?.Report(new AnalysisProgress { Fraction = 0.05, Stage = $"reading VCF: {read:N0} SNP kept…" });
            }
            if (duplicates > 0)
                Notice(0.05, $"note: {duplicates:N0} duplicate CHROM/POS record(s) ignored (first one kept)");
            if (stats.SkippedShortLine > 0)
                Notice(0.05, $"warning: {stats.SkippedShortLine:N0} malformed record(s) were skipped " +
                             "(fewer columns than the header, or an empty sample column)");
            if (stats.MalformedPos > 0)
                Notice(0.05, $"warning: {stats.MalformedPos:N0} record(s) have a POS that is not a plain number; " +
                             "read as the original reads them (leading digits, else 0)");
            int nHap = stats.SampleCount * 2;
            swRead.Stop();

            // EHH is a separate analysis, not an output format: it grows haplotypes around one
            // anchor site and writes <prefix>.ehh.gz instead of the stat file, exactly as the
            // original tool's -EHH mode short-circuits the LD-decay path.
            if (p.OutType == LdOutputType.Ehh)
                return RunEhh(request, p, byChrom, nHap, phased, stats, swRead.Elapsed.TotalSeconds, progress, ct);

            // --- HAPE: choose degree of parallelism from cores + available RAM ---
            var scheduler = new HapeScheduler(maxDistBp, withDPrime);
            int dop = Deterministic ? 1 : (ForcedDop > 0 ? ForcedDop : scheduler.DecideDegreeOfParallelism());

            progress?.Report(new AnalysisProgress
            {
                Fraction = 0.1,
                Stage = $"pairwise {(withDPrime ? "r^2 & D'" : "r^2")}{(genotypeMl ? " (ML)" : "")} on {read:N0} SNP (x{dop} cores)…",
            });

            var swPair = System.Diagnostics.Stopwatch.StartNew();
            Acc global;
            Acc[] workers = null;   // the parallel workers' tables: made once, merged once below
            try
            {
                global = new Acc(maxDistBp, withDPrime);
                // Chromosomes in the original's order: it keeps them in a std::map<string, …>,
                // which iterates by byte-wise string comparison. The order does not change which
                // pairs are counted, but it is the order the per-distance sums are added in, so it
                // is part of reproducing the original's numbers exactly.
                var chroms = new List<string>(byChrom.Keys);
                chroms.Sort(StringComparer.Ordinal);
                foreach (var chrom in chroms)
                {
                    var list = byChrom[chrom];
                    list.Sort((a, b) => a.Pos.CompareTo(b.Pos)); // ascending, like the sorted map
                    var sites = list.ToArray();
                    AccumulateChrom(sites, nHap, maxDistBp, withDPrime, genotypeMl, dop, global, ref workers, ct);
                }
                if (workers != null)
                    foreach (var w in workers) MergeInto(global, w, withDPrime);
            }
            catch (OutOfMemoryException)
            {
                double gb = scheduler.PerWorkerBytes / (1024.0 * 1024 * 1024);
                return new AnalysisResult
                {
                    Success = false,
                    Message = $"Not enough memory for MaxDist {p.MaxDistKb} kb: the per-distance tables need " +
                              $"about {gb.ToString("F1", CultureInfo.InvariantCulture)} GB for each of the " +
                              $"{Math.Max(1, dop)} worker(s) plus one more for the total. Use a smaller MaxDist.",
                };
            }
            swPair.Stop();

            // --- write <prefix>.stat.gz in the original format ---
            progress?.Report(new AnalysisProgress { Fraction = 0.95, Stage = "writing stat" });
            var swWrite = System.Diagnostics.Stopwatch.StartNew();
            string statPath = OutputPaths.StatFor(request.OutputPrefix);
            WriteStat(statPath, global.SumRR, global.SumD, global.Count, maxDistBp);
            swWrite.Stop();

            return new AnalysisResult
            {
                Success = true,
                StatFilePath = statPath,
                PairsEvaluated = global.Pairs,
                DegreeOfParallelism = dop,
                ReadSeconds = swRead.Elapsed.TotalSeconds,
                PairwiseSeconds = swPair.Elapsed.TotalSeconds,
                WriteSeconds = swWrite.Elapsed.TotalSeconds,
                LdEstimator = estimator,
                InputNotices = notices,
                Message = $"kept {read} SNP, {global.Pairs} pairs, dop={dop}, LD from {estimator} -> {statPath}",
            };
        }

        /// <summary>
        /// Runs the EHH branch: resolves the anchor's chromosome, hands the sorted sites to
        /// <see cref="EhhAnalysis"/> and reports the outcome. Failures (bad anchor, unknown
        /// chromosome, too few fully-called SNP) come back as a failed result with a message
        /// that says how to fix the run, rather than an exception.
        /// </summary>
        private AnalysisResult RunEhh(
            AnalysisRequest request, AnalysisParameters p, Dictionary<string, List<PackedSite>> byChrom,
            int nHap, bool phased, ReaderStats stats, double readSeconds, IProgress<AnalysisProgress> progress,
            CancellationToken ct)
        {
            if (!SiteParser.TryParse(p.EhhSite, out string requestedChrom, out long anchor))
                return new AnalysisResult
                {
                    Success = false,
                    Message = "EHH needs an anchor site written as chr:pos, e.g. 22:17000000.",
                };

            // EHH grows haplotypes, so it is only meaningful on phased genotypes: with '/'
            // genotypes the original canonicalises every het to (major, minor), which makes
            // every heterozygous sample carry the same two haplotypes and the decay curve
            // meaningless. Phasing is judged from the first data record, as the original does.
            if (!phased)
                return new AnalysisResult
                {
                    Success = false,
                    Message = p.IgnorePhase
                        ? "EHH needs phased haplotypes, but this run was asked to ignore the VCF's phase. " +
                          "Run EHH without the ignore-phase option."
                        : "EHH needs a PHASED VCF (genotypes written with '|'); this file's first " +
                          "record uses '/'. Phase it first (e.g. with SHAPEIT/Beagle), or use " +
                          "analysis type 1 or 2, which the tool computes for unphased data too.",
                };

            string chrom = ResolveChromosome(requestedChrom, byChrom.Keys);
            if (chrom == null)
                return new AnalysisResult
                {
                    Success = false,
                    Message = $"EHH chromosome '{requestedChrom}' is not in the retained SNP set " +
                              $"(available: {string.Join(", ", new List<string>(byChrom.Keys).ToArray())}).",
                };
            var list = byChrom[chrom];

            list.Sort((a, b) => a.Pos.CompareTo(b.Pos));
            progress?.Report(new AnalysisProgress { Fraction = 0.5, Stage = $"EHH around {chrom}:{anchor}…" });

            string ehhPath = OutputPaths.EhhFor(request.OutputPrefix);
            var swEhh = System.Diagnostics.Stopwatch.StartNew();
            var outcome = EhhAnalysis.Run(list, nHap, chrom, anchor, p.MaxDistKb * 1000, ehhPath, ct);
            swEhh.Stop();

            if (!outcome.Success)
                return new AnalysisResult { Success = false, Message = outcome.Message };

            progress?.Report(new AnalysisProgress { Fraction = 1.0, Stage = "EHH done" });
            return new AnalysisResult
            {
                Success = true,
                StatFilePath = ehhPath,
                PairsEvaluated = outcome.SitesUsed,
                DegreeOfParallelism = 1,
                ReadSeconds = readSeconds,
                PairwiseSeconds = swEhh.Elapsed.TotalSeconds,
                WriteSeconds = 0,
                Message = outcome.Message,
            };
        }

        /// <summary>
        /// The VCF's name for the anchor's chromosome: an exact match first, then the usual
        /// "chr22" / "Chr22" / "22" spellings of the same name (the prefix compared without
        /// regard to case). Null when nothing matches, or when the tolerant match is ambiguous.
        /// </summary>
        public static string ResolveChromosome(string requested, IEnumerable<string> available)
        {
            var names = new List<string>(available);
            if (names.Contains(requested)) return requested;
            string bare = StripChr(requested);
            string found = null;
            foreach (var n in names)
            {
                if (!string.Equals(StripChr(n), bare, StringComparison.Ordinal)) continue;
                if (found != null) return null;   // two candidates: refuse to guess
                found = n;
            }
            return found;
        }

        private static string StripChr(string name)
            => name.StartsWith("chr", StringComparison.OrdinalIgnoreCase) ? name.Substring(3) : name;

        /// <summary>
        /// Accumulates all in-window pairs of one chromosome. Single-thread uses a plain
        /// sequential scan (exact reference order), and so does a chromosome that fits in one
        /// block, where there is nothing to share out. Parallel uses cache-blocked tiling: the
        /// sorted sites are cut into L2-sized blocks and workers claim i-blocks dynamically
        /// (Interlocked), so each i-block stays hot in cache while every reachable j-block is
        /// reused across all sites in the block — cutting the memory traffic that otherwise
        /// caps multicore scaling.
        /// <para>The workers' tables (<paramref name="workers"/>) are made on the first parallel
        /// chromosome and kept for the whole run; the caller merges them once at the end. Making,
        /// zeroing and merging dop tables of MaxDist entries for every chromosome made an
        /// assembly of thousands of short contigs hundreds of times slower in parallel than on
        /// one thread.</para>
        /// </summary>
        private void AccumulateChrom(
            PackedSite[] sites, int nHap, int maxDistBp, bool withDPrime, bool genotypeMl, int dop, Acc global,
            ref Acc[] workers, CancellationToken ct)
        {
            int m = sites.Length;
            if (m < 2) return;

            int b = Math.Max(MinBlockSize, BlockSize);
            int numBlocks = (m + b - 1) / b;
            if (dop <= 1 || numBlocks == 1)
            {
                AccumulateRange(sites, nHap, maxDistBp, withDPrime, genotypeMl, global, ct);
                return;
            }

            if (workers == null)
            {
                workers = new Acc[dop];
                for (int t = 0; t < dop; t++) workers[t] = new Acc(maxDistBp, withDPrime);
            }
            int nextBlock = -1;
            var tasks = new Task[Math.Min(dop, numBlocks)];   // no idle workers on a short chromosome
            for (int t = 0; t < tasks.Length; t++)
            {
                var acc = workers[t];
                tasks[t] = Task.Run(() =>
                {
                    int bi;
                    while ((bi = Interlocked.Increment(ref nextBlock)) < numBlocks)
                        ProcessIBlock(sites, bi, b, m, nHap, maxDistBp, withDPrime, genotypeMl, acc, ct);
                }, ct);
            }
            try
            {
                Task.WaitAll(tasks);
            }
            catch (AggregateException ae)
            {
                // WaitAll wraps whatever the workers threw. A cancelled run must surface as a
                // cancellation — the caller tells "Cancelled" from "Failed" by the exception
                // type — and any other failure as the worker's own exception, not the wrapper.
                ct.ThrowIfCancellationRequested();
                var inner = ae.Flatten().InnerExceptions;
                if (inner.Count > 0) ExceptionDispatchInfo.Capture(inner[0]).Throw();
                throw;
            }
        }

        /// <summary>Computes all in-window pairs whose first site is in i-block <paramref name="bi"/>.</summary>
        private static void ProcessIBlock(
            PackedSite[] sites, int bi, int b, int m, int nHap, int maxDistBp, bool withDPrime, bool genotypeMl,
            Acc acc, CancellationToken ct)
        {
            int iLo = bi * b;
            int iHi = Math.Min(m, iLo + b);
            long lastIPos = sites[iHi - 1].Pos;
            double[] sumRR = acc.SumRR, sumD = acc.SumD;
            long[] count = acc.Count;
            long pairs = acc.Pairs;
            ct.ThrowIfCancellationRequested();

            for (int bj = bi; bj < (m + b - 1) / b; bj++)
            {
                int jLo = bj * b;
                int jHi = Math.Min(m, jLo + b);
                // Nearest possible pair between the two blocks; if already out of window, done.
                if (sites[jLo].Pos - lastIPos > maxDistBp) break;

                for (int i = iLo; i < iHi; i++)
                {
                    var si = sites[i];
                    long pi = si.Pos;
                    int j = (bj == bi) ? i + 1 : jLo;
                    for (; j < jHi; j++)
                    {
                        long dis = sites[j].Pos - pi;
                        if (dis > maxDistBp) break;
                        if (PairLd(si, sites[j], nHap, withDPrime, genotypeMl, out double r2, out double dp))
                        {
                            sumRR[dis] += r2; count[dis]++; pairs++;
                            if (withDPrime) sumD[dis] += dp;
                        }
                    }
                }
            }
            acc.Pairs = pairs;
        }

        /// <summary>All in-window pairs of one chromosome in the reference's order (single thread).</summary>
        private static void AccumulateRange(
            PackedSite[] sites, int nHap, int maxDistBp, bool withDPrime, bool genotypeMl, Acc acc, CancellationToken ct)
        {
            int m = sites.Length;
            double[] sumRR = acc.SumRR, sumD = acc.SumD;
            long[] count = acc.Count;
            long pairs = acc.Pairs;   // accumulate across chromosomes, like the parallel path

            for (int i = 0; i < m; i++)
            {
                if ((i & 1023) == 0) ct.ThrowIfCancellationRequested();
                var si = sites[i];
                long pi = si.Pos;
                for (int j = i + 1; j < m; j++)
                {
                    long dis = sites[j].Pos - pi;
                    if (dis > maxDistBp) break;
                    if (PairLd(si, sites[j], nHap, withDPrime, genotypeMl, out double r2, out double dp))
                    {
                        sumRR[dis] += r2; count[dis]++; pairs++;
                        if (withDPrime) sumD[dis] += dp;
                    }
                }
            }
            acc.Pairs = pairs;
        }

        /// <summary>
        /// One pair's r^2 (and D' when asked) by the kernel the run uses. Shared by the sequential
        /// and the block-parallel loops, so the two can never accumulate different statistics.
        /// </summary>
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.AggressiveInlining)]
        private static bool PairLd(PackedSite a, PackedSite b, int nHap, bool withDPrime, bool genotypeMl,
            out double r2, out double dPrime)
        {
            if (genotypeMl) return LdKernel.TryGenotypeMl(a, b, withDPrime, out r2, out dPrime);
            if (withDPrime) return LdKernel.TryR2AndDPrimePacked(a, b, nHap, out r2, out dPrime);
            dPrime = 0.0;
            return LdKernel.TryR2Packed(a, b, nHap, out r2);
        }

        private static void MergeInto(Acc global, Acc part, bool withDPrime)
        {
            double[] gRR = global.SumRR, pRR = part.SumRR;
            long[] gC = global.Count, pC = part.Count;
            int n = gRR.Length;
            for (int i = 0; i < n; i++) { gRR[i] += pRR[i]; gC[i] += pC[i]; }
            if (withDPrime)
            {
                double[] gD = global.SumD, pD = part.SumD;
                for (int i = 0; i < n; i++) gD[i] += pD[i];
            }
            global.Pairs += part.Pairs;
        }

        /// <summary>Lists up to eight names, then "… and N more".</summary>
        private static string Summarize(List<string> names)
        {
            const int Show = 8;
            if (names.Count <= Show) return string.Join(", ", names.ToArray());
            var head = names.GetRange(0, Show);
            return string.Join(", ", head.ToArray()) + $", … and {names.Count - Show} more";
        }

        /// <summary>
        /// Writes the stat file atomically (see <see cref="AtomicFile"/>): a run that fails while
        /// writing leaves the previous result in place, never a truncated one.
        /// </summary>
        private static void WriteStat(string path, double[] sumRR, double[] sumD, long[] count, int maxDistBp)
            => AtomicFile.Write(path, fs => WriteStatBody(fs, sumRR, sumD, count, maxDistBp));

        private static void WriteStatBody(Stream fs, double[] sumRR, double[] sumD, long[] count, int maxDistBp)
        {
            var inv = CultureInfo.InvariantCulture;
            bool withDPrime = sumD != null;
            using (var gz = new GZipStream(fs, CompressionLevel.Optimal, true))
            using (var w = new StreamWriter(gz, new System.Text.UTF8Encoding(false), 1 << 20))
            {
                w.Write(ResultFormat.StatHeader);
                for (int ii = 1; ii <= maxDistBp; ii++)
                {
                    long c = count[ii];
                    if (c == 0) continue;
                    double sr = sumRR[ii];
                    double mr = sr / c;
                    w.Write(ii.ToString(inv));
                    w.Write('\t');
                    w.Write(FixedFormat.F4(mr, inv));
                    if (withDPrime)
                    {
                        double sd = sumD[ii];
                        double md = sd / c;
                        w.Write('\t'); w.Write(FixedFormat.F4(md, inv));
                        w.Write('\t'); w.Write(FixedFormat.F4(sr, inv));
                        w.Write('\t'); w.Write(FixedFormat.F4(sd, inv));
                    }
                    else
                    {
                        w.Write("\tNA\t");
                        w.Write(FixedFormat.F4(sr, inv));
                        w.Write("\tNA");
                    }
                    w.Write('\t');
                    w.Write(c.ToString(inv));
                    w.Write('\n');
                }
            }
        }

    }
}
