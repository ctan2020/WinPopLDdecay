using System;
using System.Collections.Generic;
using System.IO;

namespace PopLD.Infrastructure.Plotting
{
    /// <summary>What statistics a result file actually carries.</summary>
    public enum ResultContent
    {
        /// <summary>Unreadable, or not a layout we recognise — offer everything and let the plot report it.</summary>
        Unknown,
        /// <summary>An <c>*.ehh.gz</c> in the reference EHH layout.</summary>
        Ehh,
        /// <summary>LD decay with r² only: the reference's <c>-OutType 1</c> writes "NA" in both D' columns.</summary>
        R2Only,
        /// <summary>LD decay carrying r² and D': the reference's <c>-OutType 2</c> (or the 5-column <c>-OutType 4</c>).</summary>
        R2AndDPrime,
    }

    /// <summary>
    /// Reads just enough of a result file to say which statistics it holds, so the plot's Y-axis
    /// offers what the data can actually produce instead of what the last analysis was configured
    /// to compute. Cheap by construction: it stops at the first row that settles the question, and
    /// never reads more than <see cref="MaxDataRows"/> data rows.
    /// </summary>
    public static class ResultFileProbe
    {
        /// <summary>
        /// How many data rows to read before concluding "no D' here". Our own writer is
        /// all-or-nothing per file — <c>WriteStat</c> emits "NA" in the D' columns for every row of
        /// an r²-only run — so one row decides it. The cap only bounds the cost on a foreign file
        /// that happens to start with D'-less bins.
        /// </summary>
        private const int MaxDataRows = 512;

        /// <summary>
        /// True when <paramref name="path"/> is an EHH result: named *.ehh / *.ehh.gz, or carrying
        /// the reference EHH header. The one test every plot path dispatches on, so a file the
        /// Y-axis box calls EHH is also read as EHH.
        /// </summary>
        public static bool IsEhh(string path) => Probe(path) == ResultContent.Ehh;

        /// <summary>Classifies one result file. Never throws: an unreadable file is Unknown.</summary>
        public static ResultContent Probe(string path)
        {
            if (string.IsNullOrEmpty(path)) return ResultContent.Unknown;
            if (path.EndsWith(".ehh.gz", StringComparison.OrdinalIgnoreCase) ||
                path.EndsWith(".ehh", StringComparison.OrdinalIgnoreCase))
                return ResultContent.Ehh;

            try
            {
                // Gzipped or plain, recognised from the content — the same reader the plot uses.
                using (var r = PopLD.Domain.IO.TextInput.OpenText(path, 1 << 16))
                {
                    string header = r.ReadLine();
                    if (header == null) return ResultContent.Unknown;
                    // The reference EHH layout, in case an EHH file was saved under another name.
                    if (header.IndexOf("EHH_all", StringComparison.Ordinal) >= 0) return ResultContent.Ehh;
                    // 3 columns = -OutType 5 (r² and a count, no D'); 5 columns = -OutType 4
                    // (r², D' and their counts); 6 columns = the MeanBin layout this tool writes,
                    // where the D' columns are "NA" unless the run computed D'.
                    var layout = StatFileBinner.LayoutOf(header);
                    if (layout == null) return ResultContent.Unknown;
                    if (layout == StatFileBinner.StatLayout.R2Count) return ResultContent.R2Only;
                    if (layout == StatFileBinner.StatLayout.R2AndDCount) return ResultContent.R2AndDPrime;

                    string line;
                    int rows = 0;
                    while (rows < MaxDataRows && (line = r.ReadLine()) != null)
                    {
                        if (line.Length == 0 || line.IndexOf('#') >= 0) continue;
                        var f = line.Split(StatFileBinner.FieldSep, StringSplitOptions.RemoveEmptyEntries);
                        if (f.Length < 3) continue;
                        rows++;
                        // Same field and same test as the binner (and the reference, `ne "NA"`):
                        // Sum_D' is the second from the end, and only an exact "NA" means none.
                        if (!string.Equals(f[f.Length - 2], "NA", StringComparison.Ordinal))
                            return ResultContent.R2AndDPrime;
                    }
                    return rows > 0 ? ResultContent.R2Only : ResultContent.Unknown;
                }
            }
            catch { return ResultContent.Unknown; }
        }

        /// <summary>
        /// Classifies a whole selection. D' is offered only when EVERY file carries it — a mixed
        /// set would otherwise draw some curves and warn about the rest. A mixed EHH/LD selection
        /// comes back as Unknown; the plot refuses that combination on its own.
        /// </summary>
        public static ResultContent ProbeAll(IEnumerable<string> paths)
        {
            int total = 0, ehh = 0, ld = 0, ldWithDPrime = 0, unknown = 0;
            foreach (string p in paths ?? new string[0])
            {
                total++;
                switch (Probe(p))
                {
                    case ResultContent.Ehh: ehh++; break;
                    case ResultContent.R2AndDPrime: ld++; ldWithDPrime++; break;
                    case ResultContent.R2Only: ld++; break;
                    default: unknown++; break;
                }
            }
            if (total == 0) return ResultContent.Unknown;
            if (ehh == total) return ResultContent.Ehh;
            // Anything unreadable, or EHH mixed with LD, leaves the question open: stay permissive
            // and let the plot report it (a mixed EHH/LD selection it refuses outright).
            if (unknown > 0 || ehh > 0) return ResultContent.Unknown;
            return ldWithDPrime == ld ? ResultContent.R2AndDPrime : ResultContent.R2Only;
        }
    }
}
