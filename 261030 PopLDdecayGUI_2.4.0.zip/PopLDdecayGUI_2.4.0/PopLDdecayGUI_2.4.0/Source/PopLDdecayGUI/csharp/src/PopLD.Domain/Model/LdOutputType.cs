namespace PopLD.Domain.Model
{
    /// <summary>
    /// What the run computes. Values 1 and 2 mirror the original PopLDdecay <c>-OutType</c>
    /// (r^2, r^2+D'). Value 3 is this GUI's own numbering for the original's separate
    /// <c>-EHH chr:pos</c> mode: in the C++ tool EHH is not an OutType at all but a switch that
    /// short-circuits the LD-decay path, so exposing it as a third mutually exclusive choice
    /// matches what the program actually does. (The original's own OutType 3 is a pairwise-LD
    /// dump, which this GUI does not offer.) EHH needs an anchor site, so
    /// <see cref="AnalysisParameters.EhhSite"/> is required when this value is selected.
    /// </summary>
    public enum LdOutputType
    {
        /// <summary>Bin-averaged r^2 versus distance (default).</summary>
        R2 = 1,

        /// <summary>Bin-averaged r^2 and D' versus distance.</summary>
        R2AndDPrime = 2,

        /// <summary>Extended haplotype homozygosity decay around an anchor site.</summary>
        Ehh = 3,
    }
}
