using System.Collections.Generic;

namespace PopLD.Domain.Abstractions
{
    /// <summary>
    /// Content-Addressed Incremental Recomputation (CAIR) store. Results are keyed by the
    /// content of everything that affects the <c>.stat.gz</c> (input identity + filter params +
    /// OutType), but NOT by MaxDist or plot params. Because a stat file holds every integer
    /// distance up to its MaxDist, a cached result computed at a larger MaxDist can serve any
    /// smaller-MaxDist request by truncation — turning parameter tweaks into instant hits.
    /// </summary>
    public interface ICacheStore
    {
        /// <summary>
        /// If a cached result exists for <paramref name="key"/> whose MaxDist is at least
        /// <paramref name="requestedMaxDistBp"/>, materializes it to <paramref name="outputStatPath"/>
        /// (copy or distance-truncate), hands back the input notices stored with it, and returns
        /// true. Otherwise returns false. Throws <see cref="CacheUnavailableException"/> when the
        /// cache cannot be read; other exceptions concern writing <paramref name="outputStatPath"/>.
        /// </summary>
        bool TryServe(string key, int requestedMaxDistBp, string outputStatPath, out IReadOnlyList<string> inputNotices);

        /// <summary>
        /// Stores a freshly computed stat file under the key with its MaxDist, together with the
        /// warnings and notes its run reported about the input (see
        /// <see cref="Model.AnalysisResult.InputNotices"/>).
        /// </summary>
        void Put(string key, string statPath, int maxDistBp, IReadOnlyList<string> inputNotices);

        /// <summary>
        /// Discards every cached result, so the next run of any input recomputes from scratch.
        /// Returns how many entries were removed. Used by the GUI's "reset cached results"
        /// action when a user wants a guaranteed-fresh run.
        /// </summary>
        int Clear();
    }
}
