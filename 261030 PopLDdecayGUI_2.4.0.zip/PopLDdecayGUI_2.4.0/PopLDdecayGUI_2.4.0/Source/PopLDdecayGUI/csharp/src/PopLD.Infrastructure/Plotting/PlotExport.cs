using System;
using System.Collections.Generic;
using PopLD.Domain.IO;
using PopLD.Domain.Model;

namespace PopLD.Infrastructure.Plotting
{
    /// <summary>
    /// The files a plot export writes, shared by the command line and the GUI so both write the
    /// same set and check the same names: the PDF (and the GUI's PNG) at the base name, then the
    /// data — the reference tool's <c>*.ehh</c> layout for EHH curves (one file per curve when
    /// there are several), otherwise one binned table per source result file. All of them are
    /// known before anything is written, so an export that would overwrite one of the very files
    /// being plotted is refused instead.
    /// </summary>
    public static class PlotExport
    {
        /// <summary>True when the data goes out in the reference's <c>*.ehh</c> layout.</summary>
        public static bool WritesEhh(IReadOnlyList<DecayPoints> series)
            => series != null && series.Count > 0 && series[0] != null &&
               series[0].Measure.StartsWith("EHH", StringComparison.Ordinal) && EhhFileWriter.CanWrite(series[0]);

        /// <summary>
        /// The <c>*.ehh.gz</c> files for an EHH export: <c>base.ehh.gz</c> for one curve, else one
        /// per curve with the collision-safe tags the binned tables use, so two inputs sharing a
        /// base name in different folders never write one file.
        /// </summary>
        public static string[] EhhTargets(string basePath, IReadOnlyList<DecayPoints> series)
        {
            if (series.Count == 1) return new[] { basePath + ".ehh.gz" };
            string[] tags = PlotDataWriter.UniqueTags(series);
            var paths = new string[series.Count];
            for (int i = 0; i < series.Count; i++) paths[i] = basePath + "." + tags[i] + ".ehh.gz";
            return paths;
        }

        /// <summary>
        /// Writes the data of an export and returns the files written: the reference's
        /// <c>*.ehh</c> layout for EHH curves, else one binned table per source result file,
        /// whose parameter comment records the measure drawn and the binning applied (a 0 bin
        /// width or break resolved to its default, maxX as the chart shows it). The names come
        /// back from the writers because neither writes one predictable file.
        /// </summary>
        public static string[] WriteData(string basePath, IReadOnlyList<DecayPoints> series, PlotMeasure measure,
            int bin1Bp, int bin2Bp, int breakBp)
        {
            if (WritesEhh(series))
            {
                string[] ehhOut = EhhTargets(basePath, series);
                for (int i = 0; i < ehhOut.Length; i++) EhhFileWriter.Write(ehhOut[i], series[i]);
                return ehhOut;
            }
            string desc = PlotDataWriter.Describe(PlotLoader.Describe(measure),
                ParameterRules.EffectiveBin(bin1Bp, ParameterRules.DefaultBin1),
                ParameterRules.EffectiveBin(bin2Bp, ParameterRules.DefaultBin2),
                ParameterRules.EffectiveBreak(breakBp),
                PlotDataWriter.EffectiveMaxXKb(series));
            return PlotDataWriter.Write(basePath + ".bin.gz", series, desc);
        }

        /// <summary>Every file the export writes, in the order it writes them.</summary>
        public static List<string> Targets(string basePath, IReadOnlyList<DecayPoints> series, bool withPng)
        {
            var targets = new List<string>();
            if (withPng) targets.Add(basePath + ".png");
            targets.Add(basePath + ".pdf");
            targets.AddRange(WritesEhh(series)
                ? EhhTargets(basePath, series)
                : PlotDataWriter.TargetPaths(basePath + ".bin.gz", series));
            return targets;
        }

        /// <summary>
        /// The input the export would overwrite (the same file, however its path is written), or
        /// null. Plotting an exported table and exporting under the same name again would
        /// otherwise replace the input with its own re-binned copy. <paramref name="otherInputs"/>
        /// are the files the user gave beyond those that made a curve: a file left off the chart
        /// (no points in the chosen statistic) is still the user's input and must survive too.
        /// </summary>
        public static string OverwrittenInput(string basePath, IReadOnlyList<DecayPoints> series, bool withPng,
            IEnumerable<string> otherInputs = null)
        {
            var inputs = new List<string>();
            foreach (var s in series)
                if (s != null && !string.IsNullOrEmpty(s.SourcePath)) inputs.Add(s.SourcePath);
            if (otherInputs != null) inputs.AddRange(otherInputs);
            var hit = FileIdentity.FindConflict(Targets(basePath, series, withPng), inputs);
            return hit?.Item2;
        }
    }
}
