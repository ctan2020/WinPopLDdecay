namespace PopLD.Engine
{
    /// <summary>
    /// Core pairwise LD statistics, ported faithfully from PopLDdecay's Calculate.h: the
    /// per-pair r^2 and D' values reproduce the original formulas (verified — the Mean_r^2
    /// column agrees with the reference). Haplotype values are 0 (major) / 1 (minor); value 2
    /// (missing/other) is dropped from the 2x2 table, matching the original for filtered
    /// phased data. This is the per-pair math only; the whole-file totals it feeds match the
    /// original PopLDdecay compiled from the master source — identical NumberPairs in every
    /// distance bin on Linux CI — see <see cref="LdAnalysisEngine"/> for that validation.
    /// </summary>
    public static class LdKernel
    {
        /// <summary>
        /// Population count. On net8+ this is <see cref="System.Numerics.BitOperations.PopCount"/>,
        /// which the JIT lowers to the hardware POPCNT instruction (with its own software fallback
        /// when the CPU lacks it) — the single biggest kernel speedup on modern machines. net48 has
        /// no such intrinsic, so it uses the SWAR (in-register parallel) fallback below.
        /// </summary>
#if NET8_0_OR_GREATER
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.AggressiveInlining)]
        public static int PopCount(ulong x) => System.Numerics.BitOperations.PopCount(x);
#else
        public static int PopCount(ulong x)
        {
            x -= (x >> 1) & 0x5555555555555555UL;
            x = (x & 0x3333333333333333UL) + ((x >> 2) & 0x3333333333333333UL);
            x = (x + (x >> 4)) & 0x0f0f0f0f0f0f0f0fUL;
            return (int)((x * 0x0101010101010101UL) >> 56);
        }
#endif

        /// <summary>Builds the 2x2 haplotype table for two packed sites (fast path skips masks).</summary>
        private static void CountsPacked(PackedSite s1, PackedSite s2, int nHap,
            out long d00, out long d01, out long d10, out long d11)
        {
            ulong[] o1 = s1.Ones, o2 = s2.Ones;
            int words = o1.Length;
            long c11 = 0;

            if (!s1.AnyMissing && !s2.AnyMissing)
            {
                for (int w = 0; w < words; w++) c11 += PopCount(o1[w] & o2[w]);
                d11 = c11;
                d10 = s1.OnesCount - c11;
                d01 = s2.OnesCount - c11;
                d00 = nHap - d11 - d10 - d01;
            }
            else
            {
                // Cold path: at least one site has missing data. A null Valid plane means the
                // site is fully called, so its validity is all-ones (~0UL); the padding bits
                // beyond the real haplotypes are masked out by the other site's real Valid plane,
                // which has them zeroed — so counts stay exact.
                ulong[] v1 = s1.Valid, v2 = s2.Valid;
                long both = 0, o1v = 0, o2v = 0;
                for (int w = 0; w < words; w++)
                {
                    ulong v = (v1 != null ? v1[w] : ~0UL) & (v2 != null ? v2[w] : ~0UL);
                    ulong a = o1[w] & v;
                    ulong b = o2[w] & v;
                    c11 += PopCount(a & b);
                    o1v += PopCount(a);
                    o2v += PopCount(b);
                    both += PopCount(v);
                }
                d11 = c11;
                d10 = o1v - c11;
                d01 = o2v - c11;
                d00 = both - d11 - d10 - d01;
            }
        }

        /// <summary>r^2 from the popcount 2x2 table (OutType 1).</summary>
        public static bool TryR2Packed(PackedSite s1, PackedSite s2, int nHap, out double r2)
        {
            CountsPacked(s1, s2, nHap, out long d00, out long d01, out long d10, out long d11);
            r2 = 0.0;
            if (d11 + d10 == 0 || d11 + d01 == 0) return false;
            double all = d00 + d01 + d10 + d11;
            r2 = R2(d00 / all, d01 / all, d10 / all);
            return true;
        }

        /// <summary>r^2 and D' from the popcount 2x2 table (OutType 2, Calculate.h's cal_RR_D_MA).</summary>
        public static bool TryR2AndDPrimePacked(PackedSite s1, PackedSite s2, int nHap, out double r2, out double dPrime)
        {
            CountsPacked(s1, s2, nHap, out long d00, out long d01, out long d10, out long d11);
            r2 = 0.0; dPrime = 0.0;
            if (d11 + d10 == 0 || d11 + d01 == 0) return false;
            double all = d00 + d01 + d10 + d11;
            R2AndDPrime(d00 / all, d01 / all, d10 / all, out r2, out dPrime);
            return true;
        }

        /// <summary>
        /// r^2 (and D' when <paramref name="withDPrime"/>) for two UNPHASED sites packed by
        /// <see cref="PackedSite.PackGenotypes"/>, from maximum-likelihood haplotype frequencies:
        /// <see cref="GenotypeHaplotypeCounts"/> gives the haplotypes the genotypes fix, and
        /// <see cref="HaplotypeMle"/> splits the double heterozygotes. The frequencies then go through
        /// the same r^2/D' formulas as phased data, and the pair is skipped under the same rule: a
        /// site with no minor allele among the samples called at both.
        /// </summary>
        public static bool TryGenotypeMl(PackedSite s1, PackedSite s2, bool withDPrime, out double r2, out double dPrime)
        {
            GenotypeHaplotypeCounts(s1, s2, out long k11, out long k10, out long k01, out long k00, out long h);
            r2 = 0.0; dPrime = 0.0;
            // A site with no minor allele here gives no pair; checked before the solve it would skip.
            if (k11 + k10 + h == 0 || k11 + k01 + h == 0) return false;

            double u = HaplotypeMle.CoupledDoubleHets(k11, k10, k01, k00, h);
            double d11 = k11 + u, d00 = k00 + u, d10 = k10 + h - u, d01 = k01 + h - u;
            double all = d00 + d01 + d10 + d11;
            if (withDPrime) R2AndDPrime(d00 / all, d01 / all, d10 / all, out r2, out dPrime);
            else r2 = R2(d00 / all, d01 / all, d10 / all);
            return true;
        }

        /// <summary>
        /// The two-locus haplotype counts that the genotypes of two UNPHASED sites fix, over the
        /// samples called at both (1 = minor allele, first digit = first site), and the number of
        /// double heterozygotes, whose phase they leave open. The 3x3 genotype table costs four
        /// popcounts per 64 samples on the Hom/Car planes; its marginals come from the per-site
        /// counts, or, when a site has missing calls, from popcounts masked by the other's calls.
        /// </summary>
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.AggressiveInlining)]
        public static void GenotypeHaplotypeCounts(PackedSite s1, PackedSite s2,
            out long k11, out long k10, out long k01, out long k00, out long doubleHets)
        {
            ulong[] h1 = s1.Hom, c1 = s1.Car, h2 = s2.Hom, c2 = s2.Car;
            int words = h1.Length;
            long hh = 0, hc = 0, ch = 0, cc = 0;
            for (int w = 0; w < words; w++)
            {
                ulong a = h1[w], b = c1[w], x = h2[w], y = c2[w];
                hh += PopCount(a & x);
                hc += PopCount(a & y);
                ch += PopCount(b & x);
                cc += PopCount(b & y);
            }

            long nS, hom1, car1, hom2, car2;
            if (!s1.AnyMissing && !s2.AnyMissing)
            {
                nS = s1.SampleCount;
                hom1 = s1.HomCount; car1 = s1.CarCount;
                hom2 = s2.HomCount; car2 = s2.CarCount;
            }
            else
            {
                // Marginals over the samples called at BOTH sites. The cross terms above need no
                // mask, since a sample missing at a site has no Hom/Car bit there. A null plane
                // means all-called; its ~0UL padding is cleared by the other site's real plane.
                ulong[] v1 = s1.SampleValid, v2 = s2.SampleValid;
                nS = hom1 = car1 = hom2 = car2 = 0;
                for (int w = 0; w < words; w++)
                {
                    ulong m1 = v1 != null ? v1[w] : ~0UL;
                    ulong m2 = v2 != null ? v2[w] : ~0UL;
                    nS += PopCount(m1 & m2);
                    hom1 += PopCount(h1[w] & m2); car1 += PopCount(c1[w] & m2);
                    hom2 += PopCount(h2[w] & m1); car2 += PopCount(c2[w] & m1);
                }
            }

            // Genotype table n[g1][g2], g = minor-allele dosage.
            long n22 = hh, n21 = hc - hh, n12 = ch - hh, n11 = cc - hc - ch + hh;
            long n20 = hom1 - hc, n02 = hom2 - ch;
            long n10 = car1 - hom1 - n12 - n11, n01 = car2 - hom2 - n21 - n11;
            long n00 = nS - n22 - n21 - n12 - n11 - n20 - n02 - n10 - n01;

            k11 = 2 * n22 + n21 + n12;
            k10 = 2 * n20 + n21 + n10;
            k01 = 2 * n02 + n12 + n01;
            k00 = 2 * n00 + n10 + n01;
            doubleHets = n11;
        }

        /// <summary>
        /// The OutType 1 r^2 of PopLDdecay v3.45 (ProMethod1.h, PairWiseComV1, OutType 1 branch)
        /// from the frequencies p0 = f00, p1 = f01, p2 = f10 of a 2x2 haplotype table
        /// (0 = major, first digit = first site), including its 1e-10 clamp. The single copy of
        /// this formula: every r^2 path (phased, PopLDdecay rule, maximum likelihood) applies its
        /// own skip rule, normalises its own table and comes here.
        /// <para>Written operation for operation as v3.45 writes it, so every pair's r^2 is the
        /// same double: <c>Cal_A = 1.0 - pA1 - pA2 + Cal_B</c>, i.e. ((1 - pA1) - pA2) + Cal_B.
        /// v3.45's own <c>cal_RR_MA</c> (the OutType 2 path) groups it as <c>1.0 - (pA1 + pA2) + Cal_B</c>,
        /// which can differ in the last bit and, rarely, in the fourth decimal of one pair.</para>
        /// </summary>
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.AggressiveInlining)]
        private static double R2(double p0, double p1, double p2)
        {
            double pA1 = p0 + p1, pA2 = p0 + p2;
            double calB = pA1 * pA2;
            double calA = 1.0 - pA1 - pA2 + calB;
            if (calA == 0 || calB == 0)
            {
                if (p0 < 1e-10) p0 = 1e-10;
                if (p1 < 1e-10) p1 = 1e-10;
                if (p2 < 1e-10) p2 = 1e-10;
                pA1 = p0 + p1; pA2 = p0 + p2;
                calB = pA1 * pA2; calA = 1.0 - pA1 - pA2 + calB;
            }
            double dA = p0 - calB;
            return (dA * dA) / (calA * calB);
        }

        /// <summary>
        /// Calculate.h's r^2 and D' (cal_RR_D_MA) from the table frequencies, as for
        /// <see cref="R2"/>; the single copy of this formula. Its r^2 is algebraically identical to
        /// <see cref="R2"/>; D' is the normalized disequilibrium.
        /// </summary>
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.AggressiveInlining)]
        private static void R2AndDPrime(double p0, double p1, double p2, out double r2, out double dPrime)
        {
            double pA1 = p0 + p1, pB1 = 1.0 - pA1;
            double pA2 = p0 + p2, pB2 = 1.0 - pA2;
            double xA1A2 = pA1 * pA2;
            double dInner = p0 - xA1A2;
            double calA, calB;
            // "0.0 - D", as Calculate.h writes it: for D == +0.0 that is +0.0, where "-D" would be
            // -0.0. The stat file cannot tell the two apart, a per-pair dump can.
            if (dInner > 0) { calA = pB1 * pA2; calB = pA1 * pB2; }
            else { dInner = 0.0 - dInner; calA = pB1 * pB2; calB = xA1A2; }
            double dMax = calA < calB ? calA : calB;
            if (dMax == 0)
            {
                if (p0 < 1e-10) p0 = 1e-10;
                if (p1 < 1e-10) p1 = 1e-10;
                if (p2 < 1e-10) p2 = 1e-10;
                pA1 = p0 + p1; pB1 = 1.0 - pA1;
                pA2 = p0 + p2; pB2 = 1.0 - pA2;
                xA1A2 = pA1 * pA2;
                dInner = p0 - xA1A2;
                if (dInner > 0) { calA = pB1 * pA2; calB = pA1 * pB2; }
                else { dInner = 0.0 - dInner; calA = pB1 * pB2; calB = xA1A2; }
                dMax = calA < calB ? calA : calB;
            }
            dPrime = dInner / dMax;
            r2 = (dInner / calA) * (dInner / calB);
        }
    }
}
