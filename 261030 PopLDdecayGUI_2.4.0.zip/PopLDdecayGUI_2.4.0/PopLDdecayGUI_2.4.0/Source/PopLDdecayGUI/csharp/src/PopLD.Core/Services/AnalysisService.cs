using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using PopLD.Domain.Abstractions;
using PopLD.Domain.IO;
using PopLD.Domain.Model;
using PopLD.Domain.Services;

namespace PopLD.Core.Services
{
    /// <summary>
    /// Application-layer orchestrator used by both the WPF UI and the CLI. Wraps the engine
    /// with the CAIR cache (skip recomputation on content-equal runs, reuse larger-MaxDist
    /// results by truncation) and records every run in the provenance ledger.
    /// </summary>
    public sealed class AnalysisService
    {
        private readonly ILdAnalysisEngine _engine;
        private readonly IResultRepository _results;
        /// <summary>The original tool clamps MAF to this floor in EHH mode.</summary>
        private const double EhhMinMaf = 0.05;

        /// <summary>
        /// Generation of the .stat.gz contents. It is part of the cache key, so entries written by
        /// an older build are simply never matched instead of being served as if this build had
        /// produced them — which would silently undo a correctness fix and leave the sidecar
        /// stamping the current version on numbers this build would not compute.
        /// <para>BUMP THIS whenever a change alters the bytes of a .stat.gz for the same inputs.
        /// 2 = unphased genotypes canonicalised like Read_VCF_IN, duplicate CHROM/POS dropped,
        /// and 4-decimal output rounded exactly as C's "%.4f".
        /// 3 = OutType 1 r^2 computed operation for operation as v3.45 does, chromosomes summed
        /// in the original's order, the reader's header/'N'/POS rules aligned with the
        /// original, and key numbers written round-trip.</para>
        /// </summary>
        private const int StatFormatVersion = 3;

        private readonly ICacheStore _cache;         // optional
        private readonly IProvenanceLedger _ledger;  // optional

        public AnalysisService(ILdAnalysisEngine engine, IResultRepository results)
            : this(engine, results, null, null) { }

        public AnalysisService(ILdAnalysisEngine engine, IResultRepository results,
            ICacheStore cache, IProvenanceLedger ledger)
        {
            _engine = engine ?? throw new ArgumentNullException(nameof(engine));
            _results = results ?? throw new ArgumentNullException(nameof(results));
            _cache = cache;
            _ledger = ledger;
        }

        public async Task<AnalysisResult> RunAsync(
            AnalysisRequest request,
            IProgress<AnalysisProgress> progress,
            CancellationToken cancellationToken)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));

            bool ehhMode = request.Parameters.OutType == LdOutputType.Ehh;
            string statPath = OutputPaths.ResultFor(request.OutputPrefix, ehhMode);

            // First of all: a run must never replace a file it was given to read. An output prefix
            // that names the VCF (or its sample list) would otherwise overwrite it with the result.
            string conflict = OutputConflict(request, statPath);
            if (conflict != null)
                return new AnalysisResult { Success = false, Message = conflict };

            // Validate the anchor up front: the engine can only check it after streaming the
            // whole VCF, which on a multi-GB file means a minute of work before a typo surfaces.
            if (ehhMode && !IsWellFormedSite(request.Parameters.EhhSite))
                return new AnalysisResult
                {
                    Success = false,
                    Message = "EHH needs an anchor site written as chr:pos, e.g. 22:17000000 " +
                              "(got " + (string.IsNullOrWhiteSpace(request.Parameters.EhhSite)
                                  ? "no value" : "\"" + request.Parameters.EhhSite + "\"") + ").",
                };

            // EHH follows haplotypes, so it cannot run on a VCF read as unphased. Refuse it here,
            // before the whole input is streamed, like a malformed anchor above.
            if (ehhMode && request.Parameters.IgnorePhase)
                return new AnalysisResult
                {
                    Success = false,
                    Message = "EHH needs phased haplotypes, so it cannot be combined with ignoring the VCF's phase.",
                };

            if (ehhMode && request.Parameters.Maf < EhhMinMaf)
            {
                // The original raises MAF to 0.05 for EHH; rare alleles make haplotype
                // homozygosity meaningless. Copy the parameters so the caller's object is untouched.
                request = new AnalysisRequest
                {
                    VcfPaths = request.VcfPaths,
                    SampleListPath = request.SampleListPath,
                    OutputPrefix = request.OutputPrefix,
                    BypassCache = request.BypassCache,
                    Parameters = request.Parameters.Clone(),
                };
                request.Parameters.Maf = EhhMinMaf;
                progress?.Report(new AnalysisProgress
                {
                    Fraction = 0.0,
                    // A note, not a warning: it is the documented EHH rule and happens on every
                    // EHH run left at the default MAF, so it must not turn the GUI's light amber
                    // each time and teach users to ignore real warnings.
                    Stage = $"note: EHH requires MAF >= {EhhMinMaf.ToString(CultureInfo.InvariantCulture)}; using that instead",
                });
            }

            int maxDistBp = request.Parameters.MaxDistKb * 1000;
            string inputs = DescribeInputs(request);
            // The key is built from the settings the engine will actually apply, so an unphased
            // option that cannot change this input's numbers (phased VCF, EHH) never forces a
            // recomputation. Reading the first record is I/O, so it stays off the caller's thread.
            EffectiveSettings settings = await ResolveAsync(request, cancellationToken).ConfigureAwait(false);
            // Two different parameter strings on purpose: the key must stay MaxDist-free so a wider
            // cached result can be truncated and reused, while the ledger has to be able to tell a
            // 100 kb run from a 300 kb one. Never derive the key from the ledger string.
            string keyParams = DescribeParams(settings.Parameters);
            string ledgerParams = DescribeLedgerParams(settings.Parameters);
            string key = CacheKey.Sha256Hex("v" + StatFormatVersion + "||" + inputs + "||" + keyParams);

            var sw = Stopwatch.StartNew();
            AnalysisResult result;

            // The CAIR store is LD-specific: a hit at a larger MaxDist is served by truncating
            // the stat file by distance, which is meaningless for an .ehh.gz. EHH runs are cheap
            // (one small region), so they always recompute.
            if (!ehhMode && _cache != null && !request.BypassCache &&
                TryServe(key, maxDistBp, statPath, progress, out IReadOnlyList<string> notices))
            {
                // The same warnings as a computed run: the request's own (an option without effect
                // here) and those the run that made this result reported about the same input.
                if (settings.IgnoredOptionWarning != null)
                    progress?.Report(new AnalysisProgress { Fraction = 0.0, Stage = settings.IgnoredOptionWarning });
                foreach (var notice in notices)
                    progress?.Report(new AnalysisProgress { Fraction = 0.05, Stage = notice });
                // Spell out exactly which inputs this hit is bound to, so a hit after
                // switching sample lists is auditable rather than looking like a stale reuse.
                string vcfName = request.VcfPaths.Count > 0 ? Path.GetFileName(request.VcfPaths[0]) : "?";
                string subpop = string.IsNullOrEmpty(request.SampleListPath)
                    ? "all samples"
                    : "SubPop=" + Path.GetFileName(request.SampleListPath) +
                      " (" + CountSampleTokens(request.SampleListPath) + " samples)";
                progress?.Report(new AnalysisProgress { Fraction = 1.0, Stage = "cache hit (no recompute)" });
                result = new AnalysisResult
                {
                    Success = true,
                    StatFilePath = statPath,
                    FromCache = true,
                    // The key fixes the estimator, so the replayed file came from this one; saying
                    // so keeps the rewritten sidecar as specific as the one written at compute time.
                    LdEstimator = settings.LdEstimator,
                    Message = $"cache hit [{vcfName}, {subpop}, MaxDist={request.Parameters.MaxDistKb}kb] -> " + statPath,
                };
                // TryServe REWROTE the .stat.gz (copied, or truncated when the cached entry was
                // computed at a larger MaxDist), so the sidecar beside it has to be rewritten too.
                // Left alone it would keep describing the earlier run and claim a maxDistKb the
                // file no longer has — the record must always describe the file it sits next to.
                WriteProvenance(request, result, progress);
            }
            else
            {
                result = await _engine.RunAsync(request, progress, cancellationToken).ConfigureAwait(false);
                if (result.Success)
                {
                    WriteProvenance(request, result, progress);
                    if (!ehhMode && _cache != null)
                    {
                        // The cache only saves time: failing to store a result must not turn a
                        // finished analysis into a failed one.
                        try { _cache.Put(key, result.StatFilePath, maxDistBp, result.InputNotices); }
                        catch (Exception ex) when (IsFileSystemError(ex))
                        {
                            Warn(progress, "result not added to the cache: " + ex.Message);
                        }
                    }
                }
            }
            sw.Stop();

            if (result.Success && _ledger != null)
            {
                try
                {
                    _ledger.Append(new ProvenanceRecord
                    {
                        TimestampUtc = DateTime.UtcNow.ToString("o"),
                        ToolVersion = PopLD.Domain.ToolInfo.Version,
                        CacheKey = key,
                        Inputs = inputs,
                        Parameters = ledgerParams,
                        OutputPath = result.StatFilePath,
                        PairsEvaluated = result.PairsEvaluated,
                        DegreeOfParallelism = result.DegreeOfParallelism,
                        ElapsedSeconds = sw.Elapsed.TotalSeconds,
                        CacheHit = result.FromCache,
                    });
                }
                catch (Exception ex) when (IsFileSystemError(ex))
                {
                    // The result and its sidecar are already written; the shared ledger being
                    // busy or read-only is reported, not turned into a failed run.
                    Warn(progress, "run not recorded in the provenance ledger: " + ex.Message);
                }
            }
            return result;
        }

        /// <summary>
        /// A cache lookup. The cache only saves time, so a cache that cannot be read (a file held
        /// by a virus scanner, a lock held by another account) is a miss and a warning, never the
        /// reason a run fails: the analysis is then simply computed. An output file that cannot
        /// be written is a different matter — computing would end in the same error, only later —
        /// so that failure is the run's and is not caught here.
        /// </summary>
        private bool TryServe(string key, int maxDistBp, string statPath, IProgress<AnalysisProgress> progress,
            out IReadOnlyList<string> notices)
        {
            notices = new string[0];
            try
            {
                if (!_cache.TryServe(key, maxDistBp, statPath, out var stored)) return false;
                if (stored != null) notices = stored;
                return true;
            }
            catch (CacheUnavailableException ex)
            {
                Warn(progress, "cache not used: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Writes the sidecar for a result just produced. If that fails, the sidecar from an
        /// earlier run must not stay behind describing a file it no longer matches, so it is
        /// removed and the failure reported.
        /// </summary>
        private void WriteProvenance(AnalysisRequest request, AnalysisResult result, IProgress<AnalysisProgress> progress)
        {
            try
            {
                _results.WriteProvenance(request, result);
            }
            catch (Exception ex) when (IsFileSystemError(ex))
            {
                if (!string.IsNullOrEmpty(result.StatFilePath))
                    AtomicFile.TryDelete(OutputPaths.ProvenanceFor(result.StatFilePath));
                Warn(progress, "provenance record (.provenance.txt) not written: " + ex.Message);
            }
        }

        /// <summary>
        /// The message refusing a run whose result file or provenance record would be one of its
        /// inputs (the same file, however the path is written), or null.
        /// </summary>
        public static string OutputConflict(AnalysisRequest request, string resultPath)
        {
            var inputs = new List<string>(request.VcfPaths);
            if (!string.IsNullOrEmpty(request.SampleListPath)) inputs.Add(request.SampleListPath);
            var hit = FileIdentity.FindConflict(new[] { resultPath, OutputPaths.ProvenanceFor(resultPath) }, inputs);
            return hit == null ? null
                : "The output " + hit.Item1 + " is the input " + hit.Item2 +
                  "; writing it would destroy the input. Choose another output prefix.";
        }

        private static bool IsFileSystemError(Exception ex)
            => ex is IOException || ex is UnauthorizedAccessException;

        private static void Warn(IProgress<AnalysisProgress> progress, string text)
            => progress?.Report(new AnalysisProgress { Fraction = 1.0, Stage = "warning: " + text });

        /// <summary>
        /// The settings the engine will apply to <paramref name="request"/> (see
        /// <see cref="ILdAnalysisEngine.Resolve"/>), on a worker thread: it reads the input's first
        /// record, which must not block a UI thread on a large or remote VCF.
        /// </summary>
        public Task<EffectiveSettings> ResolveAsync(AnalysisRequest request, CancellationToken cancellationToken)
        {
            if (request == null) throw new ArgumentNullException(nameof(request));
            return Task.Run(() => _engine.Resolve(request), cancellationToken);
        }

        /// <summary>"chr:pos" as <see cref="SiteParser"/> reads it — the same rule the CLI, the GUI
        /// and the engine apply.</summary>
        private static bool IsWellFormedSite(string text) => SiteParser.TryParse(text, out _, out _);

        private static string DescribeInputs(AnalysisRequest request)
        {
            var sb = new StringBuilder();
            foreach (var v in request.VcfPaths)
            {
                if (sb.Length > 0) sb.Append(';');
                sb.Append(Identity(v));
            }
            if (!string.IsNullOrEmpty(request.SampleListPath))
                sb.Append(";subpop:").Append(SampleListIdentity(request.SampleListPath));
            return sb.ToString();
        }

        /// <summary>
        /// Content-based identity of a sample list: the canonical sample SET, hashed. It is read
        /// by <see cref="SampleListFile"/>, the very reader the engine selects samples with, so the
        /// key always names the samples that were analysed (a byte-order mark, gzip, line endings
        /// or comment lines cannot make the two disagree). Two different files with the same
        /// samples are the same analysis (cache may serve); the same file edited in place is a
        /// different analysis (must recompute). Falls back to path+size+mtime if the file cannot
        /// be read (or is absurdly large).
        /// </summary>
        private static string SampleListIdentity(string path)
        {
            try
            {
                if (new FileInfo(path).Length > (32L << 20)) return Identity(path);
                var tokens = new SortedSet<string>(SampleListFile.Load(path), StringComparer.Ordinal);
                return "sha256:" + CacheKey.Sha256Hex(string.Join("\n", tokens)) +
                       ";n=" + tokens.Count.ToString(CultureInfo.InvariantCulture);
            }
            catch { return Identity(path); }
        }

        /// <summary>Distinct sample-name count of a list ("?" if unreadable).</summary>
        private static string CountSampleTokens(string path)
        {
            try { return SampleListFile.Load(path).Count.ToString(CultureInfo.InvariantCulture); }
            catch { return "?"; }
        }

        /// <summary>
        /// A VCF's identity in the cache key: full path, size, modification time and — where the
        /// file system keeps one (NTFS) — its change time. The content is not hashed: that would
        /// cost a full read of a multi-GB file on every lookup, the very work a hit avoids. The
        /// change time closes the gap the other three leave: it is set on every write, also when a
        /// tool (a copy that keeps timestamps, a sync client) resets the modification time
        /// afterwards. A file system without it (FAT/exFAT, some network shares) falls back to the
        /// first three; there, and against a tool that rewrites the change time itself, a forced
        /// recomputation (--no-cache, or the GUI's Reset) is the remedy.
        /// </summary>
        private static string Identity(string path)
        {
            try
            {
                var fi = new FileInfo(path);
                string change = FileIdentity.ChangeStamp(fi.FullName);
                return fi.FullName + "|" + fi.Length.ToString(CultureInfo.InvariantCulture) + "|" +
                       fi.LastWriteTimeUtc.Ticks.ToString(CultureInfo.InvariantCulture) +
                       (change != null ? "|ct" + change : "");
            }
            catch { return path; }
        }

        /// <summary>
        /// The CACHE KEY's parameter half. Do not change its inputs or format: every result
        /// already cached on a user's machine is filed under a key built from this string.
        /// </summary>
        private static string DescribeParams(AnalysisParameters p)
        {
            var inv = CultureInfo.InvariantCulture;
            // Fields that change the CONTENT of a stat-file row, plus deliberate omissions:
            //  * MaxDist is left out even though it does change the file — the original writes one
            //    row per bp distance from 1 to MaxDist (LD_Decay.cpp:279 converts kb->bp,
            //    FileDeal.h:1341/1352 loop 1..InInt), so a wider result is a strict SUPERSET of a
            //    narrower one and the cache can serve the narrow request by truncating rather than
            //    recomputing. It is not "irrelevant" — see DescribeLedgerParams, which records it.
            //  * Plot params (bin/break/maxX) never reach the .stat.gz at all; binning happens in
            //    the plotting step (Plot_OnePop.pl), downstream of the file.
            // The anchor site is part of the key only in EHH mode; otherwise a value left in the
            // box would change the key without changing the result, costing a needless recompute.
            // The unphased-LD options are appended only when they differ from the default.
            // Thresholds are written round-trip ("R"): the default ToString keeps only 15 digits
            // on .NET Framework, so two different thresholds could share a key there.
            return "maf=" + p.Maf.ToString("R", inv) + ";het=" + p.Het.ToString("R", inv) +
                   ";miss=" + p.Miss.ToString("R", inv) + ";outType=" + (int)p.OutType +
                   ";ehh=" + (p.OutType == LdOutputType.Ehh ? (p.EhhSite ?? "") : "") +
                   (p.UnphasedEstimator == UnphasedLdEstimator.MaximumLikelihood ? ";unphased=ml" : "") +
                   (p.IgnorePhase ? ";ignorePhase=1" : "");
        }

        /// <summary>
        /// The LEDGER's parameter string: the cache-key params plus MaxDist. The ledger identifies
        /// a run rather than deduplicating it, so it must record the distance range the output was
        /// actually written at — without it a 100 kb and a 300 kb run are indistinguishable in the
        /// log even though their stat files hold different row sets (FileDeal.h:1341).
        /// </summary>
        private static string DescribeLedgerParams(AnalysisParameters p)
        {
            return DescribeParams(p) + ";maxDistKb=" +
                   p.MaxDistKb.ToString(CultureInfo.InvariantCulture);
        }
    }
}
