using System;
using System.IO;
using System.Threading;
using PopLD.Domain.Services;

namespace PopLD.Infrastructure
{
    /// <summary>
    /// The cross-process mutex the cache and the provenance ledger take, since the GUI and the
    /// command line share both. What a busy or unopenable lock means is the caller's policy.
    /// </summary>
    internal static class NamedLock
    {
        internal enum Result { Ran, Busy, Unopenable }

        /// <summary>
        /// <c>Local\PopLDdecay.&lt;kind&gt;.</c> plus the first 16 hex digits of the SHA-256 of the
        /// upper-cased full path, so every process using the same store takes the same mutex.
        /// </summary>
        internal static string NameFor(string kind, string path)
            => @"Local\PopLDdecay." + kind + "." + CacheKey.Sha256Hex(Path.GetFullPath(path).ToUpperInvariant()).Substring(0, 16);

        /// <summary>
        /// Runs <paramref name="body"/> holding the mutex, waiting at most <paramref name="timeout"/>
        /// for another holder; one that died holding it counts as gone. Busy: the wait ran out.
        /// Unopenable: the name belongs to another account's mutex (an elevated and a normal instance
        /// at once) or to another kind of object, and <paramref name="error"/> says which. The body
        /// has not run in either case; its own exceptions pass through after the mutex is released.
        /// </summary>
        internal static Result TryRun(string name, TimeSpan timeout, Action body, out Exception error)
        {
            error = null;
            Mutex created;
            try { created = new Mutex(false, name); }
            catch (Exception ex) when (ex is UnauthorizedAccessException || ex is WaitHandleCannotBeOpenedException)
            {
                error = ex;
                return Result.Unopenable;
            }
            using (var mutex = created)
            {
                bool owned;
                try { owned = mutex.WaitOne(timeout); }
                catch (AbandonedMutexException) { owned = true; }
                if (!owned) return Result.Busy;
                try { body(); }
                finally { mutex.ReleaseMutex(); }
                return Result.Ran;
            }
        }
    }
}
