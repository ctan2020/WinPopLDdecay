using System.Globalization;

namespace PopLD.Domain.Services
{
    /// <summary>
    /// The one parser of an EHH anchor "chr:pos", shared by the command line, the GUI, the
    /// service and the engine, so a value is accepted or refused the same way everywhere.
    /// </summary>
    public static class SiteParser
    {
        /// <summary>
        /// Splits at the LAST colon, so a chromosome name that contains colons (some contig names
        /// do) is kept whole. The chromosome must be non-empty and the position a plain
        /// non-negative integer (digits only — no sign, no thousands separators, no exponent).
        /// Surrounding whitespace is ignored.
        /// </summary>
        public static bool TryParse(string text, out string chrom, out long pos)
        {
            chrom = null; pos = 0;
            if (string.IsNullOrWhiteSpace(text)) return false;
            text = text.Trim();
            int colon = text.LastIndexOf(':');
            if (colon <= 0 || colon == text.Length - 1) return false;
            string c = text.Substring(0, colon).Trim();
            string p = text.Substring(colon + 1).Trim();
            if (c.Length == 0) return false;
            if (!long.TryParse(p, NumberStyles.None, CultureInfo.InvariantCulture, out long v)) return false;
            chrom = c;
            pos = v;
            return true;
        }
    }
}
