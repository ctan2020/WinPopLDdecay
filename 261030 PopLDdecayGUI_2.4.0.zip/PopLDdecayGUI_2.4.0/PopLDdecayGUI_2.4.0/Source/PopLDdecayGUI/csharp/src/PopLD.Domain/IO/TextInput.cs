using System;
using System.IO;
using System.Text;

namespace PopLD.Domain.IO
{
    /// <summary>
    /// Opens every text input the tool reads — VCF, sample list, result files — the way the
    /// original opens them through igzstream (zlib's gzopen/gzread): compression is recognised
    /// from the first bytes, not from the file name, so a gzip file is read wherever it is named
    /// and a plain file is read even when it is called ".gz". BGZF, single-member and
    /// multi-member gzip are all read to the end, every block or member checked against its
    /// trailer; a compressed file that stops partway is an error, not a shorter input.
    /// <para>Text is decoded as Latin-1, which maps every byte to one character and back, so
    /// names compare byte for byte as in the original (an ASCII decoder would turn every
    /// non-ASCII byte into '?', making different names equal). A leading UTF-8 byte-order mark,
    /// which Windows editors often write, is skipped; the original would read it as part of the
    /// first line.</para>
    /// </summary>
    public static class TextInput
    {
        /// <summary>ISO-8859-1: one character per byte, all 256 values round-trip.</summary>
        public static readonly Encoding Latin1 = Encoding.GetEncoding(28591);

        /// <summary>Opens <paramref name="path"/> as text, decompressing it if its content is gzip.</summary>
        public static StreamReader OpenText(string path, int bufferSize = 1 << 20)
        {
            // A small file buffer whatever the reader's: the reader's large reads go past it
            // straight to the file, and the gzip reader seeks once per member, which on .NET
            // Framework copies whatever the buffer still holds (with 1 MiB, a file of many small
            // members read at well under 1 MB/s).
            var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 1 << 16);
            try
            {
                Stream s = SkipUtf8Bom(Decompressed(fs));
                return new StreamReader(s, Latin1, false, bufferSize);
            }
            catch
            {
                fs.Dispose();
                throw;
            }
        }

        /// <summary>The decompressed content of a seekable stream positioned at its start.</summary>
        public static Stream Decompressed(Stream seekable)
        {
            var head = new byte[18];
            int n = ReadOnlyStream.ReadUpTo(seekable, head, 0, head.Length);
            seekable.Position = 0;
            if (n < 2 || head[0] != 0x1f || head[1] != 0x8b) return seekable;
            if (BgzfReadStream.LooksLikeBgzf(head, n)) return new BgzfReadStream(seekable);
            return new GzipMembersStream(seekable);
        }

        private static Stream SkipUtf8Bom(Stream s)
        {
            var head = new byte[3];
            int n = ReadOnlyStream.ReadUpTo(s, head, 0, 3);
            if (n == 3 && head[0] == 0xEF && head[1] == 0xBB && head[2] == 0xBF) return s;
            return n == 0 ? s : new PrefixedStream(head, n, s);
        }

        /// <summary>Replays a few bytes already read from <c>inner</c>, then continues with it.</summary>
        private sealed class PrefixedStream : ReadOnlyStream
        {
            private readonly byte[] _prefix;
            private readonly int _prefixLen;
            private int _prefixPos;
            private readonly Stream _inner;

            public PrefixedStream(byte[] prefix, int len, Stream inner)
            {
                _prefix = prefix; _prefixLen = len; _inner = inner;
            }

            public override int Read(byte[] buffer, int offset, int count)
            {
                if (_prefixPos < _prefixLen)
                {
                    int n = Math.Min(count, _prefixLen - _prefixPos);
                    Buffer.BlockCopy(_prefix, _prefixPos, buffer, offset, n);
                    _prefixPos += n;
                    return n;
                }
                return _inner.Read(buffer, offset, count);
            }

            protected override void Dispose(bool disposing)
            {
                if (disposing) _inner.Dispose();
                base.Dispose(disposing);
            }
        }
    }
}
