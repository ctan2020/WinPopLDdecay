using System;

namespace PopLD.Domain.Services
{
    /// <summary>Shared output-path conventions so the engine, service and cache agree.</summary>
    public static class OutputPaths
    {
        /// <summary>Returns the ".stat.gz" path for a prefix, stripping a trailing .gz/.stat.</summary>
        public static string StatFor(string prefix)
        {
            if (string.IsNullOrEmpty(prefix)) prefix = "out";
            if (prefix.EndsWith(".gz", StringComparison.OrdinalIgnoreCase))
                prefix = prefix.Substring(0, prefix.Length - 3);
            if (prefix.EndsWith(".stat", StringComparison.OrdinalIgnoreCase))
                prefix = prefix.Substring(0, prefix.Length - 5);
            return prefix + ".stat.gz";
        }

        /// <summary>Returns the ".ehh.gz" path for a prefix (EHH mode writes this instead of the stat file).</summary>
        public static string EhhFor(string prefix)
        {
            string stat = StatFor(prefix);
            return stat.Substring(0, stat.Length - ".stat.gz".Length) + ".ehh.gz";
        }

        /// <summary>The result file a run writes: <see cref="EhhFor"/> for EHH, else <see cref="StatFor"/>.</summary>
        public static string ResultFor(string prefix, bool ehh) => ehh ? EhhFor(prefix) : StatFor(prefix);

        /// <summary>The provenance record written beside a result file.</summary>
        public static string ProvenanceFor(string resultPath) => resultPath + ".provenance.txt";
    }
}
