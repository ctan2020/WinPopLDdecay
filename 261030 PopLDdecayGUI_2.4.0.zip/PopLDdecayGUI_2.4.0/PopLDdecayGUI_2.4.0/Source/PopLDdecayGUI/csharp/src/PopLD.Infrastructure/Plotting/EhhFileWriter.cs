using System;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using PopLD.Domain.IO;
using PopLD.Domain.Services;

namespace PopLD.Infrastructure.Plotting
{
    /// <summary>
    /// Writes an EHH curve back out in the reference tool's own <c>*.ehh</c> layout —
    /// <c>#Chr / Site / Dist / EHH_all / EHH_0 / EHH_1</c>, distances in bp — so an exported
    /// EHH plot carries the same file a Linux PopLDdecay run would produce. The generic
    /// <see cref="PlotDataWriter"/> dump keeps only distance-in-kb and one statistic, which
    /// loses Site, EHH_0 and EHH_1.
    /// </summary>
    public static class EhhFileWriter
    {
        /// <summary>True when this series carries the full EHH rows needed for the format.</summary>
        public static bool CanWrite(DecayPoints s) => s != null && s.EhhRows != null && s.EhhRows.Length > 0;

        public static void Write(string path, DecayPoints series)
        {
            if (!CanWrite(series)) throw new InvalidOperationException("series carries no EHH rows");

            // Latin-1, as the rows were read: a chromosome name comes back byte for byte.
            AtomicFile.Write(path, fs => WriteBody(fs, series.EhhRows));
        }

        private static void WriteBody(Stream fs, EhhRow[] rows)
        {
            using (var gz = new GZipStream(fs, CompressionLevel.Optimal, true))
            using (var w = new StreamWriter(gz, TextInput.Latin1, 1 << 16))
            {
                ResultFormat.WriteEhhHeader(w, rows.Length);
                foreach (var r in rows)
                    ResultFormat.WriteEhhRow(w, r.Chrom, r.Site, r.Dist, r.All, r.Allele0, r.Allele1);
            }
        }
    }
}
