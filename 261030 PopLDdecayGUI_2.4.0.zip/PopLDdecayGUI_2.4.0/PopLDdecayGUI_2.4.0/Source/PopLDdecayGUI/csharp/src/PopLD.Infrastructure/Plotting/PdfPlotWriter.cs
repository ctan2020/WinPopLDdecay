using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace PopLD.Infrastructure.Plotting
{
    /// <summary>
    /// True vector-PDF export of the LD-decay plot: axes, gridlines, tick labels, series
    /// polylines and the legend are written as PDF path/text operators (not a rasterized
    /// bitmap), so the figure stays sharp at any zoom — suitable for journal submission.
    /// Uses the standard Helvetica base-14 font (WinAnsi), so no font embedding and no
    /// third-party library is needed. Layout comes from <see cref="PlotLayout"/>, the same
    /// geometry the on-screen view renders, so the PDF matches what the user sees.
    /// </summary>
    public static class PdfPlotWriter
    {
        private const double FontPx = 12.0;        // label font size in layout (pixel) units
        private const double LineHeightPx = 14.0;  // Helvetica line height at 12px
        private const double AscentPx = 9.0;       // top-of-line -> baseline offset
        private const double Scale = 0.75;         // px -> pt (96 dpi -> 72 dpi)

        public static void Write(string path, double widthPx, double heightPx, IReadOnlyList<DecayPoints> series)
        {
            var layout = PlotLayout.Compute(widthPx, heightPx, series,
                s => HelveticaWidth(s, FontPx), LineHeightPx);
            var inv = CultureInfo.InvariantCulture;
            var c = new StringBuilder(1 << 16);

            // Global px->pt scale; all coordinates below stay in layout pixels (y flipped).
            c.Append(Scale.ToString("0.###", inv)).Append(" 0 0 ")
             .Append(Scale.ToString("0.###", inv)).Append(" 0 0 cm\n");

            // white background
            c.Append("1 1 1 rg 0 0 ").Append(F(widthPx)).Append(' ').Append(F(heightPx)).Append(" re f\n");

            // gridlines
            c.Append("0.886 0.886 0.910 RG 1 w\n");
            foreach (var g in layout.GridLines) Line(c, g, heightPx);

            // axis lines
            c.Append("0.533 0.533 0.565 RG 1 w\n");
            foreach (var a in layout.AxisLines) Line(c, a, heightPx);

            // tick + axis labels (dark gray, same tone as the screen view)
            c.Append("0.267 0.267 0.267 rg\n");
            foreach (var t in layout.TickLabels) Text(c, t, heightPx);
            Text(c, layout.XAxisLabel, heightPx);
            Text(c, layout.YAxisLabel, heightPx);
            Text(c, layout.RightAxisLabel, heightPx);

            // series polylines
            foreach (var s in layout.Series)
            {
                Rgb(c, PlotPalette.Colors[s.ColorIndex]).Append(" RG 2 w 1 J 1 j\n");
                for (int i = 0; i < s.Xs.Length; i++)
                {
                    c.Append(F(s.Xs[i])).Append(' ').Append(F(heightPx - s.Ys[i]))
                     .Append(i == 0 ? " m\n" : " l\n");
                }
                if (s.Xs.Length > 0) c.Append("S\n");
            }

            // legend: translucent white rounded box, border, swatches, labels
            if (layout.HasLegend)
            {
                var b = layout.LegendBox;
                c.Append("/GSt gs\n");                       // ca 0.88, like the screen view
                c.Append("1 1 1 rg 0.867 0.867 0.890 RG 1 w\n");
                RoundedRect(c, b, 6, heightPx);
                c.Append("B\n");                             // fill + stroke
                c.Append("/GSo gs\n");                       // back to opaque
                foreach (var item in layout.LegendItems)
                {
                    Rgb(c, PlotPalette.Colors[item.ColorIndex]).Append(" rg ");
                    var s = item.Swatch;
                    c.Append(F(s.X)).Append(' ').Append(F(heightPx - s.Y - s.H)).Append(' ')
                     .Append(F(s.W)).Append(' ').Append(F(s.H)).Append(" re f\n");
                    c.Append("0.267 0.267 0.267 rg\n");
                    Text(c, item.Label, heightPx);
                }
            }

            WritePdfFile(path, widthPx * Scale, heightPx * Scale, EncodeWinAnsi(c.ToString()));
        }

        // ---- content-stream helpers (layout px, y flipped to PDF's bottom-left origin) ----

        private static string F(double v) => v.ToString("0.##", CultureInfo.InvariantCulture);

        private static void Line(StringBuilder c, PlotLine l, double h)
        {
            c.Append(F(l.X1)).Append(' ').Append(F(h - l.Y1)).Append(" m ")
             .Append(F(l.X2)).Append(' ').Append(F(h - l.Y2)).Append(" l S\n");
        }

        private static void Text(StringBuilder c, PlotText t, double h)
        {
            if (t == null || string.IsNullOrEmpty(t.Text)) return;
            double baseline = h - t.Y - AscentPx;   // top-left anchor -> first baseline
            c.Append("BT /F1 ").Append(F(FontPx)).Append(" Tf 1 0 0 1 ")
             .Append(F(t.X)).Append(' ').Append(F(baseline)).Append(" Tm (")
             .Append(EscapeText(t.Text)).Append(") Tj ET\n");
        }

        private static void RoundedRect(StringBuilder c, PlotRect r, double rad, double h)
        {
            // Rounded rectangle via Bézier corners (kappa approximation), y flipped.
            double k = 0.5523 * rad;
            double x0 = r.X, x1 = r.Right, yTop = h - r.Y, yBot = h - r.Bottom;
            c.Append(F(x0 + rad)).Append(' ').Append(F(yTop)).Append(" m ");
            c.Append(F(x1 - rad)).Append(' ').Append(F(yTop)).Append(" l ");
            Curve(c, x1 - rad + k, yTop, x1, yTop - rad + k, x1, yTop - rad);
            c.Append(F(x1)).Append(' ').Append(F(yBot + rad)).Append(" l ");
            Curve(c, x1, yBot + rad - k, x1 - rad + k, yBot, x1 - rad, yBot);
            c.Append(F(x0 + rad)).Append(' ').Append(F(yBot)).Append(" l ");
            Curve(c, x0 + rad - k, yBot, x0, yBot + rad - k, x0, yBot + rad);
            c.Append(F(x0)).Append(' ').Append(F(yTop - rad)).Append(" l ");
            Curve(c, x0, yTop - rad + k, x0 + rad - k, yTop, x0 + rad, yTop);
            c.Append("h\n");
        }

        private static void Curve(StringBuilder c, double c1x, double c1y, double c2x, double c2y, double x, double y)
        {
            c.Append(F(c1x)).Append(' ').Append(F(c1y)).Append(' ')
             .Append(F(c2x)).Append(' ').Append(F(c2y)).Append(' ')
             .Append(F(x)).Append(' ').Append(F(y)).Append(" c ");
        }

        private static string EscapeText(string s)
        {
            var sb = new StringBuilder(s.Length + 4);
            foreach (char ch in s)
            {
                if (ch == '(' || ch == ')' || ch == '\\') sb.Append('\\');
                sb.Append(ch);
            }
            return sb.ToString();
        }

        /// <summary>
        /// Maps the content string to WinAnsi (CP1252) bytes. Operators are pure ASCII; text
        /// may contain ² (0xB2 in both Latin-1 and CP1252) plus a few CP1252-only characters
        /// that are remapped explicitly. Anything unencodable becomes '?'.
        /// </summary>
        private static byte[] EncodeWinAnsi(string s)
        {
            var bytes = new byte[s.Length];
            for (int i = 0; i < s.Length; i++)
                bytes[i] = TryWinAnsi(s[i], out byte b) ? b : (byte)'?';
            return bytes;
        }

        /// <summary>The WinAnsi byte of <paramref name="ch"/>: Latin-1 as is, plus the five typographic marks file names commonly carry.</summary>
        private static bool TryWinAnsi(char ch, out byte b)
        {
            switch (ch)
            {
                case '…': b = 0x85; return true;
                case '‘': b = 0x91; return true;   // left single quote
                case '’': b = 0x92; return true;   // right single quote
                case '–': b = 0x96; return true;   // en dash
                case '—': b = 0x97; return true;   // em dash
            }
            b = (byte)ch;
            return ch <= 0xFF;
        }

        /// <summary>Appends a palette colour as the three 0..1 components PDF colour operators take.</summary>
        private static StringBuilder Rgb(StringBuilder c, byte[] col)
            => c.Append(F(col[0] / 255.0)).Append(' ').Append(F(col[1] / 255.0)).Append(' ').Append(F(col[2] / 255.0));

        /// <summary>
        /// True when every character of <paramref name="s"/> survives the WinAnsi mapping —
        /// i.e. the PDF legend/labels will show it as-is. CJK and other non-Latin characters
        /// return false (they would degrade to '?'), letting callers warn the user up front.
        /// </summary>
        public static bool CanEncode(string s)
        {
            if (string.IsNullOrEmpty(s)) return true;
            foreach (char ch in s)
                if (!TryWinAnsi(ch, out _)) return false;
            return true;
        }

        // ---- PDF file assembly (objects + xref) ----

        // Written atomically, like every other output: a failed export leaves the previous file,
        // never a half-written PDF.
        private static void WritePdfFile(string path, double widthPt, double heightPt, byte[] content)
            => PopLD.Domain.IO.AtomicFile.Write(path, fs => WritePdfBody(fs, widthPt, heightPt, content));

        private static void WritePdfBody(Stream fs, double widthPt, double heightPt, byte[] content)
        {
            var inv = CultureInfo.InvariantCulture;
            var off = new long[8];
            void W(string s)
            {
                // Latin-1 byte write: everything here is ASCII except the binary-marker line.
                var b = new byte[s.Length];
                for (int i = 0; i < s.Length; i++) b[i] = s[i] <= 0xFF ? (byte)s[i] : (byte)'?';
                fs.Write(b, 0, b.Length);
            }

            W("%PDF-1.4\n%âãÏÓ\n");
            off[1] = fs.Position; W("1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
            off[2] = fs.Position; W("2 0 obj\n<< /Type /Pages /Kids [3 0 R] /Count 1 >>\nendobj\n");
            off[3] = fs.Position;
            W("3 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 " +
              widthPt.ToString("0.##", inv) + " " + heightPt.ToString("0.##", inv) + "]" +
              " /Resources << /Font << /F1 5 0 R >> /ExtGState << /GSo 6 0 R /GSt 7 0 R >> >>" +
              " /Contents 4 0 R >>\nendobj\n");
            off[4] = fs.Position;
            W("4 0 obj\n<< /Length " + content.Length.ToString(inv) + " >>\nstream\n");
            fs.Write(content, 0, content.Length);
            W("\nendstream\nendobj\n");
            off[5] = fs.Position;
            W("5 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>\nendobj\n");
            off[6] = fs.Position; W("6 0 obj\n<< /Type /ExtGState /ca 1 >>\nendobj\n");
            off[7] = fs.Position; W("7 0 obj\n<< /Type /ExtGState /ca 0.88 >>\nendobj\n");

            long xref = fs.Position;
            W("xref\n0 8\n0000000000 65535 f \n");
            for (int i = 1; i <= 7; i++) W(off[i].ToString("D10", inv) + " 00000 n \n");
            W("trailer\n<< /Size 8 /Root 1 0 R >>\nstartxref\n" + xref.ToString(inv) + "\n%%EOF\n");
        }

        // ---- Helvetica metrics (standard AFM widths, per-mille of font size) ----

        /// <summary>Width of <paramref name="s"/> in the same units as <paramref name="size"/>.</summary>
        public static double HelveticaWidth(string s, double size)
        {
            if (string.IsNullOrEmpty(s)) return 0;
            int total = 0;
            foreach (char ch in s) total += CharWidth(ch);
            return total * size / 1000.0;
        }

        private static int CharWidth(char ch)
        {
            if (ch >= 32 && ch < 32 + Widths.Length) return Widths[ch - 32];
            switch (ch)
            {
                case '²': return 333;
                case '…': return 1000;
                case '’': case '‘': return 222;
                case '–': return 556;
                case '—': return 1000;
                case '°': return 400;
                default: return 556; // average fallback
            }
        }

        // ASCII 32..126 from the standard Helvetica AFM.
        private static readonly short[] Widths =
        {
            278, 278, 355, 556, 556, 889, 667, 191, 333, 333, 389, 584, 278, 333, 278, 278, // sp..'/'
            556, 556, 556, 556, 556, 556, 556, 556, 556, 556, 278, 278, 584, 584, 584, 556, // 0..'?'
            1015, 667, 667, 722, 722, 667, 611, 778, 722, 278, 500, 667, 556, 833, 722, 778, // @..O
            667, 778, 722, 667, 611, 722, 667, 944, 667, 667, 611, 278, 278, 278, 469, 556, // P.._
            333, 556, 556, 500, 556, 556, 278, 556, 556, 222, 222, 500, 222, 833, 556, 556, // `..o
            556, 556, 333, 500, 278, 556, 500, 722, 500, 500, 500, 334, 260, 334, 584,      // p..~
        };
    }
}
