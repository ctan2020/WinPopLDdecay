using System;
using System.Diagnostics;

namespace PopLD.Engine.Hape
{
    /// <summary>
    /// Hardware-Adaptive Parallel Engine scheduler. Chooses the degree of parallelism at run
    /// time from the detected core count and the memory each worker needs, so the same binary
    /// saturates a 4-core laptop and a 24-core workstation without user tuning, while never
    /// over-committing RAM. This adaptivity is a core contribution of the software-design work.
    /// </summary>
    public sealed class HapeScheduler
    {
        /// <summary>Bytes each parallel worker needs for its thread-local accumulators.</summary>
        public long PerWorkerBytes { get; }

        public HapeScheduler(int maxDistBp, bool withDPrime)
        {
            // Each worker keeps sumRR[] + count[] (+ sumD[] for D') of length maxDistBp+2.
            long slots = (long)maxDistBp + 2;
            PerWorkerBytes = slots * (sizeof(double) + sizeof(long)) + (withDPrime ? slots * sizeof(double) : 0);
        }

        /// <summary>Degree of parallelism: cap by cores and by a fraction of available memory.</summary>
        public int DecideDegreeOfParallelism()
        {
            int cores = Environment.ProcessorCount;
            long budget = AvailableMemoryBytes() / 2; // use at most half of free RAM for accumulators
            long byMemory = Math.Max(1, budget / PerWorkerBytes);   // PerWorkerBytes is never 0
            return (int)Math.Max(1, Math.Min(cores, byMemory));
        }

        private static long AvailableMemoryBytes()
        {
#if NET8_0_OR_GREATER
            // net8 has no built-in PerformanceCounter without an extra Windows-only package; the GC
            // memory info gives a portable estimate of currently-available RAM.
            try
            {
                var info = GC.GetGCMemoryInfo();
                long avail = info.TotalAvailableMemoryBytes - info.MemoryLoadBytes;
                return avail > 0 ? avail : 2L * 1024 * 1024 * 1024;
            }
            catch
            {
                return 2L * 1024 * 1024 * 1024;
            }
#else
            try
            {
                using (var pc = new PerformanceCounter("Memory", "Available Bytes"))
                {
                    return (long)pc.NextValue();
                }
            }
            catch
            {
                return 2L * 1024 * 1024 * 1024; // conservative 2 GB fallback if the counter is unavailable
            }
#endif
        }
    }
}
