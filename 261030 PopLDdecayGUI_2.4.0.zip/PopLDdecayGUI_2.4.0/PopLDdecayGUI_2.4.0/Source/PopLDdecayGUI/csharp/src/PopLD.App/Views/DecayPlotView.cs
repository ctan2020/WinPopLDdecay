using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Media;
using PopLD.Infrastructure.Plotting;

namespace PopLD.App.Views
{
    /// <summary>
    /// Vector LD-decay plot drawn directly with WPF (no charting library). Geometry (axes,
    /// gridlines, ticks, series polylines, legend) comes from the shared PlotLayout, the same
    /// layout the vector-PDF exporter uses, so screen, PNG and PDF all match. Being a
    /// FrameworkElement with an OnRender override, it exports crisply to PNG via
    /// RenderTargetBitmap.
    /// </summary>
    public sealed class DecayPlotView : FrameworkElement
    {
        private readonly List<DecayPoints> _series = new List<DecayPoints>();
        private readonly Color[] _palette;

        public DecayPlotView()
        {
            _palette = new Color[PlotPalette.Colors.Length];
            for (int i = 0; i < _palette.Length; i++)
            {
                byte[] c = PlotPalette.Colors[i];
                _palette[i] = Color.FromRgb(c[0], c[1], c[2]);
            }
        }

        public void SetSeries(IEnumerable<DecayPoints> series)
        {
            _series.Clear();
            _series.AddRange(series);
            InvalidateVisual();
        }

        /// <summary>True when at least one series has points to draw (all-empty plots — e.g.
        /// D' requested from OutType-1 files — should not be exportable).</summary>
        public bool HasData
        {
            get
            {
                foreach (var s in _series) if (s.XKb.Length > 0) return true;
                return false;
            }
        }

        protected override void OnRender(DrawingContext dc)
        {
            double W = ActualWidth, H = ActualHeight;
            dc.DrawRectangle(Brushes.White, null, new Rect(0, 0, W, H));
            if (W < 80 || H < 80) return;

            double textHeight = MakeText("Ag").Height;
            var layout = PlotLayout.Compute(W, H, _series, s => MakeText(s).Width, textHeight);

            var axisPen = new Pen(new SolidColorBrush(Color.FromRgb(0x88, 0x88, 0x90)), 1);
            var gridPen = new Pen(new SolidColorBrush(Color.FromRgb(0xE2, 0xE2, 0xE8)), 1);
            axisPen.Freeze(); gridPen.Freeze();

            foreach (var g in layout.GridLines)
                dc.DrawLine(gridPen, new Point(g.X1, g.Y1), new Point(g.X2, g.Y2));
            foreach (var a in layout.AxisLines)
                dc.DrawLine(axisPen, new Point(a.X1, a.Y1), new Point(a.X2, a.Y2));

            foreach (var t in layout.TickLabels) DrawText(dc, t);
            DrawText(dc, layout.XAxisLabel);
            DrawText(dc, layout.YAxisLabel);
            DrawText(dc, layout.RightAxisLabel);

            // series
            foreach (var s in layout.Series)
            {
                if (s.Xs.Length == 0) continue;
                var pen = new Pen(new SolidColorBrush(_palette[s.ColorIndex]), 2);
                pen.Freeze();

                var geo = new StreamGeometry();
                using (var g = geo.Open())
                {
                    g.BeginFigure(new Point(s.Xs[0], s.Ys[0]), false, false);
                    for (int i = 1; i < s.Xs.Length; i++)
                        g.LineTo(new Point(s.Xs[i], s.Ys[i]), true, false);
                }
                geo.Freeze();
                dc.DrawGeometry(null, pen, geo);
            }

            // legend
            if (layout.HasLegend)
            {
                var b = layout.LegendBox;
                var bg = new SolidColorBrush(Color.FromArgb(224, 255, 255, 255));
                var border = new Pen(new SolidColorBrush(Color.FromRgb(0xDD, 0xDD, 0xE3)), 1);
                bg.Freeze(); border.Freeze();
                dc.DrawRoundedRectangle(bg, border, new Rect(b.X, b.Y, b.W, b.H), 6, 6);

                foreach (var item in layout.LegendItems)
                {
                    var sw = item.Swatch;
                    dc.DrawRectangle(new SolidColorBrush(_palette[item.ColorIndex]), null,
                        new Rect(sw.X, sw.Y, sw.W, sw.H));
                    DrawText(dc, item.Label);
                }
            }
        }

        private void DrawText(DrawingContext dc, PlotText t)
        {
            if (t == null || string.IsNullOrEmpty(t.Text)) return;
            dc.DrawText(MakeText(t.Text), new Point(t.X, t.Y));
        }

        private FormattedText MakeText(string s)
        {
            double dpi = VisualTreeHelper.GetDpi(this).PixelsPerDip;
            return new FormattedText(s, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                new Typeface("Segoe UI"), 12, new SolidColorBrush(Color.FromRgb(0x44, 0x44, 0x44)), dpi);
        }
    }
}
