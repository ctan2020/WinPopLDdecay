using System;
using System.IO;
using System.IO.Compression;

namespace PopLD.Domain.IO
{
    /// <summary>
    /// Reads a gzip file to its end, member after member (<c>cat a.gz b.gz</c>, or a writer that
    /// flushes members), as zlib's gzread does, and checks every member against its trailer. The
    /// same code runs on every runtime: .NET Framework's <see cref="GZipStream"/> stops after the
    /// first member, and on both .NET Framework and .NET 5+ it reports a file cut off in the
    /// middle of a member as a normal end of data, so a truncated download would read as a
    /// complete, shorter file.
    /// <para>Each member's header is parsed here and its deflate data inflated by a raw
    /// <see cref="DeflateStream"/>, which stops where the deflate data ends. It reads ahead, so
    /// that point is found from the trailer instead: the member's CRC-32 and length (mod 2^32),
    /// both computed here from the inflated bytes, must stand as eight bytes just behind the base
    /// stream's position. When they do not, the member is incomplete or damaged and reading fails
    /// with <see cref="InvalidDataException"/>. After a complete member, bytes that do not start
    /// another one are ignored, as zlib ignores them.</para>
    /// </summary>
    public sealed class GzipMembersStream : ReadOnlyStream
    {
        /// <summary>DeflateStream reads ahead at most its 8 KiB input buffer; the search covers far more.</summary>
        private const int Window = 1 << 16;

        private readonly Stream _base;
        private DeflateStream _current;
        private long _dataStart;     // where the current member's deflate data begins
        private long _memberBytes;   // bytes inflated so far from the current member
        private uint _crc;           // and their CRC-32
        private bool _done;
        private InvalidDataException _failure;

        /// <param name="seekableBase">A readable, seekable stream positioned at the first member.</param>
        public GzipMembersStream(Stream seekableBase)
        {
            _base = seekableBase ?? throw new ArgumentNullException(nameof(seekableBase));
            if (!_base.CanSeek) throw new ArgumentException("The base stream must be seekable.", nameof(seekableBase));
            BeginMember();
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            // Once the data has been found damaged, every later read says so again rather than
            // carrying on from an undefined place.
            if (_failure != null) throw new InvalidDataException(_failure.Message, _failure);
            if (count == 0) return 0;
            try
            {
                while (!_done)
                {
                    int n = _current.Read(buffer, offset, count);
                    if (n > 0)
                    {
                        _memberBytes += n;
                        _crc = Crc32.Append(_crc, buffer, offset, n);
                        return n;
                    }
                    EndMember();
                }
                return 0;
            }
            catch (InvalidDataException ex)
            {
                _failure = ex;
                throw;
            }
        }

        /// <summary>Reads the gzip header at the base stream's position and starts inflating.</summary>
        private void BeginMember()
        {
            var h = new byte[10];
            if (ReadUpTo(_base, h, 0, 10) < 10) throw Truncated();
            if (h[0] != 0x1f || h[1] != 0x8b) throw new InvalidDataException("The data is not in gzip format.");
            if (h[2] != 8) throw new InvalidDataException("A gzip member uses an unknown compression method.");
            int flags = h[3];
            if ((flags & 0xE0) != 0) throw new InvalidDataException("A gzip member has reserved header flags set.");
            if ((flags & 0x04) != 0)                       // FEXTRA: two-byte length, then the field
            {
                int b0 = _base.ReadByte(), b1 = _base.ReadByte();
                if (b1 < 0) throw Truncated();
                Skip(b0 | (b1 << 8));
            }
            if ((flags & 0x08) != 0) SkipZeroTerminated();  // FNAME
            if ((flags & 0x10) != 0) SkipZeroTerminated();  // FCOMMENT
            if ((flags & 0x02) != 0) Skip(2);               // FHCRC
            _dataStart = _base.Position;
            _memberBytes = 0;
            _crc = 0;
            _current = new DeflateStream(_base, CompressionMode.Decompress, true);
        }

        /// <summary>
        /// Checks the trailer of the member just inflated and starts the next member, if one
        /// follows; otherwise marks the end of the data.
        /// </summary>
        private void EndMember()
        {
            long consumed = _base.Position;
            long length = _base.Length;
            _current.Dispose();
            _current = null;

            // The trailer starts where the deflate data ends: at or before `consumed`, within the
            // read-ahead window, and at least two bytes (the shortest deflate stream) into the data.
            long lo = Math.Max(_dataStart + 2, consumed - Window);
            long hi = Math.Min(consumed, length - 8);
            if (lo <= hi)
            {
                int span = (int)(Math.Min(length, hi + 10) - lo);   // trailer, plus two bytes after it
                var buf = new byte[span];
                _base.Position = lo;
                int got = ReadUpTo(_base, buf, 0, span);
                uint size = (uint)_memberBytes;
                for (int i = 0; i + 8 <= got && lo + i <= hi; i++)
                {
                    if (U32(buf, i) != _crc || U32(buf, i + 4) != size) continue;
                    long end = lo + i + 8;
                    if (i + 10 <= got && buf[i + 8] == 0x1f && buf[i + 9] == 0x8b)
                    {
                        _base.Position = end;
                        BeginMember();
                    }
                    else
                    {
                        _done = true;   // end of file, or trailing bytes that are not gzip data
                    }
                    return;
                }
            }
            throw new InvalidDataException(
                "The gzip file ends in the middle of a member, or a member does not match its " +
                "checksum: the file is truncated or damaged.");
        }

        private static InvalidDataException Truncated()
            => new InvalidDataException("The gzip file ends inside a member header: the file is truncated or damaged.");

        private void Skip(int n)
        {
            if (_base.Length - _base.Position < n) throw Truncated();
            _base.Position += n;
        }

        private void SkipZeroTerminated()
        {
            int b;
            while ((b = _base.ReadByte()) != 0)
                if (b < 0) throw Truncated();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _current?.Dispose();
                _base.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
